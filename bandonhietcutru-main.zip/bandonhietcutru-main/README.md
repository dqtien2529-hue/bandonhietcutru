# Hệ Thống Giám Sát Lĩnh Vực Cư Trú, Căn Cước - Công An Tỉnh Đắk Lắk

Ứng dụng giám sát trực tuyến chỉ tiêu công tác cư trú, cấp căn cước và định danh điện tử của 102 xã, phường thuộc Công an tỉnh Đắk Lắk. Ứng dụng đã được chuyển đổi hoàn toàn sang **React + TypeScript + Vite + Tailwind CSS**.

## Tính năng chính

1. **Bản đồ nhiệt tương tác 102 xã, phường (Interactive SVG Heatmap):**
   - Bản đồ địa bàn tỉnh Đắk Lắk được số hóa theo từng xã/phường.
   - Tô màu tự động theo ngưỡng hoàn thành chỉ tiêu: 🟢 Đạt tốt, 🟡 Trung bình, 🔴 Chậm, ⚪ Chưa có dữ liệu.
   - Cảnh báo viền đỏ đối với các đơn vị đóng băng (từ 3 ngày trở lên chưa phát sinh số liệu mới).
   - Tooltip thông tin chi tiết di chuyển theo con trỏ chuột (kết quả ngày, lũy kế, chỉ tiêu giao, tỷ lệ %).
   - Bộ lọc trạng thái bản đồ và công cụ phóng to / thu nhỏ / đặt lại độ phóng.

2. **Bảng tổng hợp chỉ tiêu & Top 10 dẫn đầu / báo động:**
   - 5 thẻ chỉ số tổng quan theo thời gian thực (Tổng số đơn vị, Đạt tốt, Trung bình, Chậm/Báo động, Tỷ lệ hoàn thành toàn tỉnh).
   - Top 10 đơn vị dẫn đầu với huy hiệu 🥇🥈🥉.
   - Top 10 đơn vị báo động tiến độ chậm.

3. **Bảng dữ liệu 102 xã, phường chi tiết:**
   - Tìm kiếm nhanh theo tên xã/phường.
   - Lọc nhanh theo phân loại trạng thái.
   - Hiển thị thanh tiến độ %, kết quả ngày (+N), lũy kế đạt, chỉ tiêu giao.
   - Nhấp vào bất kỳ xã/phường nào để mở modal chi tiết và điều chỉnh số liệu của từng chỉ tiêu.

4. **Cập nhật số liệu ngày & Nhập tệp CSV:**
   - Bảng nhập kết quả ngày cho cả 102 đơn vị theo từng chỉ tiêu.
   - Hỗ trợ tải tệp CSV đối soát số liệu tự động theo mã STT.
   - Modal xem trước và đối soát dữ liệu CSV trước khi lưu chính thức.

5. **Tạo dự thảo báo cáo hành chính tự động:**
   - Tổng hợp nhanh tình hình số liệu, tỷ lệ hoàn thành, danh sách đơn vị cần quan tâm và đơn vị có tiến độ cao.
   - Định dạng văn bản hành chính theo quy chuẩn ngành Công an.
   - Nút sao chép văn bản vào clipboard với 1 cú nhấp.

6. **Kho lưu trữ & Xuất file:**
   - Lưu trữ dữ liệu lịch sử theo từng ngày báo cáo vào LocalStorage và đồng bộ giữa các tab trình duyệt.
   - Xuất dữ liệu bảng tổng hợp ra file Excel (.xlsx) chuẩn SheetJS.
   - Chụp và xuất ảnh Banner độ phân giải cao dạng PNG bằng `html2canvas`.

7. **Cấu hình chỉ tiêu & Tiêu chí chuyên môn:**
   - Tùy chỉnh tên và ngưỡng đánh giá (Tốt ≥ %, Trung bình ≥ %) cho từng chỉ tiêu.
   - Thêm chỉ tiêu mới hoặc xóa chỉ tiêu khi có yêu cầu nghiệp vụ mới.
   - Khôi phục dữ liệu và 5 chỉ tiêu mặc định.

8. **Chế độ trình chiếu Kiosk:**
   - Tự động luân chuyển tiêu điểm giữa Bản đồ nhiệt ➔ Bảng xếp hạng ➔ Bảng dữ liệu theo chu kỳ 8 giây.

## Công nghệ sử dụng
- **React 19 & TypeScript**
- **Vite**
- **Tailwind CSS v4**
- **Lucide React** (bộ icon hành chính, chuyên nghiệp)
- **html2canvas** (chụp ảnh banner)
- **XLSX (SheetJS)** (xử lý file Excel & CSV)
