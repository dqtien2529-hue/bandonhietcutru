import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import sharp from 'sharp';
import Tesseract from 'tesseract.js';
import { OFFICIAL_102_COMMUNES } from './src/data/communes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '25mb' }));

// Helper text normalizer for Vietnamese matching
function normalizeText(str: string): string {
  return (str || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const d: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) d[i][0] = i;
  for (let j = 0; j <= n; j++) d[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
    }
  }
  return d[m][n];
}

function stripPrefix(s: string): string {
  return s
    .replace(/^[^a-z0-9]*/i, '')
    .replace(/^(xa+|phuong+|tt+|thitran+|donvi+)+/i, '')
    .replace(/^[a-z]{1,2}(?=(ea|krong|cu|buon|dak|hoa|phu|xuan|tuy|son|song|nam|lien|tam))/i, '');
}

function findMatchingCommune(rawWord: string) {
  const normRaw = normalizeText(rawWord);
  if (!normRaw || normRaw.length < 3) return null;
  if (normRaw.includes('tong') || normRaw.includes('donvi') || normRaw.includes('stt') || normRaw.includes('chitie')) return null;

  const strippedRaw = stripPrefix(normRaw);
  let best: { stt: number; name: string } | null = null;
  let bestScore = 0;

  for (const c of OFFICIAL_102_COMMUNES) {
    const coreNorm = stripPrefix(normalizeText(c.name));

    if (strippedRaw && (strippedRaw === coreNorm || strippedRaw.includes(coreNorm) || coreNorm.includes(strippedRaw))) {
      return { stt: c.stt, name: c.name, score: 0.98 };
    }

    const maxLen = Math.max(strippedRaw.length, coreNorm.length);
    const dist = levenshtein(strippedRaw, coreNorm);
    const sim = 1 - dist / maxLen;

    if (sim > 0.65 && sim > bestScore) {
      bestScore = sim;
      best = { stt: c.stt, name: c.name };
    }
  }

  return bestScore >= 0.65 && best ? { ...best, score: bestScore } : null;
}

// Fallback OCR parser for table images
async function parseTableWithOCR(imageBuffer: Buffer, kpiList: any[] = []) {
  try {
    const trimmed = await sharp(imageBuffer)
      .trim({ background: { r: 255, g: 255, b: 255 }, threshold: 12 })
      .resize({ width: 1600 })
      .toBuffer();

    const ocr = await Tesseract.recognize(trimmed, 'vie+eng');
    let rawText = ocr.data.text || '';

    // If first pass was too short or empty, try thresholding
    if (rawText.length < 30) {
      const thresholded = await sharp(trimmed).grayscale().threshold(180).toBuffer();
      const ocrThresh = await Tesseract.recognize(thresholded, 'vie+eng');
      rawText = `${rawText}\n${ocrThresh.data.text || ''}`;
    }

    const lines = rawText.split(/[\r\n]+/);
    const resultMap = new Map<number, { stt: number; name: string; kpiValues: any; confidence: number; note: string }>();

    for (const line of lines) {
      const parts = line.split('|').map(p => p.trim()).filter(Boolean);
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        const match = findMatchingCommune(part);
        if (match) {
          let num: number | null = null;
          const inlineMatch = part.match(/\b([0-9]+)\b/);
          if (inlineMatch) {
            num = parseInt(inlineMatch[1], 10);
          } else if (i + 1 < parts.length) {
            const nextMatch = parts[i + 1].match(/\b([0-9]+)\b/);
            if (nextMatch) num = parseInt(nextMatch[1], 10);
          }

          if (num !== null && !isNaN(num) && num >= 0 && num < 1000) {
            const existing = resultMap.get(match.stt) || {
              stt: match.stt,
              name: match.name,
              kpiValues: {
                qua_han_ngay: 0,
                da_thu_nhan: 0,
                da_kich_hoat: 0,
                con_phai_lam: 0,
                luy_ke: 0,
                chi_tieu_ngay: 100
              },
              confidence: match.score || 0.95,
              note: 'Nhận diện tự động từ bảng ảnh'
            };

            existing.kpiValues.qua_han_ngay += num;
            resultMap.set(match.stt, existing);
          }
        }
      }
    }

    return Array.from(resultMap.values());
  } catch (err: any) {
    console.error('Fallback OCR error:', err);
    return [];
  }
}

// AI Image & Document Table Parser endpoint
app.post('/api/ai/parse-image', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', kpiList = [] } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Thiếu dữ liệu hình ảnh (imageBase64).' });
    }

    const rawData = imageBase64.replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, '');
    const imageBuffer = Buffer.from(rawData, 'base64');

    // Preprocess image with sharp: trim whitespace so tables occupy the majority of view
    let processedBuffer = imageBuffer;
    try {
      processedBuffer = await sharp(imageBuffer)
        .trim({ background: { r: 255, g: 255, b: 255 }, threshold: 10 })
        .resize({ width: 1400, withoutEnlargement: false })
        .png()
        .toBuffer();
    } catch (e) {
      console.warn('Sharp trim skipped:', e);
      processedBuffer = imageBuffer;
    }

    const apiKey = process.env.GEMINI_API_KEY?.trim();
    let parsedRows: any[] = [];

    // Attempt Gemini models if API key is present
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const communeReference = OFFICIAL_102_COMMUNES.map(c => `${c.stt}. ${c.name}`).join(', ');
        const systemPrompt = `Bạn là chuyên gia trích xuất bảng biểu số liệu hành chính của Công an tỉnh Đắk Lắk.
Nhiệm vụ: Nhận diện danh sách xã/phường và số liệu trong ảnh.
Danh sách 102 xã/phường chính thức để đối chiếu:
${communeReference}

QUY TẮC ĐẶC BIỆT:
1. Bảng có thể chia cột hoặc nhiều bảng con (ví dụ: Tạm trú quá hạn và Thường trú quá hạn).
2. Đối với chỉ tiêu quá hạn: Nếu một xã có cả tạm trú và thường trú, hãy cộng tổng vào qua_han_ngay (ví dụ: tạm trú 2, thường trú 4 -> qua_han_ngay = 6).
3. Không bỏ sót bất kỳ xã/phường nào có số liệu.
4. Bỏ qua dòng "Tổng".
5. Trả về mảng JSON với name và kpiValues.`;

        // Try gemini-3.1-flash-lite first, fallback to gemini-3.8-flash if needed
        const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
        let rawJson: any = null;

        for (const model of candidateModels) {
          try {
            const response = await ai.models.generateContent({
              model,
              contents: [
                {
                  inlineData: {
                    mimeType: 'image/png',
                    data: processedBuffer.toString('base64'),
                  },
                },
                {
                  text: 'Trích xuất toàn bộ các xã/phường và số liệu trong ảnh. Bỏ qua dòng Tổng.',
                },
              ],
              config: {
                systemInstruction: systemPrompt,
                responseMimeType: 'application/json',
                responseSchema: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: 'Tên xã hoặc phường' },
                      qua_han_ngay: { type: Type.INTEGER, description: 'Tổng số hồ sơ quá hạn (tạm trú + thường trú nếu có)' },
                      tam_tru_qua_han: { type: Type.INTEGER, description: 'Số tạm trú quá hạn' },
                      thuong_tru_qua_han: { type: Type.INTEGER, description: 'Số thường trú quá hạn' },
                      da_thu_nhan: { type: Type.INTEGER, description: 'Định danh mức 2 đã thu nhận' },
                      da_kich_hoat: { type: Type.INTEGER, description: 'Định danh mức 2 đã kích hoạt' },
                      con_phai_lam: { type: Type.INTEGER, description: 'Làm sạch dữ liệu còn phải làm' },
                      luy_ke: { type: Type.INTEGER, description: 'Số hóa tàng thư lũy kế' },
                      chi_tieu_ngay: { type: Type.INTEGER, description: 'Chỉ tiêu ngày' },
                      note: { type: Type.STRING, description: 'Ghi chú đối soát' },
                    },
                    required: ['name'],
                  },
                },
              },
            });

            if (response.text) {
              const parsed = JSON.parse(response.text);
              if (Array.isArray(parsed) && parsed.length > 0) {
                rawJson = parsed;
                break;
              }
            }
          } catch {
            // Continue to next candidate model or fallback OCR
          }
        }

        if (Array.isArray(rawJson) && rawJson.length > 0) {
          parsedRows = rawJson.map((item: any) => {
            const matched = findMatchingCommune(item.name || '');
            const kVals = item.kpiValues || {};
            
            const rawQuaHan = item.qua_han_ngay ?? kVals.qua_han_ngay;
            const rawTamTru = item.tam_tru_qua_han ?? kVals.tam_tru_qua_han ?? 0;
            const rawThuongTru = item.thuong_tru_qua_han ?? kVals.thuong_tru_qua_han ?? 0;
            const sumOverdue = rawTamTru + rawThuongTru;
            const finalQuaHan = rawQuaHan !== undefined && rawQuaHan !== null 
              ? (sumOverdue > rawQuaHan ? sumOverdue : rawQuaHan)
              : sumOverdue;

            return {
              stt: matched ? matched.stt : (item.stt || 0),
              name: matched ? matched.name : item.name,
              kpiValues: {
                qua_han_ngay: finalQuaHan,
                tam_tru_qua_han: rawTamTru,
                thuong_tru_qua_han: rawThuongTru,
                da_thu_nhan: item.da_thu_nhan ?? kVals.da_thu_nhan ?? 0,
                da_kich_hoat: item.da_kich_hoat ?? kVals.da_kich_hoat ?? 0,
                con_phai_lam: item.con_phai_lam ?? kVals.con_phai_lam ?? 0,
                luy_ke: item.luy_ke ?? kVals.luy_ke ?? 0,
                chi_tieu_ngay: item.chi_tieu_ngay ?? kVals.chi_tieu_ngay ?? 100
              },
              confidence: item.confidence ?? 0.98,
              note: item.note || 'Nhận diện tự động'
            };
          }).filter((r: any) => r.stt > 0);
        }
      } catch {
        // Fall back gracefully to OCR without logging error dumps
      }
    }

    // If Gemini was unavailable or yielded 0 rows, use fallback OCR
    if (!parsedRows || parsedRows.length === 0) {
      parsedRows = await parseTableWithOCR(imageBuffer, kpiList);
    }

    // Merge duplicates if same commune was returned multiple times
    const mergedMap = new Map<number, any>();
    for (const row of parsedRows) {
      if (!row.stt) continue;
      if (mergedMap.has(row.stt)) {
        const existing = mergedMap.get(row.stt);
        existing.kpiValues.qua_han_ngay = Math.max(existing.kpiValues.qua_han_ngay || 0, row.kpiValues.qua_han_ngay || 0);
        existing.kpiValues.da_thu_nhan = Math.max(existing.kpiValues.da_thu_nhan || 0, row.kpiValues.da_thu_nhan || 0);
        existing.kpiValues.da_kich_hoat = Math.max(existing.kpiValues.da_kich_hoat || 0, row.kpiValues.da_kich_hoat || 0);
        existing.kpiValues.con_phai_lam = Math.max(existing.kpiValues.con_phai_lam || 0, row.kpiValues.con_phai_lam || 0);
        existing.kpiValues.luy_ke = Math.max(existing.kpiValues.luy_ke || 0, row.kpiValues.luy_ke || 0);
      } else {
        mergedMap.set(row.stt, row);
      }
    }

    const finalRows = Array.from(mergedMap.values());

    return res.json({
      success: true,
      rows: finalRows,
      count: finalRows.length
    });
  } catch (err: any) {
    console.error('AI Table parsing error:', err);
    return res.status(500).json({
      error: err.message || 'Lỗi khi nhận diện bảng số liệu.',
    });
  }
});

async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
  });
}

startServer();
