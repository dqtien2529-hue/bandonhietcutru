import React, { useState, useEffect, useRef, useMemo } from 'react';
import { AppState, CommuneKPIValues, CsvPreviewRow, KPI, KpiType } from './types';
import { OFFICIAL_102_COMMUNES, formatDateYMD } from './data/communes';
import { loadStateForDate, writeDateRecord, createDefaultState } from './utils/storage';
import { computeSummaryData } from './utils/calculations';
import { HeaderBanner } from './components/HeaderBanner';
import { SubToolbar } from './components/SubToolbar';
import { SummaryCards } from './components/SummaryCards';
import { HeatmapMap } from './components/HeatmapMap';
import { Leaderboards } from './components/Leaderboards';
import { CommuneTable } from './components/CommuneTable';
import { SidebarNav } from './components/SidebarNav';
import { CommuneDetailModal } from './components/modals/CommuneDetailModal';
import { DailyUpdateModal, AutoFilledInfo } from './components/modals/DailyUpdateModal';
import { CsvPreviewModal } from './components/modals/CsvPreviewModal';
import { AiReportModal } from './components/modals/AiReportModal';
import { ArchiveModal } from './components/modals/ArchiveModal';
import { BannerDownloadModal } from './components/modals/BannerDownloadModal';
import { KpiAdminModal } from './components/modals/KpiAdminModal';
import { RankingRulesModal } from './components/modals/RankingRulesModal';
import { AdminAuthModal } from './components/modals/AdminAuthModal';
import { AdminPasswordSettingsModal } from './components/modals/AdminPasswordSettingsModal';
import * as XLSX from 'xlsx';

export function App() {
  const getTodayStr = () => formatDateYMD(new Date());

  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr);
  const [appState, setAppState] = useState<AppState>(() => {
    const initial = loadStateForDate(getTodayStr());
    return initial.state;
  });
  const [previousState, setPreviousState] = useState<AppState | undefined>(() => {
    const initial = loadStateForDate(getTodayStr());
    return initial.previousState;
  });
  const [version, setVersion] = useState<number>(1);
  const [syncMessage, setSyncMessage] = useState<string>('Lưu trên trình duyệt • đồng bộ giữa các tab');
  const [syncConnected, setSyncConnected] = useState<boolean>(true);

  // Kiosk state
  const [kioskRunning, setKioskRunning] = useState<boolean>(false);
  const [kioskStep, setKioskStep] = useState<number>(0);

  // Modals state
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDailyUpdateOpen, setIsDailyUpdateOpen] = useState(false);
  const [isAiReportOpen, setIsAiReportOpen] = useState(false);
  const [isArchiveOpen, setIsArchiveOpen] = useState(false);
  const [isKpiAdminOpen, setIsKpiAdminOpen] = useState(false);
  const [isRankingRulesOpen, setIsRankingRulesOpen] = useState(false);
  const [isBannerDownloadOpen, setIsBannerDownloadOpen] = useState(false);
  const [selectedCommuneStt, setSelectedCommuneStt] = useState<number | null>(null);

  // Preview Modal for Excel/CSV/AI Image
  const [isCsvPreviewOpen, setIsCsvPreviewOpen] = useState(false);
  const [csvPreviewRows, setCsvPreviewRows] = useState<CsvPreviewRow[]>([]);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [autoFilledInfo, setAutoFilledInfo] = useState<AutoFilledInfo | null>(null);
  const [injectedBatch, setInjectedBatch] = useState<Record<number, Record<string, CommuneKPIValues>> | null>(null);

  // Admin Authentication State (Default password: 775593)
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('daklak_admin_authenticated') === 'true';
    } catch {
      return false;
    }
  });

  const [adminPassword, setAdminPassword] = useState<string>(() => {
    try {
      return localStorage.getItem('daklak_admin_password') || '775593';
    } catch {
      return '775593';
    }
  });

  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState(false);
  const [isAdminPasswordSettingsOpen, setIsAdminPasswordSettingsOpen] = useState(false);

  const bannerRef = useRef<HTMLDivElement>(null);

  // Authenticate Admin
  const handleAdminAuthenticate = (pass: string): boolean => {
    if (pass === adminPassword) {
      setIsAdmin(true);
      try {
        sessionStorage.setItem('daklak_admin_authenticated', 'true');
      } catch (e) {
        console.warn(e);
      }
      return true;
    }
    return false;
  };

  // Logout Admin
  const handleAdminLogout = () => {
    setIsAdmin(false);
    try {
      sessionStorage.removeItem('daklak_admin_authenticated');
    } catch (e) {
      console.warn(e);
    }
    // Close any administrative modals
    setIsDailyUpdateOpen(false);
    setIsAiReportOpen(false);
    setIsArchiveOpen(false);
    setIsKpiAdminOpen(false);
    setIsCsvPreviewOpen(false);
  };

  // Update Admin Password
  const handleUpdateAdminPassword = (oldPass: string, newPass: string): { success: boolean; message: string } => {
    if (oldPass !== adminPassword) {
      return { success: false, message: 'Mật khẩu hiện tại không chính xác.' };
    }
    setAdminPassword(newPass);
    try {
      localStorage.setItem('daklak_admin_password', newPass);
    } catch (e) {
      console.warn(e);
    }
    return { success: true, message: 'Đã thay đổi mật khẩu quản trị thành công!' };
  };

  // Reset Admin Password to default 775593
  const handleResetAdminPasswordToDefault = () => {
    setAdminPassword('775593');
    try {
      localStorage.setItem('daklak_admin_password', '775593');
    } catch (e) {
      console.warn(e);
    }
  };

  // Protected modal openers (require admin login)
  const handleOpenDailyUpdate = () => {
    if (!isAdmin) {
      setIsAdminAuthModalOpen(true);
    } else {
      setIsDailyUpdateOpen(true);
    }
  };

  const handleOpenAiReport = () => {
    if (!isAdmin) {
      setIsAdminAuthModalOpen(true);
    } else {
      setIsAiReportOpen(true);
    }
  };

  const handleOpenArchive = () => {
    if (!isAdmin) {
      setIsAdminAuthModalOpen(true);
    } else {
      setIsArchiveOpen(true);
    }
  };

  const handleOpenKpiAdmin = () => {
    if (!isAdmin) {
      setIsAdminAuthModalOpen(true);
    } else {
      setIsKpiAdminOpen(true);
    }
  };

  // Helper to persist state
  const persistState = (newState: AppState) => {
    setAppState(newState);
    const nextVer = version + 1;
    setVersion(nextVer);
    writeDateRecord(newState.selectedDate, newState, nextVer);
    setSyncMessage('Đã lưu • đồng bộ giữa các tab');
    setSyncConnected(true);
  };

  // Switch Date with safe local parsing and load nearest previous date for historical comparison
  const handleDateChange = (newDate: string) => {
    setSelectedDate(newDate);
    const loaded = loadStateForDate(newDate);
    setAppState(loaded.state);
    setPreviousState(loaded.previousState);
    setVersion(loaded.version || 1);
  };

  // Cross-tab sync
  useEffect(() => {
    const handleStorageEvent = (e: StorageEvent) => {
      const prefix = 'daklak-kpi-report:v1:';
      if (!e.key || !e.key.startsWith(prefix)) return;
      const dateKey = e.key.slice(prefix.length);
      if (dateKey !== selectedDate) return;

      try {
        const parsed = e.newValue ? JSON.parse(e.newValue) : null;
        if (parsed && parsed.state && Number(parsed.version) > version) {
          setAppState(parsed.state);
          setVersion(Number(parsed.version));
          setSyncMessage('Đã nhận cập nhật từ tab khác');
        }
      } catch (err) {
        console.error(err);
      }
    };

    window.addEventListener('storage', handleStorageEvent);
    return () => window.removeEventListener('storage', handleStorageEvent);
  }, [selectedDate, version]);

  // Kiosk interval
  useEffect(() => {
    if (!kioskRunning) return;
    const interval = setInterval(() => {
      setKioskStep(prev => (prev + 1) % 3);
    }, 8000);
    return () => clearInterval(interval);
  }, [kioskRunning]);

  // Computed summary
  const summary = useMemo(() => {
    return computeSummaryData(
      appState.communeData,
      previousState?.communeData,
      appState.kpis,
      appState.selectedKpiId,
      appState.selectedPeriod,
      appState.rankingRules
    );
  }, [appState.communeData, previousState?.communeData, appState.kpis, appState.selectedKpiId, appState.selectedPeriod, appState.rankingRules]);

  // Save commune details from CommuneDetailModal
  const handleSaveCommuneDetails = (stt: number, stats: Record<string, CommuneKPIValues>) => {
    const newCommuneData = {
      ...appState.communeData,
      [stt]: {
        stats,
        last_updated_days_ago: 0
      }
    };
    persistState({
      ...appState,
      communeData: newCommuneData
    });
  };

  // Batch save daily data from DailyUpdateModal
  const handleBatchSaveDaily = (updates: Record<number, Record<string, CommuneKPIValues>>) => {
    const updated = { ...appState.communeData };
    Object.entries(updates).forEach(([sttStr, kpiMap]) => {
      const stt = parseInt(sttStr, 10);
      if (!updated[stt]) updated[stt] = { stats: {} };
      updated[stt] = {
        ...updated[stt],
        stats: {
          ...updated[stt].stats,
          ...kpiMap
        },
        last_updated_days_ago: 0
      };
    });

    persistState({
      ...appState,
      communeData: updated
    });
  };

  // Excel (.xlsx, .xls) & CSV File Upload Parser
  const handleExcelOrCsvFileSelected = async (file: File) => {
    setIsProcessingFile(true);
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(new Uint8Array(buffer), { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const table = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: true }) as any[][];

      if (!table || table.length < 2) throw new Error('Tệp chưa có dữ liệu hoặc không có dòng nội dung.');

      const normalize = (val: any) =>
        String(val ?? '')
          .replace(/^\uFEFF/, '')
          .trim()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .toLowerCase();

      const headers = table[0].map(normalize);
      const sttCol = headers.findIndex(h => h === 'stt' || h === 'ma' || h === 'ma don vi');
      const nameCol = headers.findIndex(h => h.includes('ten') || h.includes('xa') || h.includes('phuong') || h.includes('don vi'));

      const colThu = headers.findIndex(h => h.includes('thu nhan') || h === 'ct1_thu' || h === 'thu');
      const colKich = headers.findIndex(h => h.includes('kich hoat') || h === 'ct1_kich' || h === 'kich');
      const colQuaHan = headers.findIndex(h => h.includes('qua han') || h.includes('tre han') || h === 'ct2');
      const colLamSach = headers.findIndex(h => h.includes('con phai lam') || h.includes('lam sach') || h === 'ct3');
      const colLuyKe = headers.findIndex(h => h.includes('luy ke') || h.includes('so hoa') || h === 'ct4');

      const unitsById = new Map(OFFICIAL_102_COMMUNES.map(u => [u.stt, u]));
      const bufferRows: CsvPreviewRow[] = [];
      const injectedUpdates: Record<number, Record<string, CommuneKPIValues>> = {};

      table.slice(1).forEach((cells) => {
        let stt = -1;
        if (sttCol >= 0 && cells[sttCol] !== undefined && cells[sttCol] !== '') {
          stt = parseInt(String(cells[sttCol]).trim(), 10);
        }

        let unit = unitsById.get(stt);
        if (!unit && nameCol >= 0 && cells[nameCol]) {
          const rawName = String(cells[nameCol]).trim().toLowerCase();
          unit = OFFICIAL_102_COMMUNES.find(u => u.name.toLowerCase().includes(rawName));
        }

        if (!unit) return;

        const kpiValues: Record<string, any> = {
          da_thu_nhan: colThu >= 0 ? parseInt(cells[colThu]) || 0 : (parseInt(cells[2]) || 0),
          da_kich_hoat: colKich >= 0 ? parseInt(cells[colKich]) || 0 : (parseInt(cells[3]) || 0),
          qua_han_ngay: colQuaHan >= 0 ? parseInt(cells[colQuaHan]) || 0 : (parseInt(cells[4]) || 0),
          con_phai_lam: colLamSach >= 0 ? parseInt(cells[colLamSach]) || 0 : (parseInt(cells[5]) || 0),
          luy_ke: colLuyKe >= 0 ? parseInt(cells[colLuyKe]) || 0 : (parseInt(cells[6]) || 0),
          chi_tieu_ngay: 100
        };

        const hasNonZero = Object.values(kpiValues).some(v => typeof v === 'number' && v > 0);
        const isUncertain = !hasNonZero || (colThu < 0 && colKich < 0 && colQuaHan < 0);

        bufferRows.push({
          stt: unit.stt,
          name: unit.name,
          kpiValues,
          confidence: isUncertain ? 0.7 : 0.95,
          isUncertain
        });

        injectedUpdates[unit.stt] = {
          kpi_1: {
            da_thu_nhan: kpiValues.da_thu_nhan,
            da_kich_hoat: kpiValues.da_kich_hoat,
            reported: Boolean(kpiValues.da_thu_nhan > 0 || kpiValues.da_kich_hoat > 0)
          },
          kpi_2: {
            qua_han_ngay: kpiValues.qua_han_ngay,
            reported: true
          },
          kpi_3: {
            con_phai_lam: kpiValues.con_phai_lam,
            reported: Boolean(kpiValues.con_phai_lam > 0)
          },
          kpi_4: {
            luy_ke: kpiValues.luy_ke,
            chi_tieu_ngay: 100,
            reported: Boolean(kpiValues.luy_ke > 0)
          }
        };
      });

      if (bufferRows.length === 0) {
        throw new Error('Không nhận diện được dòng dữ liệu xã/phường nào khớp với danh sách 102 đơn vị.');
      }

      setCsvPreviewRows(bufferRows);
      setInjectedBatch(injectedUpdates);

      const names = bufferRows.map(r => r.name);
      setAutoFilledInfo({
        count: bufferRows.length,
        communeNames: names,
        sttList: bufferRows.map(r => r.stt),
        summary: `Đã nạp tệp và tự động điền ${bufferRows.length} đơn vị vào bảng đối soát!`
      });

      // Keep DailyUpdateModal OPEN so user sees values filled directly into inputs!
      setIsDailyUpdateOpen(true);
    } catch (err: any) {
      alert(err.message || 'Lỗi khi đọc tệp Excel/CSV.');
    } finally {
      setIsProcessingFile(false);
    }
  };

  // AI Table Image OCR / Vision Parser
  const handleImageFileSelected = async (file: File) => {
    setIsProcessingFile(true);
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const imageBase64 = await base64Promise;

      const resp = await fetch('/api/ai/parse-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          mimeType: file.type || 'image/jpeg',
          kpiList: appState.kpis
        })
      });

      const data = await resp.json();
      if (!resp.ok || !data.success) {
        throw new Error(data.error || 'AI không nhận diện được bảng số liệu.');
      }

      const rowsFromAi = data.rows || [];
      const unitsById = new Map(OFFICIAL_102_COMMUNES.map(u => [u.stt, u]));
      const previewRows: CsvPreviewRow[] = [];
      const injectedUpdates: Record<number, Record<string, CommuneKPIValues>> = {};

      rowsFromAi.forEach((item: any) => {
        let unit = unitsById.get(item.stt);
        if (!unit && item.name) {
          const rawName = String(item.name).trim().toLowerCase();
          unit = OFFICIAL_102_COMMUNES.find(u => u.name.toLowerCase().includes(rawName));
        }
        if (!unit) return;

        const kVals = item.kpiValues || {};
        const totalOverdue = Number(kVals.qua_han_ngay !== undefined ? kVals.qua_han_ngay : ((kVals.tam_tru_qua_han || 0) + (kVals.thuong_tru_qua_han || 0)));

        previewRows.push({
          stt: unit.stt,
          name: unit.name,
          kpiValues: {
            da_thu_nhan: Number(kVals.da_thu_nhan ?? kVals.kpi_1_thu ?? 0),
            da_kich_hoat: Number(kVals.da_kich_hoat ?? kVals.kpi_1_kich ?? 0),
            qua_han_ngay: totalOverdue,
            con_phai_lam: Number(kVals.con_phai_lam ?? kVals.kpi_3 ?? 0),
            luy_ke: Number(kVals.luy_ke ?? kVals.kpi_4 ?? 0),
            chi_tieu_ngay: 100
          },
          confidence: typeof item.confidence === 'number' ? item.confidence : 0.95,
          isUncertain: item.confidence !== undefined && item.confidence < 0.8,
          error: item.note
        });

        injectedUpdates[unit.stt] = {
          kpi_1: {
            da_thu_nhan: Number(kVals.da_thu_nhan ?? 0),
            da_kich_hoat: Number(kVals.da_kich_hoat ?? 0),
            reported: Boolean((kVals.da_thu_nhan || 0) > 0 || (kVals.da_kich_hoat || 0) > 0)
          },
          kpi_2: {
            qua_han_ngay: totalOverdue,
            reported: true
          },
          kpi_3: {
            con_phai_lam: Number(kVals.con_phai_lam ?? 0),
            reported: Boolean((kVals.con_phai_lam || 0) > 0)
          },
          kpi_4: {
            luy_ke: Number(kVals.luy_ke ?? 0),
            chi_tieu_ngay: 100,
            reported: Boolean((kVals.luy_ke || 0) > 0)
          }
        };
      });

      if (previewRows.length === 0) {
        throw new Error('AI không tìm thấy dòng số liệu nào khớp với 102 xã/phường.');
      }

      setCsvPreviewRows(previewRows);
      setInjectedBatch(injectedUpdates);

      const names = previewRows.map(r => r.name);
      setAutoFilledInfo({
        count: previewRows.length,
        communeNames: names,
        sttList: previewRows.map(r => r.stt),
        summary: `AI đã nhận diện thành công ${previewRows.length} đơn vị: ${names.slice(0, 5).join(', ')}${names.length > 5 ? '...' : ''}. Đã tự động điền giá trị vào bảng.`
      });

      // Keep DailyUpdateModal OPEN so user sees values populated directly into their form!
      setIsDailyUpdateOpen(true);
    } catch (err: any) {
      alert(`Nhận diện ảnh: ${err.message}. Bạn có thể nạp tệp Excel hoặc nhập trực tiếp.`);
    } finally {
      setIsProcessingFile(false);
    }
  };

  // Confirm extracted data from CsvPreviewModal without destroying unmentioned KPIs
  const handleConfirmPreviewData = () => {
    const updated = { ...appState.communeData };
    csvPreviewRows.forEach(row => {
      if (!updated[row.stt]) updated[row.stt] = { stats: {} };
      const currentStats = updated[row.stt].stats || {};
      const newVals = row.kpiValues;

      const hasKpi1 = newVals.da_thu_nhan > 0 || newVals.da_kich_hoat > 0;
      const hasKpi2 = newVals.qua_han_ngay !== undefined;
      const hasKpi3 = newVals.con_phai_lam > 0;
      const hasKpi4 = newVals.luy_ke > 0;

      updated[row.stt] = {
        ...updated[row.stt],
        stats: {
          ...currentStats,
          kpi_1: hasKpi1 ? {
            ...currentStats['kpi_1'],
            da_thu_nhan: newVals.da_thu_nhan ?? currentStats['kpi_1']?.da_thu_nhan ?? 0,
            da_kich_hoat: newVals.da_kich_hoat ?? currentStats['kpi_1']?.da_kich_hoat ?? 0,
            reported: true
          } : (currentStats['kpi_1'] || { reported: false }),
          kpi_2: hasKpi2 ? {
            ...currentStats['kpi_2'],
            qua_han_ngay: newVals.qua_han_ngay ?? 0,
            reported: true
          } : (currentStats['kpi_2'] || { reported: false }),
          kpi_3: hasKpi3 ? {
            ...currentStats['kpi_3'],
            con_phai_lam: newVals.con_phai_lam ?? currentStats['kpi_3']?.con_phai_lam ?? 0,
            reported: true
          } : (currentStats['kpi_3'] || { reported: false }),
          kpi_4: hasKpi4 ? {
            ...currentStats['kpi_4'],
            luy_ke: newVals.luy_ke ?? currentStats['kpi_4']?.luy_ke ?? 0,
            chi_tieu_ngay: newVals.chi_tieu_ngay || currentStats['kpi_4']?.chi_tieu_ngay || 100,
            reported: true
          } : (currentStats['kpi_4'] || { reported: false })
        },
        last_updated_days_ago: 0
      };
    });

    persistState({
      ...appState,
      communeData: updated
    });
    setIsCsvPreviewOpen(false);
    setIsDailyUpdateOpen(true);
  };

  // Selected commune object for detail modal
  const selectedCommune = useMemo(() => {
    if (!selectedCommuneStt) return null;
    return OFFICIAL_102_COMMUNES.find(c => c.stt === selectedCommuneStt) || null;
  }, [selectedCommuneStt]);

  return (
    <div className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 min-h-screen flex flex-col transition-colors duration-200">
      {/* Header Banner */}
      <HeaderBanner
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        onOpenBannerDownload={() => setIsBannerDownloadOpen(true)}
        kioskRunning={kioskRunning}
        onToggleKiosk={() => setKioskRunning(!kioskRunning)}
        bannerRef={bannerRef}
      />

      {/* SubToolbar */}
      <SubToolbar
        syncMessage={syncMessage}
        syncConnected={syncConnected}
        selectedPeriod={appState.selectedPeriod}
        onSetPeriod={(p) => persistState({ ...appState, selectedPeriod: p })}
        kpis={appState.kpis}
        selectedKpiId={appState.selectedKpiId}
        onSelectKpi={(id) => persistState({ ...appState, selectedKpiId: id })}
        selectedDate={selectedDate}
        onDateChange={handleDateChange}
        onOpenDailyUpdate={() => setIsDailyUpdateOpen(true)}
        onOpenAiReport={() => setIsAiReportOpen(true)}
        onOpenArchive={() => setIsArchiveOpen(true)}
        onOpenKpiAdmin={() => setIsKpiAdminOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-grow max-w-[1700px] w-full mx-auto p-3 md:p-4 space-y-4">
        {/* Summary Cards */}
        <SummaryCards
          totalUnits={summary.computedList.length}
          greenCount={summary.greenUnitsCount}
          greenPercent={summary.greenPercent}
          yellowCount={summary.yellowUnitsCount}
          yellowPercent={summary.yellowPercent}
          redCount={summary.redUnitsCount}
          redPercent={summary.redPercent}
          noDataCount={summary.noDataCount}
          frozenCount={summary.frozenCount}
          overallPercent={summary.overallPct}
          selectedPeriod={appState.selectedPeriod}
          selectedKpiId={appState.selectedKpiId}
        />

        {/* Bản đồ nhiệt trung tâm (Luôn nằm ở trung tâm màn hình, mở rộng tối đa và thoáng đãng) */}
        <div className="w-full">
          <HeatmapMap
            computedList={summary.computedList}
            kpis={appState.kpis}
            selectedKpiId={appState.selectedKpiId}
            mapFilter={appState.mapFilter}
            onSetMapFilter={(f) => persistState({ ...appState, mapFilter: f })}
            mapZoom={appState.mapZoom}
            onSetMapZoom={(z) => persistState({ ...appState, mapZoom: z })}
            onSelectCommune={(stt) => setSelectedCommuneStt(stt)}
            isKioskActive={kioskRunning && kioskStep === 0}
          />
        </div>

        {/* Các mục Top các đơn vị đưa xuống dưới bản đồ */}
        <div className="w-full">
          <Leaderboards
            computedList={summary.computedList}
            selectedKpiId={appState.selectedKpiId}
            onSelectCommune={(stt) => setSelectedCommuneStt(stt)}
            isKioskActive={kioskRunning && kioskStep === 1}
          />
        </div>

        {/* Danh sách 102 xã, phường chi tiết */}
        <div className="w-full">
          <CommuneTable
            computedList={summary.computedList}
            kpis={appState.kpis}
            selectedKpiId={appState.selectedKpiId}
            searchQuery={appState.searchQuery}
            onSearchChange={(q) => persistState({ ...appState, searchQuery: q })}
            tableFilterStatus={appState.tableFilterStatus}
            onFilterStatusChange={(s) => persistState({ ...appState, tableFilterStatus: s })}
            onSelectCommune={(stt) => setSelectedCommuneStt(stt)}
            isKioskActive={kioskRunning && kioskStep === 2}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-red-950 text-amber-200/80 text-center py-2.5 border-t border-amber-600/30 text-xs mt-auto">
        <p className="font-bold">CÔNG AN TỈNH ĐẮK LẮK - PHÒNG CẢNH SÁT QUẢN LÝ HÀNH CHÍNH VỀ TRẬT TỰ XÃ HỘI</p>
        <p className="text-[11px] opacity-75 mt-0.5">
          Bảo lưu mọi quyền © 2026. Phân hệ Giám sát 4 Chỉ tiêu Cư trú & Căn cước trực tuyến.
        </p>
      </footer>

      {/* Sidebar Drawer */}
      <SidebarNav
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onOpenDailyUpdate={() => setIsDailyUpdateOpen(true)}
        onOpenAiReport={() => setIsAiReportOpen(true)}
        onOpenArchive={() => setIsArchiveOpen(true)}
        onOpenKpiAdmin={() => setIsKpiAdminOpen(true)}
        onOpenRankingRules={() => setIsRankingRulesOpen(true)}
      />

      {/* Commune Detail Modal */}
      <CommuneDetailModal
        commune={selectedCommune}
        entry={selectedCommuneStt ? appState.communeData[selectedCommuneStt] : undefined}
        prevEntry={selectedCommuneStt ? previousState?.communeData?.[selectedCommuneStt] : undefined}
        kpis={appState.kpis}
        selectedPeriod={appState.selectedPeriod}
        onSave={handleSaveCommuneDetails}
        onClose={() => setSelectedCommuneStt(null)}
      />

      {/* Daily Update Modal */}
      <DailyUpdateModal
        isOpen={isDailyUpdateOpen}
        selectedDate={selectedDate}
        selectedPeriod={appState.selectedPeriod}
        kpis={appState.kpis}
        communeData={appState.communeData}
        previousCommuneData={previousState?.communeData}
        isProcessingFile={isProcessingFile}
        autoFilledInfo={autoFilledInfo}
        injectedBatch={injectedBatch}
        onOpenAuditPreview={() => setIsCsvPreviewOpen(true)}
        onClearAutoFilledNotice={() => setAutoFilledInfo(null)}
        onBatchSave={handleBatchSaveDaily}
        onFileSelected={handleExcelOrCsvFileSelected}
        onImageSelected={handleImageFileSelected}
        onClose={() => setIsDailyUpdateOpen(false)}
      />

      {/* Preview Modal for Excel/CSV/AI Image */}
      <CsvPreviewModal
        isOpen={isCsvPreviewOpen}
        rows={csvPreviewRows}
        kpis={appState.kpis}
        selectedPeriod={appState.selectedPeriod}
        onUpdateRowValue={(idx, field, val) => {
          setCsvPreviewRows(prev => {
            const next = [...prev];
            next[idx] = {
              ...next[idx],
              kpiValues: { ...next[idx].kpiValues, [field]: val }
            };
            return next;
          });
        }}
        onConfirm={handleConfirmPreviewData}
        onClose={() => setIsCsvPreviewOpen(false)}
      />

      {/* AI Report Modal */}
      <AiReportModal
        isOpen={isAiReportOpen}
        selectedDate={selectedDate}
        selectedKpiId={appState.selectedKpiId}
        kpis={appState.kpis}
        computedList={summary.computedList}
        onClose={() => setIsAiReportOpen(false)}
      />

      {/* Archive Modal */}
      <ArchiveModal
        isOpen={isArchiveOpen}
        selectedDate={selectedDate}
        selectedPeriod={appState.selectedPeriod}
        overallPercent={summary.overallPct}
        computedList={summary.computedList}
        kpis={appState.kpis}
        onOpenSavedDate={handleDateChange}
        onClose={() => setIsArchiveOpen(false)}
      />

      {/* Banner Download Confirmation Modal */}
      <BannerDownloadModal
        isOpen={isBannerDownloadOpen}
        selectedDate={selectedDate}
        bannerRef={bannerRef}
        onClose={() => setIsBannerDownloadOpen(false)}
      />

      {/* KPI Admin Modal */}
      <KpiAdminModal
        isOpen={isKpiAdminOpen}
        selectedDate={selectedDate}
        kpis={appState.kpis}
        onUpdateKpiName={(id, name) => {
          const next = appState.kpis.map(k => (k.id === id ? { ...k, name } : k));
          persistState({ ...appState, kpis: next });
        }}
        onUpdateKpiType={(id, type: KpiType) => {
          const next = appState.kpis.map(k => (k.id === id ? { ...k, type } : k));
          persistState({ ...appState, kpis: next });
        }}
        onUpdateKpiThreshGood={(id, val) => {
          const next = appState.kpis.map(k => (k.id === id ? { ...k, threshGood: val } : k));
          persistState({ ...appState, kpis: next });
        }}
        onUpdateKpiThreshAvg={(id, val) => {
          const next = appState.kpis.map(k => (k.id === id ? { ...k, threshAvg: val } : k));
          persistState({ ...appState, kpis: next });
        }}
        onDeleteKpi={(id) => {
          if (appState.kpis.length <= 1) return;
          const next = appState.kpis.filter(k => k.id !== id);
          const sel = appState.selectedKpiId === id ? 'all' : appState.selectedKpiId;
          persistState({ ...appState, kpis: next, selectedKpiId: sel });
        }}
        onAddNewKpi={(name, type: KpiType, threshGood, threshAvg) => {
          const newId = `kpi_${Date.now()}`;
          const nextKpis = [...appState.kpis, { id: newId, name, shortName: name, type, description: '', threshGood, threshAvg }];
          const updated = { ...appState.communeData };
          OFFICIAL_102_COMMUNES.forEach(c => {
            if (!updated[c.stt]) updated[c.stt] = { stats: {} };
            updated[c.stt].stats[newId] = { giao: 0, da_lam: 0, ngay_hom_nay: 0, reported: false };
          });
          persistState({ ...appState, kpis: nextKpis, communeData: updated });
        }}
        onResetDefaultData={() => {
          const def = createDefaultState(selectedDate);
          persistState(def);
        }}
        onClose={() => setIsKpiAdminOpen(false)}
      />

      {/* Ranking Rules Modal */}
      <RankingRulesModal
        isOpen={isRankingRulesOpen}
        rules={appState.rankingRules}
        onSaveRules={(newRules) => persistState({ ...appState, rankingRules: newRules })}
        onClose={() => setIsRankingRulesOpen(false)}
      />

      {/* Loading overlay for AI / File processing */}
      {isProcessingFile && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col items-center gap-3 border border-amber-500">
            <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
            <p className="font-bold text-sm text-slate-800 dark:text-slate-100">
              Đang phân tích bảng số liệu bằng AI & SheetJS...
            </p>
            <p className="text-xs text-slate-500">Vui lòng chờ trong giây lát</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
