import React from 'react';
import { ComputedCommune, KPI } from '../types';
import { ClipboardList, Search } from 'lucide-react';

interface CommuneTableProps {
  computedList: ComputedCommune[];
  kpis: KPI[];
  selectedKpiId: string;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  tableFilterStatus: 'all' | 'green' | 'yellow' | 'red';
  onFilterStatusChange: (status: 'all' | 'green' | 'yellow' | 'red') => void;
  onSelectCommune: (stt: number) => void;
  isKioskActive?: boolean;
}

export const CommuneTable: React.FC<CommuneTableProps> = ({
  computedList,
  kpis,
  selectedKpiId,
  searchQuery,
  onSearchChange,
  tableFilterStatus,
  onFilterStatusChange,
  onSelectCommune,
  isKioskActive = false
}) => {
  const query = searchQuery.toLowerCase().trim();
  const filtered = computedList.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(query);
    const statusToCheck = selectedKpiId === 'all'
      ? c.computed.overallStatus
      : (c.computed.kpiResults[selectedKpiId]?.status || 'none');
    const matchesStatus = tableFilterStatus === 'all' || statusToCheck === tableFilterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div
      id="kiosk-step-3"
      className={`bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-3 flex flex-col flex-grow ${
        isKioskActive ? 'ring-4 ring-amber-500 rounded-xl' : ''
      }`}
    >
      {/* Table Search & Status Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-200 dark:border-slate-700">
        <h2 className="font-bold text-slate-800 dark:text-slate-100 text-xs sm:text-sm flex items-center gap-1">
          <ClipboardList className="w-4 h-4 text-amber-600" />
          <span>DANH SÁCH 102 XÃ, PHƯỜNG</span>
        </h2>

        <div className="flex flex-wrap items-center gap-1.5">
          {/* Quick Status Filters */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => onFilterStatusChange('all')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                tableFilterStatus === 'all' ? 'bg-amber-600 text-white shadow' : 'hover:bg-slate-200 text-slate-600 dark:text-slate-300'
              }`}
            >
              Tất cả
            </button>
            <button
              type="button"
              onClick={() => onFilterStatusChange('green')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                tableFilterStatus === 'green' ? 'bg-amber-600 text-white shadow' : 'hover:bg-slate-200 text-emerald-600'
              }`}
            >
              🟢 Xanh
            </button>
            <button
              type="button"
              onClick={() => onFilterStatusChange('yellow')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                tableFilterStatus === 'yellow' ? 'bg-amber-600 text-white shadow' : 'hover:bg-slate-200 text-amber-600'
              }`}
            >
              🟡 Vàng
            </button>
            <button
              type="button"
              onClick={() => onFilterStatusChange('red')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                tableFilterStatus === 'red' ? 'bg-amber-600 text-white shadow' : 'hover:bg-slate-200 text-red-600'
              }`}
            >
              🔴 Đỏ
            </button>
          </div>

          {/* Search Input */}
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Tìm tên xã, phường..."
              className="bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded pl-7 pr-2.5 py-1 text-xs outline-none w-36 sm:w-44 font-bold"
            />
          </div>
        </div>
      </div>

      {/* Scrollable Table Container */}
      <div className="max-h-[460px] overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg shadow-inner">
        <table className="w-full text-left border-collapse text-xs">
          <thead className="bg-slate-100 dark:bg-slate-900 sticky top-0 z-20 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700 uppercase font-bold text-[10px] shadow-sm">
            <tr>
              <th className="p-2 text-center w-10 bg-slate-100 dark:bg-slate-900">STT</th>
              <th className="p-2 bg-slate-100 dark:bg-slate-900 min-w-[130px]">Xã / Phường</th>
              {kpis.map((kpi) => (
                <th key={kpi.id} className="p-2 text-center bg-slate-100 dark:bg-slate-900 min-w-[90px]" title={kpi.name}>
                  {kpi.shortName || kpi.name}
                </th>
              ))}
              <th className="p-2 text-center bg-slate-100 dark:bg-slate-900 min-w-[110px]">Đánh giá chung</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-700/60 font-bold">
            {filtered.length > 0 ? (
              filtered.map((item) => {
                const overall = item.computed.overallStatus;
                let overallBadge = 'bg-red-100 text-red-700 border border-red-300';
                let overallLabel = `🔴 Đỏ (${item.computed.greenKpisCount}/${item.computed.totalKpis})`;

                if (overall === 'green') {
                  overallBadge = 'bg-emerald-100 text-emerald-800 border border-emerald-300';
                  overallLabel = `🟢 Xanh (${item.computed.greenKpisCount}/${item.computed.totalKpis})`;
                } else if (overall === 'yellow') {
                  overallBadge = 'bg-amber-100 text-amber-800 border border-amber-300';
                  overallLabel = `🟡 Vàng (${item.computed.greenKpisCount}/${item.computed.totalKpis})`;
                }

                return (
                  <tr
                    key={item.stt}
                    onClick={() => onSelectCommune(item.stt)}
                    className="hover:bg-amber-50 dark:hover:bg-slate-700 cursor-pointer transition"
                  >
                    <td className="p-2 text-center text-slate-400">#{item.stt}</td>
                    <td className="p-2 font-black text-slate-800 dark:text-slate-100">
                      {item.name} {item.computed.isFrozen ? <span title="3+ ngày chưa phát sinh số liệu mới">⚠️</span> : ''}
                    </td>

                    {kpis.map(kpi => {
                      const res = item.computed.kpiResults[kpi.id];
                      let cellColor = 'text-slate-400';
                      let icon = '⚪';
                      if (res) {
                        if (res.status === 'green') {
                          cellColor = 'text-emerald-600 dark:text-emerald-400';
                          icon = '🟢';
                        } else if (res.status === 'yellow') {
                          cellColor = 'text-amber-600 dark:text-amber-400';
                          icon = '🟡';
                        } else if (res.status === 'red') {
                          cellColor = 'text-red-600 dark:text-red-400';
                          icon = '🔴';
                        }
                      }

                      return (
                        <td key={kpi.id} className="p-2 text-center">
                          <span className={`inline-flex items-center gap-1 font-bold text-[11px] ${cellColor}`}>
                            <span>{icon}</span>
                            <span>{res ? res.displayResult : '—'}</span>
                          </span>
                        </td>
                      );
                    })}

                    <td className="p-2 text-center">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-black ${overallBadge}`}>
                        {overallLabel}
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={kpis.length + 3} className="p-4 text-center text-slate-400">
                  Không tìm thấy địa bàn phù hợp.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
