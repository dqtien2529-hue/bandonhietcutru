import React, { useRef, useState, useEffect } from 'react';
import { Menu, Camera, ChevronUp, ChevronDown, Upload } from 'lucide-react';

interface HeaderBannerProps {
  onToggleSidebar: () => void;
  onOpenBannerDownload?: () => void;
  kioskRunning?: boolean;
  onToggleKiosk?: () => void;
  bannerRef?: React.RefObject<HTMLDivElement | null>;
}

const DEFAULT_EMBLEM = '/assets/aistudio/huy-hieu-cand-tach-nen_d0fe6e2f.png';

export const HeaderBanner: React.FC<HeaderBannerProps> = ({
  onToggleSidebar,
  bannerRef
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [customBg, setCustomBg] = useState<string | null>(null);
  const [customEmblem, setCustomEmblem] = useState<string | null>(() => {
    try {
      const saved = localStorage.getItem('daklak_police_emblem');
      return saved || DEFAULT_EMBLEM;
    } catch {
      return DEFAULT_EMBLEM;
    }
  });

  const bannerFileInputRef = useRef<HTMLInputElement>(null);
  const emblemFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (customEmblem) {
      try {
        localStorage.setItem('daklak_police_emblem', customEmblem);
      } catch (e) {
        console.warn('Cannot persist emblem to localStorage:', e);
      }
    }
  }, [customEmblem]);

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCustomBg(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEmblemUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCustomEmblem(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <header
      ref={bannerRef}
      id="header-banner"
      style={customBg ? { backgroundImage: `url('${customBg}')`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}
      className={`relative dong-son-bg-red border-b-4 border-amber-500 shadow-md transition-all duration-300 overflow-hidden flex flex-col justify-start p-2.5 md:px-4 md:py-2.5 ${
        collapsed ? 'min-h-[56px] py-1.5' : 'min-h-[145px] md:min-h-[160px]'
      }`}
    >
      {/* Top Action Bar */}
      <div className="relative z-10 flex justify-between items-center gap-2 mb-1">
        {/* Left Menu Button */}
        <button
          onClick={onToggleSidebar}
          type="button"
          className="bg-white/95 hover:bg-red-50 text-red-950 border border-red-300/80 px-2.5 py-1.5 rounded-xl shadow-sm transition flex items-center gap-1.5 text-xs md:text-sm font-bold cursor-pointer"
        >
          <Menu className="w-4 h-4 md:w-5 md:h-5 text-red-800" />
          <span className="hidden sm:inline">Danh mục</span>
        </button>

        {/* Right Buttons Group (Removed Download and Kiosk buttons per request) */}
        <div className="flex items-center space-x-1.5">
          {/* Thay đổi ảnh nền Banner */}
          <button
            onClick={() => bannerFileInputRef.current?.click()}
            type="button"
            className="bg-white/95 hover:bg-red-50 text-red-950 text-xs font-bold px-2.5 py-1 rounded-lg border border-red-300/80 flex items-center gap-1 shadow-sm transition cursor-pointer"
            title="Tải ảnh nền banner mới"
          >
            <Camera className="w-3.5 h-3.5 text-red-800" />
            <span className="hidden md:inline">Thay ảnh nền</span>
          </button>
          <input
            ref={bannerFileInputRef}
            type="file"
            className="hidden"
            accept="image/*"
            onChange={handleBannerUpload}
          />

          {/* Thu gọn / Mở rộng */}
          <button
            onClick={() => setCollapsed(!collapsed)}
            type="button"
            className="bg-white/95 hover:bg-red-50 text-red-950 p-1.5 rounded-lg border border-red-300/80 shadow-sm transition cursor-pointer"
            title="Thu gọn/Mở rộng Banner"
          >
            {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center Police Emblem & 3-Line Administrative Titles (Pushed higher up) */}
      {!collapsed && (
        <div
          className="relative z-10 flex flex-col items-center justify-center text-center -mt-1 md:-mt-2 mb-1"
          style={{ borderColor: '#7f1d1d' }}
        >
          {/* Khu vực Huy hiệu Công an */}
          <div className="relative group mb-1 flex flex-col items-center">
            <div
              onClick={() => emblemFileInputRef.current?.click()}
              className="relative cursor-pointer transition transform hover:scale-105 active:scale-95"
              title="Nhấp vào để thay đổi Huy hiệu Công an nếu cần"
            >
              <img
                src={customEmblem || DEFAULT_EMBLEM}
                alt="Huy hiệu Công an nhân dân"
                className="w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 lg:w-32 lg:h-32 object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.45)] filter contrast-[1.08] brightness-[1.02] select-none"
                style={{ imageRendering: '-webkit-optimize-contrast' }}
              />

              {/* Hover Overlay Button to Replace Emblem */}
              <div className="absolute inset-0 rounded-full flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition duration-200 bg-black/40 text-white font-bold backdrop-blur-[1px]">
                <Upload className="w-4 h-4 mb-0.5" />
                <span style={{ fontSize: '14px', lineHeight: '17px' }}>Đổi ảnh</span>
              </div>
            </div>

            {/* Input file upload huy hiệu */}
            <input
              ref={emblemFileInputRef}
              type="file"
              className="hidden"
              accept="image/*"
              onChange={handleEmblemUpload}
            />
          </div>

          {/* Dòng 1: CÔNG AN TỈNH ĐẮK LẮK (Chữ trắng) */}
          <h1 className="text-lg md:text-xl lg:text-2xl font-black tracking-tight text-white police-white-title uppercase mb-0.5 leading-tight">
            CÔNG AN TỈNH ĐẮK LẮK
          </h1>

          {/* Dòng 2: PHÒNG CẢNH SÁT QUẢN LÝ HÀNH CHÍNH VỀ TRẬT TỰ XÃ HỘI (Chữ trắng) */}
          <h2 className="text-[11px] md:text-xs lg:text-sm font-black text-white/95 police-white-subtitle uppercase tracking-wide mb-1 leading-tight">
            PHÒNG CẢNH SÁT QUẢN LÝ HÀNH CHÍNH VỀ TRẬT TỰ XÃ HỘI
          </h2>

          {/* Dòng 3: HỆ THỐNG GIÁM SÁT LĨNH VỰC CƯ TRÚ, CĂN CƯỚC (Nền đỏ sẫm chữ trắng viền vàng) */}
          <h3 className="text-xs md:text-sm lg:text-base font-black text-white uppercase tracking-wide bg-red-950/85 backdrop-blur-sm px-4 py-0.5 md:py-1 rounded-full border border-amber-300 shadow-md leading-tight drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            HỆ THỐNG GIÁM SÁT LĨNH VỰC CƯ TRÚ, CĂN CƯỚC
          </h3>
        </div>
      )}
    </header>
  );
};

