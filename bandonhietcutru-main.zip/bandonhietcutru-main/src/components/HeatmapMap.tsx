import React, { useEffect, useRef, useState, useCallback } from 'react';
import { ComputedCommune, KPI } from '../types';
import { STANDALONE_HEATMAP_SVG } from '../data/daklakMapSvg';
import { OFFICIAL_102_COMMUNES, normalizeMapUnitName } from '../data/communes';
import { ZoomIn, ZoomOut, RotateCcw, Map as MapIcon, Maximize2, Minimize2 } from 'lucide-react';

interface HeatmapMapProps {
  computedList: ComputedCommune[];
  kpis: KPI[];
  selectedKpiId: string;
  mapFilter: 'all' | 'green' | 'yellow' | 'red';
  onSetMapFilter: (filter: 'all' | 'green' | 'yellow' | 'red') => void;
  mapZoom: number;
  onSetMapZoom: (zoom: number) => void;
  onSelectCommune: (stt: number) => void;
  isKioskActive?: boolean;
}

interface TooltipData {
  stt: number;
  name: string;
  isFrozen: boolean;
  overallStatus: 'green' | 'yellow' | 'red' | 'none';
  greenCount: number;
  totalKpis: number;
  greenPercent: number;
  kpiDetails: Array<{
    name: string;
    displayInput: string;
    displayResult: string;
    status: 'green' | 'yellow' | 'red' | 'none';
  }>;
  x: number;
  y: number;
}

export const HeatmapMap: React.FC<HeatmapMapProps> = ({
  computedList,
  kpis,
  selectedKpiId,
  mapFilter,
  onSetMapFilter,
  mapZoom,
  onSetMapZoom,
  onSelectCommune,
  isKioskActive = false
}) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [tooltip, setTooltip] = useState<TooltipData | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const activeKpi = kpis.find(k => k.id === selectedKpiId);
  const kpiTitle = activeKpi ? activeKpi.name : '⭐ Tổng hợp 4 chỉ tiêu';

  const computedByStt = useRef(new Map<number, ComputedCommune>());
  useEffect(() => {
    computedByStt.current = new Map(computedList.map(item => [item.stt, item]));
  }, [computedList]);

  const handleTileHover = useCallback((evt: PointerEvent, stt: number) => {
    const item = computedByStt.current.get(stt);
    if (!item) return;

    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();

    let x = evt.clientX - rect.left + 15;
    let y = evt.clientY - rect.top + 15;

    if (x + 300 > rect.width) x -= 310;
    if (y + 240 > rect.height) y -= 250;

    const kpiDetails = kpis.map(k => {
      const res = item.computed.kpiResults[k.id];
      return {
        name: k.shortName || k.name,
        displayInput: res?.displayInput || '—',
        displayResult: res?.displayResult || 'Chưa nhập',
        status: res?.status || 'none'
      };
    });

    setTooltip({
      stt: item.stt,
      name: item.name,
      isFrozen: item.computed.isFrozen,
      overallStatus: item.computed.overallStatus,
      greenCount: item.computed.greenKpisCount,
      totalKpis: item.computed.totalKpis,
      greenPercent: item.computed.greenKpiPercent,
      kpiDetails,
      x: Math.max(10, x),
      y: Math.max(10, y)
    });
  }, [kpis]);

  const handleTileLeave = useCallback(() => {
    setTooltip(null);
  }, []);

  // Initialize SVG once
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    try {
      const parsed = new DOMParser().parseFromString(STANDALONE_HEATMAP_SVG, 'image/svg+xml');
      const map = parsed.documentElement as unknown as SVGSVGElement;
      map.id = 'daklak-heatmap';
      map.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      map.setAttribute('role', 'group');
      map.setAttribute('aria-label', 'Bản đồ nhiệt tương tác 102 xã, phường');
      map.removeAttribute('width');
      map.removeAttribute('height');
      map.style.width = '100%';
      map.style.height = 'auto';
      map.style.maxHeight = '580px';
      map.style.display = 'block';
      map.style.transformOrigin = 'center center';
      map.style.transition = 'transform 0.15s ease';

      const unitsByName = new Map(OFFICIAL_102_COMMUNES.map(unit => [normalizeMapUnitName(unit.name), unit]));
      const paths = Array.from(map.querySelectorAll<SVGPathElement>('.unit'));

      paths.forEach(path => {
        const key = normalizeMapUnitName(
          path.getAttribute('data-name') ||
          path.getAttribute('aria-label') ||
          path.querySelector('title')?.textContent ||
          ''
        );
        const unit = unitsByName.get(key);
        if (!unit) return;

        path.dataset.unitStt = String(unit.stt);
        path.setAttribute('role', 'button');
        path.setAttribute('tabindex', '0');
        path.setAttribute('aria-label', unit.name);
        path.style.cursor = 'pointer';
        path.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';

        path.addEventListener('pointerenter', (e) => handleTileHover(e, unit.stt));
        path.addEventListener('pointermove', (e) => handleTileHover(e, unit.stt));
        path.addEventListener('pointerleave', handleTileLeave);
        path.addEventListener('click', () => onSelectCommune(unit.stt));
        path.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelectCommune(unit.stt);
          }
        });
      });

      host.replaceChildren(map);
      svgRef.current = map;
    } catch (e) {
      console.error('Failed to load heatmap SVG:', e);
      host.innerText = 'Không thể tải bản đồ nhiệt.';
    }
  }, [handleTileHover, handleTileLeave, onSelectCommune]);

  // Update path colors
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;

    svg.style.transform = `scale(${mapZoom})`;

    const colorMap: Record<string, string> = {
      green: '#10b981',
      yellow: '#f59e0b',
      red: '#ef4444',
      none: '#94a3b8'
    };

    const paths = Array.from(svg.querySelectorAll<SVGPathElement>('.unit'));
    paths.forEach(path => {
      const stt = Number(path.dataset.unitStt);
      const item = computedByStt.current.get(stt);
      if (!item) return;

      const currentStatus = selectedKpiId === 'all'
        ? item.computed.overallStatus
        : (item.computed.kpiResults[selectedKpiId]?.status || 'none');

      const fill = colorMap[currentStatus] || '#94a3b8';
      path.setAttribute('fill', fill);
      path.style.fill = fill;

      const matchesFilter = mapFilter === 'all' || currentStatus === mapFilter;
      path.setAttribute('opacity', matchesFilter ? '1' : '0.16');
      path.style.opacity = matchesFilter ? '1' : '0.16';

      if (item.computed.isFrozen) {
        path.style.stroke = '#f87171';
        path.style.strokeWidth = '2.5';
      } else {
        path.style.stroke = '#ffffff';
        path.style.strokeWidth = '0.5';
      }
    });
  }, [computedList, mapFilter, mapZoom, selectedKpiId]);

  return (
    <div
      id="kiosk-step-1"
      className={`bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-3.5 flex flex-col relative transition-all duration-300 ${
        isFullscreen
          ? 'fixed inset-0 z-50 p-4 md:p-6 bg-slate-950/98 backdrop-blur-md overflow-hidden min-h-screen justify-between'
          : 'min-h-[580px] md:min-h-[660px]'
      } ${isKioskActive ? 'ring-4 ring-amber-500' : ''}`}
    >
      {/* Map Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between border-b pb-2 mb-3 border-slate-200 dark:border-slate-700 gap-2">
        <div>
          <h2 className="font-bold text-slate-800 dark:text-slate-100 text-base md:text-lg flex items-center gap-2">
            <MapIcon className="w-5 h-5 text-amber-600" />
            <span>BẢN ĐỒ NHIỆT 102 XÃ, PHƯỜNG</span>
            {isFullscreen && (
              <span className="text-xs bg-amber-600 text-white font-bold px-2 py-0.5 rounded-full">
                Toàn màn hình
              </span>
            )}
          </h2>
          <p className="text-xs text-amber-700 dark:text-amber-400 font-bold">
            Chỉ tiêu: {kpiTitle}
          </p>
        </div>

        {/* Filter Tabs & Zoom Controls & Fullscreen */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="bg-slate-100 dark:bg-slate-900 p-1 rounded-lg flex items-center gap-1 border border-slate-200 dark:border-slate-700 text-xs font-bold">
            <button
              type="button"
              onClick={() => onSetMapFilter('all')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                mapFilter === 'all' ? 'bg-amber-600 text-white shadow font-bold' : 'hover:bg-slate-200 text-slate-600 dark:text-slate-300'
              }`}
            >
              Tất cả
            </button>
            <button
              type="button"
              onClick={() => onSetMapFilter('green')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                mapFilter === 'green' ? 'bg-amber-600 text-white shadow font-bold' : 'hover:bg-slate-200 text-emerald-600'
              }`}
            >
              🟢 Xanh
            </button>
            <button
              type="button"
              onClick={() => onSetMapFilter('yellow')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                mapFilter === 'yellow' ? 'bg-amber-600 text-white shadow font-bold' : 'hover:bg-slate-200 text-amber-600'
              }`}
            >
              🟡 Vàng
            </button>
            <button
              type="button"
              onClick={() => onSetMapFilter('red')}
              className={`px-2 py-0.5 rounded transition cursor-pointer ${
                mapFilter === 'red' ? 'bg-amber-600 text-white shadow font-bold' : 'hover:bg-slate-200 text-red-600'
              }`}
            >
              🔴 Đỏ
            </button>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => onSetMapZoom(Math.min(2.0, mapZoom + 0.15))}
              className="p-1 font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
              title="Phóng to"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onSetMapZoom(Math.max(0.5, mapZoom - 0.15))}
              className="p-1 font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
              title="Thu nhỏ"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onSetMapZoom(1.0)}
              className="p-1 font-bold text-[11px] hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer"
              title="Đặt lại độ phóng"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" />
            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1 font-bold text-xs hover:bg-amber-100 dark:hover:bg-slate-800 rounded cursor-pointer text-amber-600 dark:text-amber-400"
              title={isFullscreen ? 'Thu nhỏ (Thoát toàn màn hình)' : 'Mở rộng toàn màn hình bản đồ'}
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* SVG Heatmap Host */}
      <div className="relative flex-grow flex items-center justify-center bg-[#fffdf2] rounded-xl p-2 overflow-hidden border border-amber-200 shadow-inner">
        <div
          ref={hostRef}
          id="daklak-heatmap-host"
          className={`w-full flex items-center justify-center text-xs font-bold text-slate-500 ${
            isFullscreen ? 'min-h-[80vh]' : 'min-h-[500px] md:min-h-[580px] lg:min-h-[620px]'
          }`}
        >
          Đang tải bản đồ địa bàn…
        </div>

        {/* Floating Tooltip with 4 KPIs */}
        {tooltip && (
          <div
            id="map-tooltip"
            style={{ left: `${tooltip.x}px`, top: `${tooltip.y}px` }}
            className="absolute z-40 bg-slate-900/95 text-white p-3 rounded-xl shadow-2xl border border-amber-500 text-xs w-72 backdrop-blur-md pointer-events-none transition-opacity duration-150 opacity-100"
          >
            <div className="flex items-center justify-between border-b border-slate-700 pb-1 mb-1.5">
              <h4 className="font-bold text-amber-300 text-sm">{tooltip.name}</h4>
              <span className="text-[10px] font-bold bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded">
                STT #{tooltip.stt}
              </span>
            </div>

            <div className="space-y-1.5 my-2">
              {tooltip.kpiDetails.map((kpi, idx) => {
                const icon = kpi.status === 'green' ? '🟢' : kpi.status === 'yellow' ? '🟡' : kpi.status === 'red' ? '🔴' : '⚪';
                return (
                  <div key={idx} className="flex justify-between items-center text-[11px] border-b border-slate-800 pb-0.5">
                    <span className="text-slate-300 truncate max-w-[150px]">{kpi.name}:</span>
                    <span className="font-bold text-right ml-1">
                      {icon} {kpi.displayResult}
                    </span>
                  </div>
                );
              })}
            </div>

            {tooltip.isFrozen && (
              <p className="text-red-400 font-bold mt-1 text-[11px]">⚠️ 3 ngày chưa phát sinh số liệu mới!</p>
            )}

            <div className="mt-2 pt-1.5 border-t border-slate-700 flex justify-between items-center text-xs">
              <span className="text-slate-400">Đánh giá chung:</span>
              <span className="font-bold text-amber-300">{tooltip.greenCount}/{tooltip.totalKpis} Xanh ({tooltip.greenPercent}%)</span>
            </div>

            <div
              className={`mt-1.5 text-center py-1 rounded text-[11px] font-bold uppercase ${
                tooltip.overallStatus === 'green'
                  ? 'bg-emerald-600 text-white'
                  : tooltip.overallStatus === 'yellow'
                  ? 'bg-amber-600 text-white'
                  : 'bg-red-600 text-white'
              }`}
            >
              {tooltip.overallStatus === 'green'
                ? '🟢 Đạt tốt (Toàn bộ Xanh)'
                : tooltip.overallStatus === 'yellow'
                ? '🟡 Trung bình (≥60% Xanh)'
                : '🔴 Chậm / Báo động (<60% Xanh)'}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
