import React from 'react';
import { ComputedCommune } from '../types';
import { Trophy, AlertOctagon } from 'lucide-react';

interface LeaderboardsProps {
  computedList: ComputedCommune[];
  selectedKpiId: string;
  onSelectCommune: (stt: number) => void;
  isKioskActive?: boolean;
}

export const Leaderboards: React.FC<LeaderboardsProps> = ({
  computedList,
  selectedKpiId,
  onSelectCommune,
  isKioskActive = false
}) => {
  const isAllKpis = selectedKpiId === 'all';

  const sortedGood = [...computedList]
    .sort((a, b) => {
      if (isAllKpis) {
        if (b.computed.greenKpiPercent !== a.computed.greenKpiPercent) {
          return b.computed.greenKpiPercent - a.computed.greenKpiPercent;
        }
        return b.computed.greenKpisCount - a.computed.greenKpisCount;
      }
      const valB = b.computed.kpiResults[selectedKpiId]?.percent ?? (b.computed.kpiResults[selectedKpiId]?.status === 'green' ? 100 : 0);
      const valA = a.computed.kpiResults[selectedKpiId]?.percent ?? (a.computed.kpiResults[selectedKpiId]?.status === 'green' ? 100 : 0);
      return valB - valA;
    })
    .slice(0, 10);

  const sortedSlow = [...computedList]
    .sort((a, b) => {
      if (isAllKpis) {
        if (a.computed.greenKpiPercent !== b.computed.greenKpiPercent) {
          return a.computed.greenKpiPercent - b.computed.greenKpiPercent;
        }
        return a.computed.greenKpisCount - b.computed.greenKpisCount;
      }
      const valA = a.computed.kpiResults[selectedKpiId]?.percent ?? (a.computed.kpiResults[selectedKpiId]?.status === 'green' ? 100 : 0);
      const valB = b.computed.kpiResults[selectedKpiId]?.percent ?? (b.computed.kpiResults[selectedKpiId]?.status === 'green' ? 100 : 0);
      return valA - valB;
    })
    .slice(0, 10);

  return (
    <div
      id="kiosk-step-2"
      className={`grid grid-cols-1 sm:grid-cols-2 gap-3 ${isKioskActive ? 'ring-4 ring-amber-500 rounded-xl' : ''}`}
    >
      {/* Top 10 Dẫn đầu (Tốt) */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md border border-emerald-500/40 p-3 flex flex-col h-[260px]">
        <div className="flex items-center justify-between border-b pb-1 mb-2 border-slate-200 dark:border-slate-700">
          <h3 className="font-bold text-xs sm:text-sm text-emerald-600 dark:text-emerald-400 flex items-center gap-1 uppercase">
            <Trophy className="w-4 h-4" />
            <span>TOP 10 DẪN ĐẦU (TỐT)</span>
          </h3>
          <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold px-1.5 py-0.5 rounded">
            {isAllKpis ? '100% Xanh' : 'Đạt chuẩn'}
          </span>
        </div>
        <div className="flex-grow overflow-y-auto space-y-1.5 pr-1 text-xs font-bold">
          {sortedGood.length > 0 ? (
            sortedGood.map((item, rank) => {
              let badge = `#${rank + 1}`;
              if (rank === 0) badge = '🥇';
              else if (rank === 1) badge = '🥈';
              else if (rank === 2) badge = '🥉';

              const displayMetric = isAllKpis
                ? `${item.computed.greenKpisCount}/${item.computed.totalKpis} Xanh (${item.computed.greenKpiPercent}%)`
                : item.computed.kpiResults[selectedKpiId]?.displayResult || '—';

              return (
                <div
                  key={item.stt}
                  onClick={() => onSelectCommune(item.stt)}
                  className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between cursor-pointer transition"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-4 text-center">{badge}</span>
                    <span className="truncate">{item.name}</span>
                  </div>
                  <span className="text-emerald-600 dark:text-emerald-400 whitespace-nowrap text-[11px]">
                    {displayMetric}
                  </span>
                </div>
              );
            })
          ) : (
            <p className="p-3 text-center text-xs text-slate-400">Chưa có dữ liệu để xếp hạng.</p>
          )}
        </div>
      </div>

      {/* Top 10 Cảnh báo (Chậm) */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md border border-red-500/40 p-3 flex flex-col h-[260px]">
        <div className="flex items-center justify-between border-b pb-1 mb-2 border-slate-200 dark:border-slate-700">
          <h3 className="font-bold text-xs sm:text-sm text-red-600 dark:text-red-400 flex items-center gap-1 uppercase">
            <AlertOctagon className="w-4 h-4" />
            <span>TOP 10 BÁO ĐỘNG (CHẬM)</span>
          </h3>
          <span className="text-[10px] bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 font-bold px-1.5 py-0.5 rounded">
            {isAllKpis ? '<60% Xanh' : 'Cần quan tâm'}
          </span>
        </div>
        <div className="flex-grow overflow-y-auto space-y-1.5 pr-1 text-xs font-bold">
          {sortedSlow.length > 0 ? (
            sortedSlow.map((item) => {
              const displayMetric = isAllKpis
                ? `${item.computed.greenKpisCount}/${item.computed.totalKpis} Xanh (${item.computed.greenKpiPercent}%)`
                : item.computed.kpiResults[selectedKpiId]?.displayResult || '—';

              return (
                <div
                  key={item.stt}
                  onClick={() => onSelectCommune(item.stt)}
                  className="p-1.5 rounded-lg bg-red-50 dark:bg-red-950/40 hover:bg-red-100 border border-red-200 dark:border-red-800 flex items-center justify-between cursor-pointer transition"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-4 text-center text-red-600">🚨</span>
                    <span className="truncate">{item.name}</span>
                  </div>
                  <span className="text-red-600 dark:text-red-400 whitespace-nowrap text-[11px]">
                    {displayMetric}
                  </span>
                </div>
              );
            })
          ) : (
            <p className="p-3 text-center text-xs text-slate-400">Chưa có dữ liệu để xếp hạng.</p>
          )}
        </div>
      </div>
    </div>
  );
};
