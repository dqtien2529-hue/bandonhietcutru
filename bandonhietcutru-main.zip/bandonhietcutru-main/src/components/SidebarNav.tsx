import React from 'react';
import { X, LayoutDashboard, Edit3, FileText, FolderArchive, Settings, Sliders, Lock, Unlock, KeyRound, LogOut } from 'lucide-react';

interface SidebarNavProps {
  isOpen: boolean;
  onClose: () => void;
  isAdmin: boolean;
  onOpenDailyUpdate: () => void;
  onOpenAiReport: () => void;
  onOpenArchive: () => void;
  onOpenKpiAdmin: () => void;
  onOpenRankingRules: () => void;
  onOpenLoginModal: () => void;
  onOpenPasswordSettings: () => void;
  onLogoutAdmin: () => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  isOpen,
  onClose,
  isAdmin,
  onOpenDailyUpdate,
  onOpenAiReport,
  onOpenArchive,
  onOpenKpiAdmin,
  onOpenRankingRules,
  onOpenLoginModal,
  onOpenPasswordSettings,
  onLogoutAdmin
}) => {
  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/50 z-40 backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Drawer */}
      <div
        id="sidebar-nav"
        className={`fixed inset-y-0 left-0 w-72 bg-slate-900 text-white z-50 transform transition-transform duration-300 ease-in-out shadow-2xl border-r border-amber-500/30 flex flex-col justify-between ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 space-y-4 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-700 pb-3">
            <div>
              <h3 className="font-bold text-amber-400 text-sm uppercase tracking-wide">DANH MỤC HỆ THỐNG</h3>
              <p className="text-[10px] text-slate-400">
                {isAdmin ? 'Quyền: Quản trị viên (Đã mở khóa)' : 'Quyền: Xem công khai (Khách)'}
              </p>
            </div>
            <button
              onClick={onClose}
              type="button"
              className="text-slate-400 hover:text-white text-xl font-bold p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Menu */}
          <nav className="space-y-1.5 text-xs font-bold">
            {/* Always visible: Tổng quan Bảng điều khiển */}
            <button
              type="button"
              onClick={onClose}
              className="w-full text-left p-2.5 rounded bg-amber-600 text-white flex items-center gap-2 cursor-pointer shadow"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Tổng quan Màn hình chính</span>
            </button>

            {/* Always visible: Quy tắc xếp loại & Đánh giá */}
            <button
              type="button"
              onClick={() => {
                onOpenRankingRules();
                onClose();
              }}
              className="w-full text-left p-2.5 rounded hover:bg-slate-800 text-slate-300 flex items-center gap-2 cursor-pointer transition border border-slate-800 hover:border-slate-700"
            >
              <Sliders className="w-4 h-4 text-emerald-400" />
              <span>Quy tắc xếp loại & Đánh giá</span>
            </button>

            {/* Admin-only items: Nhập số liệu, Dự thảo, Kho lưu, Cài đặt */}
            {isAdmin ? (
              <>
                <div className="pt-2 pb-1 text-[11px] font-bold text-amber-400/90 uppercase tracking-wider flex items-center gap-1 border-t border-slate-800 mt-2">
                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Chức năng Quản trị & Nhập liệu</span>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onOpenDailyUpdate();
                    onClose();
                  }}
                  className="w-full text-left p-2.5 rounded hover:bg-slate-800 text-slate-200 flex items-center gap-2 cursor-pointer transition bg-slate-800/60 border border-amber-600/30"
                >
                  <Edit3 className="w-4 h-4 text-amber-400" />
                  <span>Cập nhật số liệu 4 chỉ tiêu</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onOpenAiReport();
                    onClose();
                  }}
                  className="w-full text-left p-2.5 rounded hover:bg-slate-800 text-slate-200 flex items-center gap-2 cursor-pointer transition bg-slate-800/60 border border-slate-700"
                >
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <span>Dự thảo văn bản báo cáo</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onOpenArchive();
                    onClose();
                  }}
                  className="w-full text-left p-2.5 rounded hover:bg-slate-800 text-slate-200 flex items-center gap-2 cursor-pointer transition bg-slate-800/60 border border-slate-700"
                >
                  <FolderArchive className="w-4 h-4 text-amber-400" />
                  <span>Kho lưu trữ & Xuất Excel</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onOpenKpiAdmin();
                    onClose();
                  }}
                  className="w-full text-left p-2.5 rounded hover:bg-slate-800 text-slate-200 flex items-center gap-2 cursor-pointer transition bg-slate-800/60 border border-slate-700"
                >
                  <Settings className="w-4 h-4 text-slate-300" />
                  <span>Cài đặt Chỉ tiêu & Tiêu chí</span>
                </button>

                {/* Password Setting & Logout */}
                <div className="pt-2 border-t border-slate-800 space-y-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onOpenPasswordSettings();
                      onClose();
                    }}
                    className="w-full text-left p-2 rounded hover:bg-slate-800 text-amber-300 flex items-center gap-2 cursor-pointer transition border border-amber-500/20"
                  >
                    <KeyRound className="w-4 h-4 text-amber-400" />
                    <span>Cài đặt Mật khẩu Quản trị</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onLogoutAdmin();
                      onClose();
                    }}
                    className="w-full text-left p-2 rounded hover:bg-red-950/60 text-red-400 flex items-center gap-2 cursor-pointer transition border border-red-500/20"
                  >
                    <LogOut className="w-4 h-4 text-red-400" />
                    <span>Khóa quyền Quản trị (Thoát)</span>
                  </button>
                </div>
              </>
            ) : (
              /* Non-Admin Locked View */
              <div className="pt-3 border-t border-slate-800 space-y-2.5">
                <div className="p-3 bg-slate-800/90 rounded-xl border border-slate-700 text-slate-300 text-xs space-y-2">
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold">
                    <Lock className="w-4 h-4" />
                    <span>Phân quyền bảo mật</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Các mục <strong className="text-slate-200">Nhập số liệu, Dự thảo, Kho lưu, Cài đặt</strong> đã được ẩn đối với khách truy cập để đảm bảo tính an toàn dữ liệu.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      onOpenLoginModal();
                      onClose();
                    }}
                    className="w-full py-2 px-3 bg-gradient-to-r from-red-800 to-red-700 hover:from-red-700 hover:to-red-600 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 shadow transition cursor-pointer border border-amber-500/40"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-amber-300" />
                    <span>Mở khóa Quản trị / Nhập liệu</span>
                  </button>
                  <p className="text-[10px] text-slate-500 text-center italic">
                    Mật khẩu mặc định: <span className="font-mono font-bold text-amber-400">775593</span>
                  </p>
                </div>
              </div>
            )}
          </nav>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 text-center font-bold">
          Công an tỉnh Đắk Lắk © 2026
        </div>
      </div>
    </>
  );
};

