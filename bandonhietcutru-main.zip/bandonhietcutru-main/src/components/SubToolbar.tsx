import React from 'react';
import { KPI } from '../types';
import { formatDDMMYYYY, getAdjacentDate, formatDateYMD } from '../data/communes';
import { Calendar, FileSpreadsheet, Settings, FileText, Edit, ChevronLeft, ChevronRight, Lock, KeyRound } from 'lucide-react';

interface SubToolbarProps {
  syncMessage: string;
  syncConnected: boolean;
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  onSetPeriod: (p: 'day' | 'month' | 'quarter' | 'year') => void;
  kpis: KPI[];
  selectedKpiId: string;
  onSelectKpi: (id: string) => void;
  selectedDate: string;
  onDateChange: (date: string) => void;
  isAdmin: boolean;
  onOpenLoginModal: () => void;
  onOpenDailyUpdate: () => void;
  onOpenAiReport: () => void;
  onOpenArchive: () => void;
  onOpenKpiAdmin: () => void;
}

export const SubToolbar: React.FC<SubToolbarProps> = ({
  syncMessage,
  syncConnected,
  selectedPeriod,
  onSetPeriod,
  kpis,
  selectedKpiId,
  onSelectKpi,
  selectedDate,
  onDateChange,
  isAdmin,
  onOpenLoginModal,
  onOpenDailyUpdate,
  onOpenAiReport,
  onOpenArchive,
  onOpenKpiAdmin
}) => {
  const handlePrevDay = () => {
    onDateChange(getAdjacentDate(selectedDate, -1));
  };

  const handleNextDay = () => {
    onDateChange(getAdjacentDate(selectedDate, 1));
  };

  const handleToday = () => {
    onDateChange(formatDateYMD(new Date()));
  };

  return (
    <div className="bg-red-900 border-b border-amber-600/40 text-white px-3 py-2.5 shadow-lg flex flex-wrap items-center justify-between gap-3 text-sm">
      {/* Live Status Indicator */}
      <div className="flex items-center gap-2 font-bold tracking-wide text-amber-200">
        <span
          className={`w-3 h-3 rounded-full ${
            syncConnected ? 'bg-emerald-400 shadow-[0_0_8px_#34d399] live-dot' : 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
          }`}
        />
        <span className="uppercase text-xs sm:text-sm font-black">GIÁM SÁT TRỰC TUYẾN 4 CHỈ TIÊU CƯ TRÚ</span>
        <span className="text-[10px] sm:text-xs text-amber-100 font-normal">
          {syncMessage || 'Lưu trên trình duyệt • đồng bộ giữa các tab'}
        </span>
      </div>

      {/* Controls Group */}
      <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
        {/* Report Period Switcher: Ngày, Tháng, Quý, Năm (Không có tuần) */}
        <div className="flex items-center gap-1 bg-red-950/90 px-2 py-1 rounded-lg border border-amber-500/50">
          <span className="text-amber-300 font-bold text-xs">Kỳ:</span>
          <button
            type="button"
            onClick={() => onSetPeriod('day')}
            className={`px-2 py-0.5 rounded text-xs font-bold transition cursor-pointer ${
              selectedPeriod === 'day' ? 'bg-amber-600 text-white shadow' : 'hover:bg-red-800 text-amber-200'
            }`}
          >
            Ngày
          </button>
          <button
            type="button"
            onClick={() => onSetPeriod('month')}
            className={`px-2 py-0.5 rounded text-xs font-bold transition cursor-pointer ${
              selectedPeriod === 'month' ? 'bg-amber-600 text-white shadow' : 'hover:bg-red-800 text-amber-200'
            }`}
          >
            Tháng
          </button>
          <button
            type="button"
            onClick={() => onSetPeriod('quarter')}
            className={`px-2 py-0.5 rounded text-xs font-bold transition cursor-pointer ${
              selectedPeriod === 'quarter' ? 'bg-amber-600 text-white shadow' : 'hover:bg-red-800 text-amber-200'
            }`}
          >
            Quý
          </button>
          <button
            type="button"
            onClick={() => onSetPeriod('year')}
            className={`px-2 py-0.5 rounded text-xs font-bold transition cursor-pointer ${
              selectedPeriod === 'year' ? 'bg-amber-600 text-white shadow' : 'hover:bg-red-800 text-amber-200'
            }`}
          >
            Năm
          </button>
        </div>

        {/* Date Selector with Next/Prev and Quick-Today */}
        <div className="flex items-center gap-1 bg-red-950/90 px-2 py-1 rounded-lg border border-amber-500/50">
          <button
            type="button"
            onClick={handlePrevDay}
            className="p-1 hover:bg-red-800 text-amber-200 rounded cursor-pointer transition"
            title="Ngày trước"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <Calendar className="w-3.5 h-3.5 text-amber-300" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => onDateChange(e.target.value)}
            className="bg-red-900 text-white font-bold text-xs rounded px-1 py-0.5 outline-none border border-red-700 cursor-pointer"
          />

          <button
            type="button"
            onClick={handleNextDay}
            className="p-1 hover:bg-red-800 text-amber-200 rounded cursor-pointer transition"
            title="Ngày sau"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={handleToday}
            className="text-[10px] font-bold bg-amber-700/80 hover:bg-amber-600 text-white px-1.5 py-0.5 rounded cursor-pointer transition"
            title="Trở về hôm nay"
          >
            Hôm nay
          </button>

          <span className="text-amber-200 font-bold text-xs bg-red-900 px-1.5 py-0.5 rounded border border-red-700">
            {formatDDMMYYYY(selectedDate)}
          </span>
        </div>

        {/* KPI Selector Dropdown */}
        <div className="flex items-center gap-1 bg-red-950/90 px-2 py-1 rounded-lg border border-amber-500/50">
          <span className="text-amber-300 font-bold text-xs">Chỉ tiêu:</span>
          <select
            value={selectedKpiId}
            onChange={(e) => onSelectKpi(e.target.value)}
            className="bg-red-900 text-white font-bold text-xs rounded px-2 py-1 outline-none border border-red-700 max-w-[210px] truncate cursor-pointer"
          >
            <option value="all">⭐ Tổng hợp 4 chỉ tiêu</option>
            {kpis.map((kpi) => (
              <option key={kpi.id} value={kpi.id}>
                {kpi.name}
              </option>
            ))}
          </select>
        </div>

        {/* Action Buttons Bar - Only visible when Admin is authenticated */}
        {isAdmin ? (
          <div className="flex items-center gap-1.5 animate-in fade-in">
            <button
              type="button"
              onClick={onOpenDailyUpdate}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 shadow transition text-xs border border-amber-300 cursor-pointer"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>Nhập số liệu ngày</span>
            </button>

            <button
              type="button"
              onClick={onOpenAiReport}
              className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 shadow transition text-xs border border-emerald-400 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Dự thảo báo cáo</span>
            </button>

            <button
              type="button"
              onClick={onOpenArchive}
              className="bg-red-800 hover:bg-red-700 text-amber-200 font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 shadow transition text-xs border border-amber-400 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Kho lưu & Xuất Excel</span>
            </button>

            <button
              type="button"
              onClick={onOpenKpiAdmin}
              className="bg-red-800 hover:bg-red-700 text-amber-200 font-bold p-1 rounded-lg shadow transition text-xs border border-amber-400 cursor-pointer"
              title="Cấu hình chỉ tiêu & Tiêu chí"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenLoginModal}
              className="bg-red-950 hover:bg-red-900 text-amber-300 font-bold px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow transition text-xs border border-amber-500/50 cursor-pointer"
              title="Đăng nhập quản trị để mở khóa nhập số liệu, dự thảo, kho lưu, cài đặt"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Nhập số liệu (Khóa)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
