import React from 'react';
import { Building2, CheckCircle2, AlertTriangle, AlertOctagon, TrendingUp } from 'lucide-react';

interface SummaryCardsProps {
  totalUnits: number;
  greenCount: number;
  greenPercent: string;
  yellowCount: number;
  yellowPercent: string;
  redCount: number;
  redPercent: string;
  noDataCount: number;
  frozenCount: number;
  overallPercent: string;
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  selectedKpiId: string;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({
  totalUnits,
  greenCount,
  greenPercent,
  yellowCount,
  yellowPercent,
  redCount,
  redPercent,
  noDataCount,
  frozenCount,
  overallPercent,
  selectedPeriod,
  selectedKpiId
}) => {
  const periodLabels = {
    day: 'Hôm nay / Theo ngày',
    month: 'Tháng này',
    quarter: 'Quý này',
    year: 'Năm này'
  };

  const isAllKpis = selectedKpiId === 'all';

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {/* Total Units */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-md border-l-4 border-blue-600 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">Tổng số đơn vị</p>
          <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100">{totalUnits}</h3>
          <p className="text-[11px] text-slate-400 font-semibold">{totalUnits} Xã / Phường trực thuộc</p>
        </div>
        <div className="w-9 h-9 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center text-blue-600 font-bold">
          <Building2 className="w-5 h-5" />
        </div>
      </div>

      {/* Good / Green */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-md border-l-4 border-emerald-500 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase text-emerald-600 dark:text-emerald-400">
            🟢 Đạt tốt {isAllKpis ? '(100% Xanh)' : '(Đạt chuẩn)'}
          </p>
          <div className="flex items-baseline gap-1.5">
            <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{greenCount}</h3>
            <span className="text-xs font-bold text-emerald-500">({greenPercent}%)</span>
          </div>
          <p className="text-[11px] text-slate-400 font-semibold">
            {isAllKpis ? 'Đạt toàn bộ các chỉ tiêu' : 'Đạt ngưỡng chỉ tiêu chọn'}
          </p>
        </div>
        <div className="w-9 h-9 bg-emerald-100 dark:bg-emerald-900/40 rounded-full flex items-center justify-center text-emerald-600">
          <CheckCircle2 className="w-5 h-5" />
        </div>
      </div>

      {/* Average / Yellow */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-md border-l-4 border-amber-500 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase text-amber-600 dark:text-amber-400">
            🟡 Trung bình {isAllKpis ? '(60%–<100%)' : '(Chuyển biến)'}
          </p>
          <div className="flex items-baseline gap-1.5">
            <h3 className="text-2xl font-black text-amber-600 dark:text-amber-400">{yellowCount}</h3>
            <span className="text-xs font-bold text-amber-500">({yellowPercent}%)</span>
          </div>
          <p className="text-[11px] text-slate-400 font-semibold">Cần đôn đốc thêm tiến độ</p>
        </div>
        <div className="w-9 h-9 bg-amber-100 dark:bg-amber-900/40 rounded-full flex items-center justify-center text-amber-600">
          <AlertTriangle className="w-5 h-5" />
        </div>
      </div>

      {/* Slow / Red */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-md border-l-4 border-red-600 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase text-red-600 dark:text-red-400">
            🔴 Chậm / Báo động {isAllKpis ? '(<60% Xanh)' : '(Không đạt)'}
          </p>
          <div className="flex items-baseline gap-1.5">
            <h3 className="text-2xl font-black text-red-600 dark:text-red-400">{redCount}</h3>
            <span className="text-xs font-bold text-red-500">({redPercent}%)</span>
          </div>
          <p className="text-[11px] text-slate-400 font-semibold">
            Chưa có số liệu: <span className="text-slate-600 font-bold">{noDataCount}</span> · Đóng băng: <span className="text-red-600 font-bold">{frozenCount} ⚠️</span>
          </p>
        </div>
        <div className="w-9 h-9 bg-red-100 dark:bg-red-900/40 rounded-full flex items-center justify-center text-red-600">
          <AlertOctagon className="w-5 h-5" />
        </div>
      </div>

      {/* Overall Provincial Status */}
      <div className="col-span-2 md:col-span-1 bg-gradient-to-br from-red-900 to-amber-900 text-white p-3 rounded-xl shadow-md border-l-4 border-amber-400 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase text-amber-300">Tỷ lệ hoàn thành toàn tỉnh</p>
          <h3 className="text-2xl font-black text-white">{overallPercent}</h3>
          <p className="text-[11px] text-amber-200/80">Kỳ: {periodLabels[selectedPeriod]}</p>
        </div>
        <div className="w-9 h-9 bg-amber-500/30 rounded-full flex items-center justify-center text-amber-300 font-bold">
          <TrendingUp className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
