import React, { useState } from 'react';
import { Lock, KeyRound, X, ShieldCheck, AlertCircle } from 'lucide-react';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthenticate: (password: string) => boolean;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onAuthenticate
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setError('Vui lòng nhập mật khẩu quản trị');
      return;
    }

    const success = onAuthenticate(password.trim());
    if (success) {
      setPassword('');
      setError(null);
      onClose();
    } else {
      setError('Mật khẩu không chính xác. Mật khẩu mặc định là 775593.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border-2 border-red-700/80 max-w-md w-full overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-900 text-white p-4 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500 text-red-950 rounded-xl shadow">
              <KeyRound className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="font-black text-sm uppercase tracking-wide text-amber-300">
                Xác thực Quyền Quản trị
              </h3>
              <p className="text-[11px] text-amber-100/90">
                Mở khóa phân hệ Nhập liệu & Cài đặt hệ thống
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setError(null);
              setPassword('');
              onClose();
            }}
            type="button"
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/50 rounded-xl p-3 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Chế độ phân quyền dữ liệu</p>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                Chế độ xem chung chỉ cho phép xem màn hình giám sát. Cần nhập mật khẩu quản trị để mở khóa các chức năng: <span className="font-semibold text-red-700 dark:text-red-400">Nhập số liệu, Dự thảo văn bản, Kho lưu trữ và Quản lý chỉ tiêu</span>.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Mật khẩu Quản trị viên:
            </label>
            <div className="relative">
              <input
                type="password"
                autoFocus
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Nhập mật khẩu (Mặc định: 775593)..."
                className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-mono tracking-wider focus:outline-none focus:border-red-600 dark:focus:border-red-500 transition text-slate-900 dark:text-white"
              />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 italic">
              * Ghi chú: Mật khẩu mặc định ban đầu là <strong className="text-amber-600 dark:text-amber-400 font-bold font-mono">775593</strong>.
            </p>
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-950/60 border border-red-300 dark:border-red-700 rounded-xl p-2.5 text-xs text-red-700 dark:text-red-300 flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Footer buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                setError(null);
                setPassword('');
                onClose();
              }}
              className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gradient-to-r from-red-700 to-red-800 hover:from-red-600 hover:to-red-700 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition cursor-pointer border border-amber-400/40"
            >
              <ShieldCheck className="w-4 h-4 text-amber-300" />
              <span>Mở khóa Quản trị</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
