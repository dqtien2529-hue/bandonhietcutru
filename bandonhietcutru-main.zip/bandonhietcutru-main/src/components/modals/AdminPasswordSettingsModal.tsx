import React, { useState } from 'react';
import { KeyRound, X, CheckCircle2, AlertCircle, RotateCcw } from 'lucide-react';

interface AdminPasswordSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSavedPassword: string;
  onUpdatePassword: (oldPass: string, newPass: string) => { success: boolean; message: string };
  onResetToDefault: () => void;
}

export const AdminPasswordSettingsModal: React.FC<AdminPasswordSettingsModalProps> = ({
  isOpen,
  onClose,
  currentSavedPassword,
  onUpdatePassword,
  onResetToDefault
}) => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!oldPassword.trim()) {
      setStatusMessage({ type: 'error', text: 'Vui lòng nhập mật khẩu hiện tại' });
      return;
    }

    if (!newPassword.trim()) {
      setStatusMessage({ type: 'error', text: 'Vui lòng nhập mật khẩu mới' });
      return;
    }

    if (newPassword.trim().length < 4) {
      setStatusMessage({ type: 'error', text: 'Mật khẩu mới phải có ít nhất 4 ký tự' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setStatusMessage({ type: 'error', text: 'Mật khẩu xác nhận không khớp' });
      return;
    }

    const res = onUpdatePassword(oldPassword.trim(), newPassword.trim());
    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => {
        onClose();
        setStatusMessage(null);
      }, 1500);
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  const handleReset = () => {
    if (window.confirm('Bạn có chắc muốn đặt lại mật khẩu về mặc định (775593)?')) {
      onResetToDefault();
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setStatusMessage({ type: 'success', text: 'Đã đặt lại mật khẩu quản trị về mặc định: 775593' });
      setTimeout(() => {
        onClose();
        setStatusMessage(null);
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border-2 border-amber-600/80 max-w-md w-full overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-900 text-white p-4 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500 text-red-950 rounded-xl shadow">
              <KeyRound className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="font-black text-sm uppercase tracking-wide text-amber-300">
                Cài đặt Mật khẩu Quản trị
              </h3>
              <p className="text-[11px] text-amber-100/90">
                Thay đổi mật khẩu mở khóa phân hệ nhập liệu
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setStatusMessage(null);
              onClose();
            }}
            type="button"
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Mật khẩu hiện tại:
            </label>
            <input
              type="password"
              value={oldPassword}
              onChange={(e) => setOldPassword(e.target.value)}
              placeholder="Nhập mật khẩu đang dùng..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-amber-500 transition text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Mật khẩu mới:
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Nhập mật khẩu mới (tối thiểu 4 ký tự)..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-amber-500 transition text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Xác nhận mật khẩu mới:
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Nhập lại mật khẩu mới..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-amber-500 transition text-slate-900 dark:text-white"
            />
          </div>

          {statusMessage && (
            <div
              className={`rounded-xl p-2.5 text-xs flex items-center gap-2 animate-in fade-in ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300'
                  : 'bg-red-50 dark:bg-red-950/60 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-300'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={handleReset}
              className="text-[11px] font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer transition hover:underline"
              title="Đặt lại về mật khẩu mặc định 775593"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Khôi phục 775593</span>
            </button>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
              >
                Đóng
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl shadow transition cursor-pointer"
              >
                Lưu mật khẩu mới
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
