import React, { useState } from 'react';
import { KPI, ComputedCommune } from '../../types';
import { formatDDMMYYYY } from '../../data/communes';
import { X, Copy, Check, FileText } from 'lucide-react';

interface AiReportModalProps {
  isOpen: boolean;
  selectedDate: string;
  selectedKpiId: string;
  kpis: KPI[];
  computedList: ComputedCommune[];
  onClose: () => void;
}

export const AiReportModal: React.FC<AiReportModalProps> = ({
  isOpen,
  selectedDate,
  selectedKpiId,
  kpis,
  computedList,
  onClose
}) => {
  const [reportText, setReportText] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleGenerateReport = () => {
    const greenUnits = computedList.filter(item => item.computed.overallStatus === 'green');
    const yellowUnits = computedList.filter(item => item.computed.overallStatus === 'yellow');
    const redUnits = computedList.filter(item => item.computed.overallStatus === 'red');
    const totalUnits = computedList.length;

    const leaders = [...computedList]
      .sort((a, b) => b.computed.greenKpiPercent - a.computed.greenKpiPercent)
      .slice(0, 5);
    const slow = [...computedList]
      .sort((a, b) => a.computed.greenKpiPercent - b.computed.greenKpiPercent)
      .slice(0, 5);

    const leaderText = leaders.map(item => `${item.name} (${item.computed.greenKpisCount}/${item.computed.totalKpis} chỉ tiêu xanh - ${item.computed.greenKpiPercent}%)`).join('; ');
    const slowText = slow.map(item => `${item.name} (${item.computed.greenKpisCount}/${item.computed.totalKpis} chỉ tiêu xanh - ${item.computed.greenKpiPercent}%)`).join('; ');

    const text = `CÔNG AN TỈNH ĐẮK LẮK
PHÒNG CẢNH SÁT QUẢN LÝ HÀNH CHÍNH VỀ TRẬT TỰ XÃ HỘI

DỰ THẢO BÁO CÁO TIẾN ĐỘ THỰC HIỆN CÁC CHỈ TIÊU CƯ TRÚ, CĂN CƯỚC
Ngày báo cáo: ${formatDDMMYYYY(selectedDate)}
Địa bàn theo dõi: 102 xã, phường trực thuộc

I. TÌNH HÌNH TIẾN ĐỘ TỔNG THỂ
Toàn tỉnh có ${totalUnits} xã, phường được theo dõi 4 chỉ tiêu trọng tâm:
1. Đơn vị đạt tốt (Đạt 100% chỉ tiêu xanh): ${greenUnits.length}/${totalUnits} đơn vị (${((greenUnits.length / totalUnits) * 100).toFixed(1)}%).
2. Đơn vị trung bình (Đạt từ 60% đến dưới 100% chỉ tiêu xanh): ${yellowUnits.length}/${totalUnits} đơn vị (${((yellowUnits.length / totalUnits) * 100).toFixed(1)}%).
3. Đơn vị chậm / có hồ sơ quá hạn (Đạt dưới 60% chỉ tiêu xanh): ${redUnits.length}/${totalUnits} đơn vị (${((redUnits.length / totalUnits) * 100).toFixed(1)}%).

II. KẾT QUẢ ĐÁNH GIÁ THEO 4 CHỈ TIÊU CHUYÊN MÔN
- Chỉ tiêu 1 (Định danh điện tử VNeID mức 2): Tỷ lệ kích hoạt/thu nhận đạt ngưỡng chuẩn ≥90%.
- Chỉ tiêu 2 (Hồ sơ quá hạn): Theo dõi sát số hồ sơ phát sinh trong ngày và số ngày phát sinh trong tháng để không vượt quá 4 ngày.
- Chỉ tiêu 3 (Làm sạch dữ liệu dân cư): Đánh giá mức độ chuyển biến giảm số trường hợp còn phải làm so với lần nhập trước (giảm >50% là Xanh, ≤50% là Vàng, không giảm là Đỏ).
- Chỉ tiêu 4 (Số hóa tàng thư cư trú): Tính kết quả trong ngày bằng lũy kế hiện tại trừ ngày trước, đối chiếu với chỉ tiêu ngày được giao.

III. CÁC ĐƠN VỊ CẦN QUAN TÂM ĐÔN ĐỐC
${slowText}

IV. CÁC ĐƠN VỊ CÓ KẾT QUẢ TỐT DẪN ĐẦU
${leaderText}

V. ĐỀ XUẤT, KIẾN NGHỊ
1. Trưởng Công an các xã, phường chỉ đạo cán bộ phụ trách rà soát ngay các hồ sơ có nguy cơ quá hạn, khẩn trương hoàn thành dứt điểm hồ sơ cư trú phát sinh trong ngày.
2. Đẩy mạnh công tác làm sạch dữ liệu và số hóa tàng thư theo đúng chỉ tiêu ngày được giao.
3. Báo cáo này là dự thảo tổng hợp tự động từ hệ thống giám sát cơ sở dữ liệu dùng chung; đề nghị lãnh đạo đơn vị kiểm tra, rà soát trước khi phê duyệt ban hành chính thức.`;

    setReportText(text);
  };

  const handleCopy = () => {
    if (!reportText) return;
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-3xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📝</span>
            <div>
              <h3 className="text-base font-bold text-amber-200 uppercase">TẠO DỰ THẢO BÁO CÁO TỪ SỐ LIỆU</h3>
              <p className="text-xs text-amber-100">Tổng hợp dữ liệu đã lưu của {computedList.length} đơn vị theo ngày báo cáo</p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action bar */}
        <div className="p-3 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleGenerateReport}
            className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-4 py-1.5 rounded-lg text-xs shadow flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Tạo dự thảo từ số liệu</span>
          </button>
          <button
            type="button"
            onClick={handleCopy}
            disabled={!reportText}
            className={`font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 cursor-pointer ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-700 hover:bg-slate-600 text-white disabled:opacity-50 disabled:cursor-not-allowed'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Đã sao chép!' : 'Sao chép văn bản'}</span>
          </button>
        </div>

        {/* Content Box */}
        <div className="p-4 overflow-y-auto flex-grow">
          <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-700 font-mono text-xs whitespace-pre-wrap min-h-[320px] text-slate-800 dark:text-slate-100 select-text leading-relaxed">
            {reportText || 'Bấm nút "Tạo dự thảo từ số liệu" để tự động soạn văn bản báo cáo theo mẫu Công an tỉnh Đắk Lắk.'}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-end items-center border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            type="button"
            className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-1.5 rounded-lg text-xs cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
