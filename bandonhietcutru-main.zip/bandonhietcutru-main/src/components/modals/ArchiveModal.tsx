import React from 'react';
import { getSavedDates, readDateRecord } from '../../utils/storage';
import { formatDDMMYYYY } from '../../data/communes';
import { ComputedCommune, KPI } from '../../types';
import * as XLSX from 'xlsx';
import { X, FileSpreadsheet, Calendar, Download } from 'lucide-react';

interface ArchiveModalProps {
  isOpen: boolean;
  selectedDate: string;
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  overallPercent: string;
  computedList: ComputedCommune[];
  kpis: KPI[];
  onOpenSavedDate: (date: string) => void;
  onClose: () => void;
}

export const ArchiveModal: React.FC<ArchiveModalProps> = ({
  isOpen,
  selectedDate,
  selectedPeriod,
  overallPercent,
  computedList,
  kpis,
  onOpenSavedDate,
  onClose
}) => {
  if (!isOpen) return null;

  const dates = getSavedDates().sort().reverse();
  const historyRecords = dates.map(date => {
    const rec = readDateRecord(date);
    return {
      date,
      updated_at: rec?.updated_at || new Date().toISOString()
    };
  });

  const handleExportExcelMultiSheet = () => {
    const workbook = XLSX.utils.book_new();

    // 1. Sheet 1: Trang tổng hợp (TrangTongHop)
    const greenUnits = computedList.filter(c => c.computed.overallStatus === 'green').length;
    const yellowUnits = computedList.filter(c => c.computed.overallStatus === 'yellow').length;
    const redUnits = computedList.filter(c => c.computed.overallStatus === 'red').length;
    const totalUnits = computedList.length;

    const summaryData = [
      ["CÔNG AN TỈNH ĐẮK LẮK - PHÒNG CẢNH SÁT QLHC VỀ TTXH"],
      ["HỆ THỐNG GIÁM SÁT LĨNH VỰC CƯ TRÚ, CĂN CƯỚC - BÁO CÁO TỔNG HỢP"],
      [`Ngày báo cáo: ${formatDDMMYYYY(selectedDate)}`, `Kỳ báo cáo: ${selectedPeriod.toUpperCase()}`],
      [],
      ["I. TỔNG HỢP KẾT QUẢ ĐÁNH GIÁ 102 XÃ, PHƯỜNG"],
      ["Chỉ số", "Số lượng", "Tỷ lệ %", "Ghi chú tiêu chí"],
      ["Tổng số đơn vị theo dõi", totalUnits, "100%", "102 xã/phường thuộc tỉnh Đắk Lắk"],
      ["🟢 Đơn vị Đạt tốt (Xanh)", greenUnits, `${((greenUnits / totalUnits) * 100).toFixed(1)}%`, "Đạt 100% các chỉ tiêu áp dụng"],
      ["🟡 Đơn vị Trung bình (Vàng)", yellowUnits, `${((yellowUnits / totalUnits) * 100).toFixed(1)}%`, "Đạt từ 60% đến dưới 100% chỉ tiêu xanh"],
      ["🔴 Đơn vị Chậm (Đỏ)", redUnits, `${((redUnits / totalUnits) * 100).toFixed(1)}%`, "Đạt dưới 60% chỉ tiêu xanh hoặc phát sinh quá hạn"],
      ["Tỷ lệ hoàn thành toàn tỉnh", `${((greenUnits / totalUnits) * 100).toFixed(1)}%`, "", "Tỷ lệ đơn vị đạt tốt"],
      [],
      ["II. CÁCH TÍNH & TIÊU CHÍ CỦA 4 CHỈ TIÊU NGHIỆP VỤ"],
      ["STT", "Tên chỉ tiêu", "Công thức tính", "Quy tắc phân loại"],
      ["CT1", "Định danh điện tử VNeID mức 2", "Tỷ lệ % = Đã kích hoạt / Đã thu nhận", "≥90%: Xanh 🟢 | <90%: Đỏ 🔴"],
      ["CT2", "Hồ sơ cư trú quá hạn", "Theo ngày: Số hồ sơ quá hạn | Theo tháng: Số ngày có phát sinh", "Ngày: =0 hồ sơ Xanh 🟢, >0 Đỏ 🔴 | Tháng: 0–4 ngày Xanh 🟢, ≥5 ngày Đỏ 🔴"],
      ["CT3", "Làm sạch dữ liệu dân cư", "So số còn phải làm với lần nhập trước: % Giảm = (Trước - Hiện tại)/Trước", "Giảm >50%: Xanh 🟢 | Giảm ≤50%: Vàng 🟡 | Không giảm/Tăng: Đỏ 🔴"],
      ["CT4", "Số hóa tàng thư cư trú", "Số làm ngày = Lũy kế hiện tại - Lũy kế trước. Tỷ lệ % = Số làm ngày / Chỉ tiêu ngày", "≥100%: Xanh 🟢 | 50%–<100%: Vàng 🟡 | <50%: Đỏ 🔴"]
    ];

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, wsSummary, "TrangTongHop");

    // 2. Sheet 2: Bảng xếp hạng (BangXepHang)
    const sortedGood = [...computedList]
      .sort((a, b) => b.computed.greenKpiPercent - a.computed.greenKpiPercent)
      .slice(0, 10);
    const sortedSlow = [...computedList]
      .sort((a, b) => a.computed.greenKpiPercent - b.computed.greenKpiPercent)
      .slice(0, 10);

    const rankingData: any[] = [
      ["BẢNG XẾP HẠNG TOP 10 ĐƠN VỊ DẪN ĐẦU VÀ BÁO ĐỘNG"],
      [`Ngày báo cáo: ${formatDDMMYYYY(selectedDate)}`],
      [],
      ["A. TOP 10 ĐƠN VỊ DẪN ĐẦU (TỐT NHẤT)"],
      ["Hạng", "Mã STT", "Tên Xã / Phường", "Số chỉ tiêu xanh", "Tổng chỉ tiêu", "Tỷ lệ xanh (%)", "Xếp loại"]
    ];

    sortedGood.forEach((item, idx) => {
      rankingData.push([
        idx + 1,
        item.stt,
        item.name,
        item.computed.greenKpisCount,
        item.computed.totalKpis,
        `${item.computed.greenKpiPercent}%`,
        item.computed.overallStatus === 'green' ? '🟢 Tốt' : item.computed.overallStatus === 'yellow' ? '🟡 Trung bình' : '🔴 Chậm'
      ]);
    });

    rankingData.push([]);
    rankingData.push(["B. TOP 10 ĐƠN VỊ BÁO ĐỘNG (CHẬM TIẾN ĐỘ)"]);
    rankingData.push(["Hạng", "Mã STT", "Tên Xã / Phường", "Số chỉ tiêu xanh", "Tổng chỉ tiêu", "Tỷ lệ xanh (%)", "Xếp loại"]);

    sortedSlow.forEach((item, idx) => {
      rankingData.push([
        idx + 1,
        item.stt,
        item.name,
        item.computed.greenKpisCount,
        item.computed.totalKpis,
        `${item.computed.greenKpiPercent}%`,
        item.computed.overallStatus === 'green' ? '🟢 Tốt' : item.computed.overallStatus === 'yellow' ? '🟡 Trung bình' : '🔴 Chậm'
      ]);
    });

    const wsRanking = XLSX.utils.aoa_to_sheet(rankingData);
    XLSX.utils.book_append_sheet(workbook, wsRanking, "BangXepHang");

    // 3. Sheet 3: Số liệu chi tiết theo 102 đơn vị (ChiTiet_102DonVi)
    const detailHeaders = [
      "STT",
      "Tên Xã / Phường",
      "CT1_Đã_Thu_Nhận",
      "CT1_Đã_Kích_Hoạt",
      "CT1_Tỷ_Lệ_%",
      "CT1_Xếp_Loại",
      "CT2_Quá_Hạn_Ngày",
      "CT2_Xếp_Loại",
      "CT3_Còn_Phải_Làm",
      "CT3_Lần_Trước",
      "CT3_Kết_Quả_Tính",
      "CT3_Xếp_Loại",
      "CT4_Lũy_Kế",
      "CT4_Làm_Trong_Ngày",
      "CT4_Chỉ_Tiêu_Ngày",
      "CT4_Tỷ_Lệ_%",
      "CT4_Xếp_Loại",
      "Số_Chỉ_Tiêu_Xanh",
      "Tổng_Chỉ_Tiêu",
      "Tỷ_Lệ_Xanh_%",
      "XẾP_LOẠI_CHUNG_ĐƠN_VỊ"
    ];

    const detailRows = computedList.map(item => {
      const c1 = item.computed.kpiResults['kpi_1'] || ({} as any);
      const c2 = item.computed.kpiResults['kpi_2'] || ({} as any);
      const c3 = item.computed.kpiResults['kpi_3'] || ({} as any);
      const c4 = item.computed.kpiResults['kpi_4'] || ({} as any);

      const statusText = (st?: string) => st === 'green' ? 'Xanh' : st === 'yellow' ? 'Vàng' : st === 'red' ? 'Đỏ' : 'Chưa có';

      return [
        item.stt,
        item.name,
        c1.details?.da_thu_nhan ?? 0,
        c1.details?.da_kich_hoat ?? 0,
        c1.percent !== undefined ? `${c1.percent}%` : '—',
        statusText(c1.status),
        c2.details?.qua_han_ngay ?? 0,
        statusText(c2.status),
        c3.details?.con_phai_lam ?? 0,
        c3.details?.con_phai_lam_truoc ?? '—',
        c3.displayResult || '—',
        statusText(c3.status),
        c4.details?.luy_ke ?? 0,
        c4.details?.so_lam_ngay ?? 0,
        c4.details?.chi_tieu_ngay ?? 100,
        c4.percent !== undefined ? `${c4.percent}%` : '—',
        statusText(c4.status),
        item.computed.greenKpisCount,
        item.computed.totalKpis,
        `${item.computed.greenKpiPercent}%`,
        item.computed.overallStatus === 'green' ? '🟢 TỐT' : item.computed.overallStatus === 'yellow' ? '🟡 TRUNG BÌNH' : '🔴 CHẬM'
      ];
    });

    const wsDetails = XLSX.utils.aoa_to_sheet([detailHeaders, ...detailRows]);
    XLSX.utils.book_append_sheet(workbook, wsDetails, "ChiTiet_102DonVi");

    // Download Workbook
    const fileName = `BaoCao_GiamSat_CuTru_DakLak_${formatDDMMYYYY(selectedDate).replace(/\//g, '-')}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-2xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📁</span>
            <div>
              <h3 className="text-base font-bold text-amber-200 uppercase">KHO LƯU TRỮ VÀ XUẤT BÁO CÁO EXCEL 3 TRANG</h3>
              <p className="text-xs text-amber-100">
                Xuất file Excel gồm Trang tổng hợp, Bảng xếp hạng và Số liệu chi tiết 102 đơn vị
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 flex-grow">
          {/* Current selected date card with Export Excel */}
          <div className="p-3 bg-amber-50 dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold shadow-sm">
            <div>
              <span className="text-amber-900 dark:text-amber-300">
                Ngày đang chọn: {formatDDMMYYYY(selectedDate)}
              </span>
              <span className="text-slate-500 dark:text-slate-400 font-normal ml-2">
                Tỷ lệ hoàn thành: {overallPercent}
              </span>
            </div>
            <button
              onClick={handleExportExcelMultiSheet}
              type="button"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow cursor-pointer transition"
            >
              <Download className="w-4 h-4" />
              <span>Xuất Excel chuẩn 3 trang</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 space-y-1">
            <p className="font-bold text-slate-700 dark:text-slate-200">📊 Nội dung file Excel khi xuất:</p>
            <p>• <strong>Sheet 1 (TrangTongHop):</strong> Báo cáo chỉ số tỉnh, tỷ lệ đạt theo từng phân loại và quy chuẩn 4 chỉ tiêu.</p>
            <p>• <strong>Sheet 2 (BangXepHang):</strong> Danh sách Top 10 đơn vị dẫn đầu và Top 10 đơn vị báo động chậm tiến độ.</p>
            <p>• <strong>Sheet 3 (ChiTiet_102DonVi):</strong> Toàn bộ 102 xã/phường kèm công thức tính, số liệu thành phần của cả 4 chỉ tiêu và màu phân loại.</p>
          </div>

          <h4 className="font-bold text-xs text-slate-700 dark:text-slate-200 uppercase border-b pb-1 pt-2">
            Lịch sử các ngày báo cáo đã lưu ({historyRecords.length} ngày):
          </h4>

          <div className="space-y-2">
            {historyRecords.length > 0 ? (
              historyRecords.map(item => (
                <div
                  key={item.date}
                  className="p-2.5 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs transition"
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-amber-600" />
                    <span className="text-amber-800 dark:text-amber-400 font-bold">
                      Bản lưu {formatDDMMYYYY(item.date)}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      Cập nhật: {new Date(item.updated_at).toLocaleString('vi-VN')}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onOpenSavedDate(item.date);
                      onClose();
                    }}
                    type="button"
                    className="bg-red-800 hover:bg-red-700 text-white font-bold px-2.5 py-1 rounded text-[11px] cursor-pointer transition"
                  >
                    Mở báo cáo ngày này
                  </button>
                </div>
              ))
            ) : (
              <p className="p-4 text-center text-xs text-slate-400">
                Chưa có ngày báo cáo nào được lưu trên trình duyệt này.
              </p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-end items-center border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            type="button"
            className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-1.5 rounded-lg text-xs cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
