import React, { useState } from 'react';
import html2canvas from 'html2canvas';
import { formatDDMMYY } from '../../data/communes';
import { X, Download, Camera } from 'lucide-react';

interface BannerDownloadModalProps {
  isOpen: boolean;
  selectedDate: string;
  bannerRef: React.RefObject<HTMLDivElement | null>;
  onClose: () => void;
}

export const BannerDownloadModal: React.FC<BannerDownloadModalProps> = ({
  isOpen,
  selectedDate,
  bannerRef,
  onClose
}) => {
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    if (!bannerRef.current) return;
    setLoading(true);
    try {
      const canvas = await html2canvas(bannerRef.current, {
        scale: 2,
        backgroundColor: '#fffdf2',
        useCORS: true
      });
      const link = document.createElement('a');
      link.download = `Banner_CongAn_DakLak_${formatDDMMYY(selectedDate).replace(/\//g, '-')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      onClose();
    } catch (e) {
      console.error('Failed to export banner image:', e);
      alert('Không thể tạo file hình ảnh banner.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-md w-full border border-amber-500 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-amber-300" />
            <h3 className="text-sm font-bold text-amber-200 uppercase">XÁC NHẬN XUẤT BANNER</h3>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 text-slate-800 dark:text-slate-100 text-sm space-y-3">
          <p className="font-bold text-center text-slate-700 dark:text-slate-200">
            Bạn có chắc chắn muốn tiến hành xuất file hình ảnh banner này không?
          </p>
          <div className="bg-amber-50 dark:bg-slate-900 p-3 rounded-xl border border-amber-200 dark:border-slate-700 text-xs text-amber-900 dark:text-amber-300 flex items-center gap-2">
            <span>💡</span>
            <span>
              Hệ thống sẽ chụp lại khung Banner Công an tỉnh Đắk Lắk nền kem trống đồng với chất lượng độ phân giải cao PNG.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-end items-center gap-2 border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            type="button"
            className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-1.5 rounded-lg text-xs cursor-pointer"
          >
            Hủy bỏ
          </button>
          <button
            onClick={handleDownload}
            disabled={loading}
            type="button"
            className="bg-amber-600 hover:bg-amber-500 active:scale-95 text-white font-bold px-5 py-1.5 rounded-lg text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{loading ? '⏳ Đang khởi tạo...' : 'Đồng ý & Tải về'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
