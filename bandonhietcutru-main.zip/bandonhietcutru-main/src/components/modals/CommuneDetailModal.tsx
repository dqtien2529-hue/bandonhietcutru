import React, { useState, useEffect } from 'react';
import { Commune, KPI, CommuneKPIValues, CommuneEntry } from '../../types';
import { evaluateKPI } from '../../utils/calculations';
import { X, Save } from 'lucide-react';

interface CommuneDetailModalProps {
  commune: Commune | null;
  entry: CommuneEntry | undefined;
  prevEntry: CommuneEntry | undefined;
  kpis: KPI[];
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  isAdmin?: boolean;
  onSave: (stt: number, stats: Record<string, CommuneKPIValues>) => void;
  onClose: () => void;
}

export const CommuneDetailModal: React.FC<CommuneDetailModalProps> = ({
  commune,
  entry,
  prevEntry,
  kpis,
  selectedPeriod,
  isAdmin = false,
  onSave,
  onClose
}) => {
  const [localStats, setLocalStats] = useState<Record<string, CommuneKPIValues>>({});

  useEffect(() => {
    if (!commune) return;
    const initial: Record<string, CommuneKPIValues> = {};
    kpis.forEach(kpi => {
      const s = entry?.stats?.[kpi.id] || {};
      initial[kpi.id] = {
        da_thu_nhan: s.da_thu_nhan ?? 0,
        da_kich_hoat: s.da_kich_hoat ?? 0,
        qua_han_ngay: s.qua_han_ngay ?? 0,
        so_ngay_phat_sinh_thang: s.so_ngay_phat_sinh_thang ?? 0,
        con_phai_lam: s.con_phai_lam ?? 0,
        luy_ke: s.luy_ke ?? 0,
        chi_tieu_ngay: s.chi_tieu_ngay || kpi.defaultDailyTarget || 100,
        reported: true
      };
    });
    setLocalStats(initial);
  }, [commune, entry, kpis]);

  if (!commune) return null;

  // Real-time evaluation of all KPIs
  let greenCount = 0;
  const evaluations: Record<string, any> = {};

  kpis.forEach(kpi => {
    const curVal = localStats[kpi.id];
    const prevVal = prevEntry?.stats?.[kpi.id];
    const res = evaluateKPI(kpi, curVal, prevVal, selectedPeriod);
    evaluations[kpi.id] = res;
    if (res.status === 'green') greenCount++;
  });

  const totalKpis = kpis.length;
  const greenPercent = totalKpis > 0 ? parseFloat(((greenCount / totalKpis) * 100).toFixed(1)) : 0;
  let overallBadge = 'bg-red-100 text-red-700 border-red-300';
  let overallText = `🔴 Đỏ (<60% Xanh) — ${greenCount}/${totalKpis} chỉ tiêu đạt`;

  if (totalKpis > 0 && greenCount === totalKpis) {
    overallBadge = 'bg-emerald-100 text-emerald-800 border-emerald-300';
    overallText = `🟢 Đạt tốt (100% Xanh) — ${greenCount}/${totalKpis} chỉ tiêu đạt`;
  } else if (greenPercent >= 60) {
    overallBadge = 'bg-amber-100 text-amber-800 border-amber-300';
    overallText = `🟡 Trung bình (≥60% Xanh) — ${greenCount}/${totalKpis} chỉ tiêu đạt`;
  }

  const handleFieldChange = (kpiId: string, field: keyof CommuneKPIValues, value: number) => {
    setLocalStats(prev => ({
      ...prev,
      [kpiId]: {
        ...prev[kpiId],
        [field]: Math.max(0, value),
        reported: true
      }
    }));
  };

  const handleSave = () => {
    onSave(commune.stt, localStats);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-3xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-900 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div>
            <span className="text-xs font-bold uppercase text-amber-300 tracking-wide">STT #{commune.stt}</span>
            <h3 className="text-lg font-bold text-amber-200">{commune.name}</h3>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-grow">
          {/* Overall Status Banner */}
          <div className="bg-slate-50 dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 uppercase font-bold">Xếp loại tổng hợp đơn vị</span>
              <div className="mt-1">
                <span className={`text-xs font-black px-2.5 py-1 rounded-md border ${overallBadge}`}>
                  {overallText}
                </span>
              </div>
            </div>
            <div className="text-right text-xs font-bold text-slate-600 dark:text-slate-300">
              <p>Tỷ lệ chỉ tiêu xanh: <span className="text-emerald-600 font-black">{greenPercent}%</span></p>
              <p className="text-[11px] text-slate-400 font-normal">Kỳ đánh giá: {selectedPeriod === 'day' ? 'Hôm nay' : selectedPeriod}</p>
            </div>
          </div>

          <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100 uppercase border-b pb-1 border-slate-200">
            Chi tiết 4 chỉ tiêu nghiệp vụ và số liệu cần nhập:
          </h4>

          {/* KPI Inputs List */}
          <div className="space-y-3">
            {kpis.map(kpi => {
              const vals = localStats[kpi.id] || {};
              const res = evaluations[kpi.id];

              let badgeColor = 'bg-red-100 text-red-700 border-red-300';
              let icon = '🔴';
              if (res?.status === 'green') {
                badgeColor = 'bg-emerald-100 text-emerald-800 border-emerald-300';
                icon = '🟢';
              } else if (res?.status === 'yellow') {
                badgeColor = 'bg-amber-100 text-amber-800 border-amber-300';
                icon = '🟡';
              }

              return (
                <div
                  key={kpi.id}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-black text-xs text-slate-800 dark:text-slate-100 block">{kpi.name}</span>
                      <span className="text-[11px] text-slate-500">{kpi.description}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-xs font-black border flex items-center gap-1 ${badgeColor}`}>
                      <span>{icon}</span>
                      <span>{res?.displayResult || 'Chưa nhập'}</span>
                    </span>
                  </div>

                  {/* Input Fields specific to this KPI type */}
                  <div className="bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 flex flex-wrap items-center gap-4 text-xs font-bold">
                    {kpi.type === 'RATIO_VNEID' && (
                      <>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Đã thu nhận:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.da_thu_nhan ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'da_thu_nhan', parseInt(e.target.value) || 0)}
                            className="w-20 border rounded px-1.5 py-0.5 text-right font-black text-slate-700 dark:text-slate-200"
                          />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Đã kích hoạt:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.da_kich_hoat ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'da_kich_hoat', parseInt(e.target.value) || 0)}
                            className="w-20 border rounded px-1.5 py-0.5 text-right font-black text-emerald-600"
                          />
                        </div>
                        <div className="text-[11px] text-slate-400">
                          (Tỷ lệ = Đã kích hoạt / Đã thu nhận, ≥90% là Xanh)
                        </div>
                      </>
                    )}

                    {kpi.type === 'OVERDUE_RECORDS' && (
                      <>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Số hồ sơ quá hạn ngày:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.qua_han_ngay ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'qua_han_ngay', parseInt(e.target.value) || 0)}
                            className="w-20 border rounded px-1.5 py-0.5 text-right font-black text-red-600"
                          />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Số ngày phát sinh tháng:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.so_ngay_phat_sinh_thang ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'so_ngay_phat_sinh_thang', parseInt(e.target.value) || 0)}
                            className="w-16 border rounded px-1.5 py-0.5 text-right font-black text-amber-700"
                          />
                        </div>
                        <div className="text-[11px] text-slate-400">
                          (Ngày: 0 hồ sơ là Xanh, &gt;0 là Đỏ; Tháng: 0–4 ngày là Xanh)
                        </div>
                      </>
                    )}

                    {kpi.type === 'DATA_CLEANING' && (
                      <>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Số trường hợp còn phải làm:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.con_phai_lam ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'con_phai_lam', parseInt(e.target.value) || 0)}
                            className="w-24 border rounded px-1.5 py-0.5 text-right font-black text-slate-800 dark:text-slate-100"
                          />
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Số lần trước: <span className="font-black text-amber-700">{prevEntry?.stats?.[kpi.id]?.con_phai_lam ?? 'Chưa có'}</span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          (Giảm &gt;50%: Xanh, Giảm ≤50%: Vàng, Tăng/không giảm: Đỏ)
                        </div>
                      </>
                    )}

                    {kpi.type === 'DIGITIZATION' && (
                      <>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Tổng lũy kế đến ngày:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.luy_ke ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'luy_ke', parseInt(e.target.value) || 0)}
                            className="w-24 border rounded px-1.5 py-0.5 text-right font-black text-blue-600"
                          />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Chỉ tiêu ngày:</label>
                          <input
                            type="number"
                            min="1"
                            value={vals.chi_tieu_ngay || kpi.defaultDailyTarget || 100}
                            onChange={(e) => handleFieldChange(kpi.id, 'chi_tieu_ngay', parseInt(e.target.value) || 100)}
                            className="w-16 border rounded px-1.5 py-0.5 text-right font-black text-slate-600"
                          />
                        </div>
                        <div className="text-[11px] text-slate-400">
                          (Số làm ngày = Lũy kế trừ trước; so chỉ tiêu ngày: ≥100% Xanh, 50–99% Vàng, &lt;50% Đỏ)
                        </div>
                      </>
                    )}

                    {kpi.type === 'CUSTOM_RATIO' && (
                      <>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Chỉ tiêu giao:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.giao ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'giao', parseInt(e.target.value) || 0)}
                            className="w-20 border rounded px-1.5 py-0.5 text-right font-black"
                          />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <label className="text-slate-500">Đã đạt:</label>
                          <input
                            type="number"
                            min="0"
                            value={vals.da_lam ?? 0}
                            onChange={(e) => handleFieldChange(kpi.id, 'da_lam', parseInt(e.target.value) || 0)}
                            className="w-20 border rounded px-1.5 py-0.5 text-right font-black text-emerald-600"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-between items-center border-t border-slate-200 dark:border-slate-700">
          <span className="text-[11px] text-slate-400">
            {isAdmin ? '*Ô để trống được lưu là 0 theo đúng quy định' : 'Chế độ chỉ xem • Cần đăng nhập quản trị để cập nhật số liệu'}
          </span>
          <div className="flex gap-2">
            {isAdmin && (
              <button
                onClick={handleSave}
                type="button"
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-1.5 rounded-lg text-xs shadow flex items-center gap-1 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Lưu kết quả đơn vị</span>
              </button>
            )}
            <button
              onClick={onClose}
              type="button"
              className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-1.5 rounded-lg text-xs cursor-pointer"
            >
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
