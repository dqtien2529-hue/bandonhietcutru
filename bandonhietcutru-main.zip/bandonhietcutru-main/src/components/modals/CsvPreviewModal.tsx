import React from 'react';
import { KPI, CsvPreviewRow, CommuneKPIValues } from '../../types';
import { evaluateKPI } from '../../utils/calculations';
import { X, Check, AlertTriangle, AlertCircle, Sparkles } from 'lucide-react';

interface CsvPreviewModalProps {
  isOpen: boolean;
  rows: CsvPreviewRow[];
  kpis: KPI[];
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  onUpdateRowValue: (rowIndex: number, field: string, val: number) => void;
  onConfirm: () => void;
  onClose: () => void;
}

export const CsvPreviewModal: React.FC<CsvPreviewModalProps> = ({
  isOpen,
  rows,
  kpis,
  selectedPeriod,
  onUpdateRowValue,
  onConfirm,
  onClose
}) => {
  if (!isOpen) return null;

  const uncertainRowsCount = rows.filter(r => r.isUncertain || (r.confidence !== undefined && r.confidence < 0.8)).length;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-6xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🤖</span>
            <div>
              <h3 className="text-base font-bold text-amber-200 uppercase flex items-center gap-1.5">
                <span>XEM TRƯỚC & ĐỐI SOÁT SỐ LIỆU (EXCEL / CSV / ẢNH AI)</span>
                <Sparkles className="w-4 h-4 text-amber-300" />
              </h3>
              <p className="text-xs text-amber-100">
                Kiểm tra, rà soát các ô được nhận diện trước khi ghi chính thức vào cơ sở dữ liệu
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning notification */}
        <div className="p-3 bg-amber-50 dark:bg-slate-900 border-b border-amber-300 dark:border-slate-700 text-xs text-amber-900 dark:text-amber-300 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
            <span>
              Tìm thấy <strong className="font-black text-amber-800 dark:text-amber-200">{rows.length}</strong> đơn vị trong tệp/ảnh.
              {uncertainRowsCount > 0 && (
                <span className="text-red-600 dark:text-red-400 font-bold ml-1">
                  Có {uncertainRowsCount} dòng cần rà soát kỹ các ô màu vàng/cam trước khi lưu.
                </span>
              )}
            </span>
          </div>
          <span className="text-[11px] text-slate-500">
            *Ô trống được tính là 0
          </span>
        </div>

        {/* Preview Table */}
        <div className="p-4 overflow-y-auto flex-grow space-y-2 max-h-[550px]">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-200 dark:bg-slate-900 sticky top-0 font-bold uppercase text-[10px] text-slate-700 dark:text-slate-300 shadow-sm z-10">
              <tr>
                <th className="p-2 border text-center w-10">STT</th>
                <th className="p-2 border min-w-[140px]">Đơn vị (Xã/Phường)</th>
                <th className="p-2 border min-w-[160px]">CT1: Định danh mức 2</th>
                <th className="p-2 border min-w-[140px]">CT2: Quá hạn</th>
                <th className="p-2 border min-w-[130px]">CT3: Làm sạch</th>
                <th className="p-2 border min-w-[150px]">CT4: Số hóa tàng thư</th>
                <th className="p-2 border text-center min-w-[120px]">Trạng thái nhận diện</th>
              </tr>
            </thead>
            <tbody className="font-bold divide-y divide-slate-200 dark:divide-slate-700">
              {rows.map((row, idx) => {
                const isUncertain = row.isUncertain || (row.confidence !== undefined && row.confidence < 0.8);
                const kVals = (row.kpiValues || {}) as CommuneKPIValues;

                // Evaluate CT1
                const ct1Kpi = kpis.find(k => k.id === 'kpi_1') || kpis[0];
                const resCt1 = ct1Kpi ? evaluateKPI(ct1Kpi, kVals, undefined, selectedPeriod) : null;

                // Evaluate CT2
                const ct2Kpi = kpis.find(k => k.id === 'kpi_2') || kpis[1];
                const resCt2 = ct2Kpi ? evaluateKPI(ct2Kpi, kVals, undefined, selectedPeriod) : null;

                // Evaluate CT3
                const ct3Kpi = kpis.find(k => k.id === 'kpi_3') || kpis[2];
                const resCt3 = ct3Kpi ? evaluateKPI(ct3Kpi, kVals, undefined, selectedPeriod) : null;

                // Evaluate CT4
                const ct4Kpi = kpis.find(k => k.id === 'kpi_4') || kpis[3];
                const resCt4 = ct4Kpi ? evaluateKPI(ct4Kpi, kVals, undefined, selectedPeriod) : null;

                return (
                  <tr
                    key={row.stt}
                    className={`transition ${isUncertain ? 'bg-amber-100/70 dark:bg-amber-950/40 border-amber-300' : 'bg-slate-50 dark:bg-slate-800'}`}
                  >
                    <td className="p-2 border text-center text-slate-500">#{row.stt}</td>
                    <td className="p-2 border font-black text-slate-800 dark:text-slate-100">{row.name}</td>

                    {/* CT1: Thu & Kích */}
                    <td className="p-2 border">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-400">Thu:</span>
                        <input
                          type="number"
                          min="0"
                          value={kVals.da_thu_nhan ?? 0}
                          onChange={(e) => onUpdateRowValue(idx, 'da_thu_nhan', parseInt(e.target.value) || 0)}
                          className={`w-16 border rounded px-1 text-right text-xs font-bold ${
                            isUncertain ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300' : 'bg-white dark:bg-slate-900'
                          }`}
                        />
                        <span className="text-[10px] text-slate-400">Kích:</span>
                        <input
                          type="number"
                          min="0"
                          value={kVals.da_kich_hoat ?? 0}
                          onChange={(e) => onUpdateRowValue(idx, 'da_kich_hoat', parseInt(e.target.value) || 0)}
                          className={`w-16 border rounded px-1 text-right text-xs font-bold text-emerald-600 ${
                            isUncertain ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300' : 'bg-white dark:bg-slate-900'
                          }`}
                        />
                        <span className="text-[10px] font-black text-slate-600 dark:text-slate-300 ml-1">
                          {resCt1?.displayResult || '—'}
                        </span>
                      </div>
                    </td>

                    {/* CT2: Quá hạn */}
                    <td className="p-2 border">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={kVals.qua_han_ngay ?? 0}
                          onChange={(e) => onUpdateRowValue(idx, 'qua_han_ngay', parseInt(e.target.value) || 0)}
                          className={`w-16 border rounded px-1 text-right text-xs font-bold text-red-600 ${
                            isUncertain ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300' : 'bg-white dark:bg-slate-900'
                          }`}
                        />
                        <span className="text-[10px] font-black">
                          {resCt2?.displayResult || '0 hồ sơ'}
                        </span>
                      </div>
                    </td>

                    {/* CT3: Làm sạch */}
                    <td className="p-2 border">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={kVals.con_phai_lam ?? 0}
                          onChange={(e) => onUpdateRowValue(idx, 'con_phai_lam', parseInt(e.target.value) || 0)}
                          className={`w-20 border rounded px-1 text-right text-xs font-bold ${
                            isUncertain ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300' : 'bg-white dark:bg-slate-900'
                          }`}
                        />
                        <span className="text-[10px] text-slate-500 font-bold">
                          {resCt3?.displayResult || '—'}
                        </span>
                      </div>
                    </td>

                    {/* CT4: Số hóa */}
                    <td className="p-2 border">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={kVals.luy_ke ?? 0}
                          onChange={(e) => onUpdateRowValue(idx, 'luy_ke', parseInt(e.target.value) || 0)}
                          className={`w-20 border rounded px-1 text-right text-xs font-bold text-blue-600 ${
                            isUncertain ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300' : 'bg-white dark:bg-slate-900'
                          }`}
                        />
                        <span className="text-[10px] font-black text-slate-600 dark:text-slate-300">
                          {resCt4?.displayResult || '—'}
                        </span>
                      </div>
                    </td>

                    {/* Status column */}
                    <td className="p-2 border text-center">
                      {isUncertain ? (
                        <span className="bg-amber-200 text-amber-900 px-2 py-0.5 rounded text-[10px] font-black border border-amber-400 flex items-center justify-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-700" />
                          <span>⚠️ Cần kiểm tra</span>
                        </span>
                      ) : (
                        <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-[10px] font-black border border-emerald-300 flex items-center justify-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>✅ Đã khớp chuẩn</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-between items-center border-t border-slate-200 dark:border-slate-700">
          <span className="text-[11px] text-slate-500 font-bold">
            *Chỉ ghi vào cơ sở dữ liệu sau khi bạn bấm xác nhận bên dưới.
          </span>
          <div className="flex gap-2">
            <button
              onClick={onConfirm}
              type="button"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-lg text-xs shadow flex items-center gap-1.5 cursor-pointer transition"
            >
              <Check className="w-4 h-4" />
              <span>Đồng ý & Lưu vào cơ sở dữ liệu</span>
            </button>
            <button
              onClick={onClose}
              type="button"
              className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-2 rounded-lg text-xs cursor-pointer transition"
            >
              Hủy bỏ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
