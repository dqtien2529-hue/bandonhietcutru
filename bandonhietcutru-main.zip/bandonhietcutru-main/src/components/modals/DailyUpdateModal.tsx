import React, { useState, useRef, useEffect } from 'react';
import { KPI, CommuneEntry, CommuneKPIValues } from '../../types';
import { OFFICIAL_102_COMMUNES, formatDDMMYYYY } from '../../data/communes';
import { evaluateKPI } from '../../utils/calculations';
import { X, Save, Upload, Camera, Search, Filter, Sparkles, CheckCircle2, Eye, RefreshCw } from 'lucide-react';

export interface AutoFilledInfo {
  count: number;
  communeNames: string[];
  sttList: number[];
  summary: string;
}

interface DailyUpdateModalProps {
  isOpen: boolean;
  selectedDate: string;
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year';
  kpis: KPI[];
  communeData: Record<number, CommuneEntry>;
  previousCommuneData: Record<number, CommuneEntry> | undefined;
  isProcessingFile?: boolean;
  autoFilledInfo?: AutoFilledInfo | null;
  injectedBatch?: Record<number, Record<string, CommuneKPIValues>> | null;
  onOpenAuditPreview?: () => void;
  onClearAutoFilledNotice?: () => void;
  onBatchSave: (updates: Record<number, Record<string, CommuneKPIValues>>) => void;
  onFileSelected: (file: File) => void;
  onImageSelected: (file: File) => void;
  onClose: () => void;
}

export const DailyUpdateModal: React.FC<DailyUpdateModalProps> = ({
  isOpen,
  selectedDate,
  selectedPeriod,
  kpis,
  communeData,
  previousCommuneData,
  isProcessingFile = false,
  autoFilledInfo = null,
  injectedBatch = null,
  onOpenAuditPreview,
  onClearAutoFilledNotice,
  onBatchSave,
  onFileSelected,
  onImageSelected,
  onClose
}) => {
  const [activeKpiFilter, setActiveKpiFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showOnlyAutoFilled, setShowOnlyAutoFilled] = useState<boolean>(false);
  const [localData, setLocalData] = useState<Record<number, Record<string, CommuneKPIValues>>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Initialize local data when modal opens
  useEffect(() => {
    if (!isOpen) return;
    const initial: Record<number, Record<string, CommuneKPIValues>> = {};
    OFFICIAL_102_COMMUNES.forEach(c => {
      initial[c.stt] = {};
      kpis.forEach(kpi => {
        const s = communeData[c.stt]?.stats?.[kpi.id] || {};
        initial[c.stt][kpi.id] = {
          da_thu_nhan: s.da_thu_nhan ?? 0,
          da_kich_hoat: s.da_kich_hoat ?? 0,
          qua_han_ngay: s.qua_han_ngay ?? 0,
          so_ngay_phat_sinh_thang: s.so_ngay_phat_sinh_thang ?? 0,
          con_phai_lam: s.con_phai_lam ?? 0,
          luy_ke: s.luy_ke ?? 0,
          chi_tieu_ngay: s.chi_tieu_ngay || kpi.defaultDailyTarget || 100,
          reported: s.reported ?? false
        };
      });
    });
    setLocalData(initial);
  }, [isOpen, communeData, kpis]);

  // When AI or file parser yields injectedBatch, merge into localData immediately!
  useEffect(() => {
    if (!injectedBatch || Object.keys(injectedBatch).length === 0) return;
    setLocalData(prev => {
      const next = { ...prev };
      Object.entries(injectedBatch).forEach(([sttStr, kpiMap]) => {
        const stt = parseInt(sttStr, 10);
        if (!next[stt]) next[stt] = {};
        Object.entries(kpiMap).forEach(([kpiId, vals]) => {
          next[stt][kpiId] = {
            ...(next[stt][kpiId] || {}),
            ...vals,
            reported: true
          };
        });
      });
      return next;
    });
  }, [injectedBatch]);

  if (!isOpen) return null;

  const autoFilledSet = new Set(autoFilledInfo?.sttList || []);

  const filteredCommunes = OFFICIAL_102_COMMUNES.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase().trim());
    if (showOnlyAutoFilled && autoFilledSet.size > 0) {
      return matchesSearch && autoFilledSet.has(c.stt);
    }
    return matchesSearch;
  });

  const handleValueChange = (stt: number, kpiId: string, field: keyof CommuneKPIValues, rawVal: string) => {
    const val = rawVal.trim() === '' ? 0 : Math.max(0, parseInt(rawVal, 10) || 0);
    setLocalData(prev => ({
      ...prev,
      [stt]: {
        ...prev[stt],
        [kpiId]: {
          ...prev[stt]?.[kpiId],
          [field]: val,
          reported: true
        }
      }
    }));
  };

  const handleSaveAll = () => {
    onBatchSave(localData);
    onClose();
  };

  const activeKpisToDisplay = activeKpiFilter === 'all'
    ? kpis
    : kpis.filter(k => k.id === activeKpiFilter);

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-7xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📝</span>
            <div>
              <h3 className="text-base font-bold text-amber-200 uppercase">
                NHẬP SỐ LIỆU THEO NGÀY — BẢNG ĐỐI SOÁT & TỰ ĐỘNG ĐIỀN DỮ LIỆU
              </h3>
              <p className="text-xs text-amber-100">
                Ngày báo cáo: <span className="font-black text-amber-300">{formatDDMMYYYY(selectedDate)}</span> • Ô để trống tự động tính là 0
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Buttons & AI Vision Bar */}
        <div className="p-3 bg-amber-50 dark:bg-slate-900 border-b border-amber-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Excel/CSV File Upload */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessingFile}
              type="button"
              className="bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow transition cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Nạp tệp Excel (.xlsx, .xls) / CSV</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept=".xlsx,.xls,.csv"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onFileSelected(f);
                e.target.value = '';
              }}
            />

            {/* AI Image / Table OCR */}
            <button
              onClick={() => imageInputRef.current?.click()}
              disabled={isProcessingFile}
              type="button"
              className="bg-purple-700 hover:bg-purple-600 disabled:opacity-50 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow transition cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>📷 Nhận diện ảnh bảng số liệu bằng AI</span>
            </button>
            <input
              ref={imageInputRef}
              type="file"
              className="hidden"
              accept="image/*"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onImageSelected(f);
                e.target.value = '';
              }}
            />
          </div>

          <div className="flex items-center gap-2">
            {onOpenAuditPreview && (
              <button
                onClick={onOpenAuditPreview}
                type="button"
                className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition shadow text-xs"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Xem đối soát nhận diện</span>
              </button>
            )}
          </div>
        </div>

        {/* Processing Spinner Banner */}
        {isProcessingFile && (
          <div className="p-3 bg-purple-100 dark:bg-purple-950/80 text-purple-900 dark:text-purple-200 border-b border-purple-300 flex items-center justify-center gap-2 font-bold text-xs animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin text-purple-700" />
            <span>🤖 Đang đọc & phân tích bảng biểu bằng AI (Tự động đối chiếu 102 xã/phường)... Vui lòng đợi trong giây lát!</span>
          </div>
        )}

        {/* Success Auto-Fill Notification Banner */}
        {autoFilledInfo && !isProcessingFile && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border-b border-emerald-400 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
              <div>
                <span className="font-extrabold uppercase text-emerald-800 dark:text-emerald-300">
                  ⚡ AI đã nhận diện và tự động điền số liệu cho {autoFilledInfo.count} đơn vị!
                </span>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                  {autoFilledInfo.summary || `Bao gồm: ${autoFilledInfo.communeNames.join(', ')}. Các ô vừa điền đã được cập nhật giá trị và tô nổi bật.`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowOnlyAutoFilled(prev => !prev)}
                type="button"
                className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-2.5 py-1 rounded shadow cursor-pointer transition flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{showOnlyAutoFilled ? '👁️ Xem toàn bộ 102 đơn vị' : `⚡ Chỉ xem ${autoFilledInfo.count} đơn vị vừa điền`}</span>
              </button>
              {onClearAutoFilledNotice && (
                <button
                  onClick={onClearAutoFilledNotice}
                  type="button"
                  className="text-slate-400 hover:text-slate-600 p-1"
                  title="Đóng thông báo"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Filter and Search Bar */}
        <div className="p-2.5 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2">
          {/* KPI Selector Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto text-xs font-bold">
            <span className="text-slate-500 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Chỉ tiêu:
            </span>
            <button
              type="button"
              onClick={() => setActiveKpiFilter('all')}
              className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                activeKpiFilter === 'all'
                  ? 'bg-amber-600 text-white shadow'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border'
              }`}
            >
              Tất cả {kpis.length} chỉ tiêu
            </button>
            {kpis.map(k => (
              <button
                key={k.id}
                type="button"
                onClick={() => setActiveKpiFilter(k.id)}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  activeKpiFilter === k.id
                    ? 'bg-amber-600 text-white shadow'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border'
                }`}
              >
                {k.shortName || k.name}
              </button>
            ))}
          </div>

          {/* Commune Search */}
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Lọc tên xã/phường..."
              className="bg-white dark:bg-slate-800 border rounded pl-7 pr-2.5 py-1 text-xs w-56 font-bold outline-none"
            />
          </div>
        </div>

        {/* Structured Table: Đơn vị | Chỉ tiêu | Số liệu cần nhập | Kết quả tính | Phân loại */}
        <div className="p-3 overflow-y-auto flex-grow max-h-[560px]">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-200 dark:bg-slate-900 sticky top-0 z-20 text-slate-800 dark:text-slate-200 border-b border-slate-300 font-bold uppercase text-[10px] shadow-sm">
              <tr>
                <th className="p-2 text-center w-10 border">STT</th>
                <th className="p-2 border min-w-[150px]">Đơn vị</th>
                <th className="p-2 border min-w-[120px]">Chỉ tiêu</th>
                <th className="p-2 border min-w-[260px]">Số liệu cần nhập</th>
                <th className="p-2 text-center border min-w-[150px]">Kết quả tính</th>
                <th className="p-2 text-center border min-w-[110px]">Phân loại</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-700 font-bold">
              {filteredCommunes.map(c => {
                const isAutoFilledUnit = autoFilledSet.has(c.stt);

                return activeKpisToDisplay.map((kpi, kIdx) => {
                  const vals = localData[c.stt]?.[kpi.id] || {};
                  const prevVals = previousCommuneData?.[c.stt]?.stats?.[kpi.id];
                  const res = evaluateKPI(kpi, vals, prevVals, selectedPeriod);

                  let badgeColor = 'bg-red-100 text-red-700 border border-red-300';
                  let icon = '🔴';
                  let label = 'Đỏ';

                  if (res.status === 'green') {
                    badgeColor = 'bg-emerald-100 text-emerald-800 border border-emerald-300';
                    icon = '🟢';
                    label = 'Xanh';
                  } else if (res.status === 'yellow') {
                    badgeColor = 'bg-amber-100 text-amber-800 border border-amber-300';
                    icon = '🟡';
                    label = 'Vàng';
                  } else if (res.status === 'none') {
                    badgeColor = 'bg-slate-100 text-slate-500 border border-slate-300';
                    icon = '⚪';
                    label = 'Chưa nhập';
                  }

                  const isFirstRowOfCommune = kIdx === 0;

                  return (
                    <tr
                      key={`${c.stt}-${kpi.id}`}
                      className={`transition ${
                        isAutoFilledUnit
                          ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-l-4 border-l-emerald-600'
                          : 'hover:bg-amber-50/60 dark:hover:bg-slate-700/50'
                      } ${isFirstRowOfCommune && activeKpisToDisplay.length > 1 ? 'border-t-2 border-slate-300 dark:border-slate-600' : ''}`}
                    >
                      {/* STT */}
                      {isFirstRowOfCommune ? (
                        <td rowSpan={activeKpisToDisplay.length} className="p-2 border text-center text-slate-400 bg-slate-50/50 dark:bg-slate-900/30">
                          #{c.stt}
                        </td>
                      ) : null}

                      {/* Đơn vị */}
                      {isFirstRowOfCommune ? (
                        <td rowSpan={activeKpisToDisplay.length} className="p-2 border font-black text-slate-800 dark:text-slate-100 bg-slate-50/50 dark:bg-slate-900/30">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span>{c.name}</span>
                            {isAutoFilledUnit && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-600 text-white font-extrabold flex items-center gap-0.5 shadow-sm">
                                <Sparkles className="w-3 h-3 text-amber-300" />
                                <span>AI đã điền</span>
                              </span>
                            )}
                          </div>
                        </td>
                      ) : null}

                      {/* Tên chỉ tiêu */}
                      <td className="p-2 border text-slate-700 dark:text-slate-200">
                        {kpi.shortName || kpi.name}
                      </td>

                      {/* Ô nhập số liệu nghiệp vụ theo từng loại chỉ tiêu */}
                      <td className="p-2 border">
                        {kpi.type === 'RATIO_VNEID' && (
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400">Thu:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.da_thu_nhan ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'da_thu_nhan', e.target.value)}
                              className={`w-20 border rounded px-1.5 py-0.5 text-right font-black ${
                                isAutoFilledUnit && (vals.da_thu_nhan || 0) > 0
                                  ? 'bg-emerald-100 border-emerald-500 text-emerald-900 ring-1 ring-emerald-400'
                                  : 'text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800'
                              }`}
                            />
                            <span className="text-slate-400">Kích:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.da_kich_hoat ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'da_kich_hoat', e.target.value)}
                              className={`w-20 border rounded px-1.5 py-0.5 text-right font-black ${
                                isAutoFilledUnit && (vals.da_kich_hoat || 0) > 0
                                  ? 'bg-emerald-100 border-emerald-500 text-emerald-900 ring-1 ring-emerald-400'
                                  : 'text-emerald-600 bg-white dark:bg-slate-800'
                              }`}
                            />
                          </div>
                        )}

                        {kpi.type === 'OVERDUE_RECORDS' && (
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400">Quá hạn ngày:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.qua_han_ngay ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'qua_han_ngay', e.target.value)}
                              className={`w-20 border rounded px-1.5 py-0.5 text-right font-black ${
                                isAutoFilledUnit && (vals.qua_han_ngay || 0) > 0
                                  ? 'bg-red-50 border-red-500 text-red-700 ring-2 ring-red-400'
                                  : 'text-red-600 bg-white dark:bg-slate-800'
                              }`}
                            />
                            <span className="text-slate-400">Số ngày tháng:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.so_ngay_phat_sinh_thang ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'so_ngay_phat_sinh_thang', e.target.value)}
                              className="w-16 border rounded px-1.5 py-0.5 text-right font-black text-amber-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                        )}

                        {kpi.type === 'DATA_CLEANING' && (
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400">Còn phải làm:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.con_phai_lam ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'con_phai_lam', e.target.value)}
                              className={`w-24 border rounded px-1.5 py-0.5 text-right font-black ${
                                isAutoFilledUnit && (vals.con_phai_lam || 0) > 0
                                  ? 'bg-emerald-100 border-emerald-500 text-emerald-900 ring-1 ring-emerald-400'
                                  : 'text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800'
                              }`}
                            />
                            <span className="text-[11px] text-slate-400">
                              (Lần trước: {prevVals?.con_phai_lam ?? '—'})
                            </span>
                          </div>
                        )}

                        {kpi.type === 'DIGITIZATION' && (
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400">Lũy kế:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.luy_ke ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'luy_ke', e.target.value)}
                              className={`w-24 border rounded px-1.5 py-0.5 text-right font-black ${
                                isAutoFilledUnit && (vals.luy_ke || 0) > 0
                                  ? 'bg-blue-100 border-blue-500 text-blue-900 ring-1 ring-blue-400'
                                  : 'text-blue-600 bg-white dark:bg-slate-800'
                              }`}
                            />
                            <span className="text-slate-400">Chỉ tiêu ngày:</span>
                            <input
                              type="number"
                              min="1"
                              value={vals.chi_tieu_ngay || kpi.defaultDailyTarget || 100}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'chi_tieu_ngay', e.target.value)}
                              className="w-16 border rounded px-1.5 py-0.5 text-right font-black text-slate-600 bg-white dark:bg-slate-800"
                            />
                          </div>
                        )}

                        {kpi.type === 'CUSTOM_RATIO' && (
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400">Giao:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.giao ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'giao', e.target.value)}
                              className="w-20 border rounded px-1.5 py-0.5 text-right font-black bg-white dark:bg-slate-800"
                            />
                            <span className="text-slate-400">Đạt:</span>
                            <input
                              type="number"
                              min="0"
                              value={vals.da_lam ?? 0}
                              onChange={(e) => handleValueChange(c.stt, kpi.id, 'da_lam', e.target.value)}
                              className="w-20 border rounded px-1.5 py-0.5 text-right font-black text-emerald-600 bg-white dark:bg-slate-800"
                            />
                          </div>
                        )}
                      </td>

                      {/* Kết quả tính tự động */}
                      <td className="p-2 border text-center font-bold text-slate-700 dark:text-slate-200">
                        {res.displayResult}
                      </td>

                      {/* Phân loại tự tính */}
                      <td className="p-2 border text-center">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-black inline-flex items-center gap-1 ${badgeColor}`}>
                          <span>{icon}</span>
                          <span>{label}</span>
                        </span>
                      </td>
                    </tr>
                  );
                });
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-between items-center border-t border-slate-200 dark:border-slate-700">
          <span className="text-[11px] text-slate-500 font-bold">
            *Các ô để trống được lưu thành 0 và duy trì hiển thị số 0 để tránh bỏ sót.
          </span>
          <div className="flex gap-2">
            <button
              onClick={handleSaveAll}
              type="button"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-lg text-xs shadow flex items-center gap-1.5 cursor-pointer transition"
            >
              <Save className="w-4 h-4" />
              <span>Lưu toàn bộ số liệu ngày vào hệ thống</span>
            </button>
            <button
              onClick={onClose}
              type="button"
              className="bg-slate-600 hover:bg-slate-500 text-white font-bold px-4 py-2 rounded-lg text-xs cursor-pointer transition"
            >
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
