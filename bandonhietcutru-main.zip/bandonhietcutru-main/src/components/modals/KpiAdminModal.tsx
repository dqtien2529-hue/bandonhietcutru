import React, { useState } from 'react';
import { KPI, KpiType } from '../../types';
import { formatDDMMYYYY } from '../../data/communes';
import { X, Plus, Trash2, RotateCcw, Settings2 } from 'lucide-react';

interface KpiAdminModalProps {
  isOpen: boolean;
  selectedDate: string;
  kpis: KPI[];
  onUpdateKpiName: (kpiId: string, name: string) => void;
  onUpdateKpiType: (kpiId: string, type: KpiType) => void;
  onUpdateKpiThreshGood: (kpiId: string, val: number) => void;
  onUpdateKpiThreshAvg: (kpiId: string, val: number) => void;
  onDeleteKpi: (kpiId: string) => void;
  onAddNewKpi: (name: string, type: KpiType, threshGood: number, threshAvg: number) => void;
  onResetDefaultData: () => void;
  onClose: () => void;
}

export const KpiAdminModal: React.FC<KpiAdminModalProps> = ({
  isOpen,
  selectedDate,
  kpis,
  onUpdateKpiName,
  onUpdateKpiType,
  onUpdateKpiThreshGood,
  onUpdateKpiThreshAvg,
  onDeleteKpi,
  onAddNewKpi,
  onResetDefaultData,
  onClose
}) => {
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<KpiType>('CUSTOM_RATIO');
  const [newGood, setNewGood] = useState('80');
  const [newAvg, setNewAvg] = useState('50');

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newName.trim();
    if (!name) return;
    const good = parseInt(newGood) || 80;
    const avg = parseInt(newAvg) || 50;
    onAddNewKpi(name, newType, good, avg);
    setNewName('');
    setNewGood('80');
    setNewAvg('50');
  };

  const handleReset = () => {
    if (window.confirm(`Xóa dữ liệu ngày ${formatDDMMYYYY(selectedDate)} và khôi phục 4 chỉ tiêu nghiệp vụ chuẩn ban đầu?`)) {
      onResetDefaultData();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-3xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-amber-800 text-white p-3.5 flex justify-between items-center border-b border-amber-400">
          <div className="flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-amber-300" />
            <h3 className="text-base font-bold text-amber-200 uppercase">
              QUẢN LÝ CHỈ TIÊU & CẤU HÌNH CÁCH TÍNH
            </h3>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-amber-200 hover:text-white p-1 rounded hover:bg-red-800 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-grow">
          {/* Explanation of Unit Overall Ranking Rule */}
          <div className="p-3 bg-amber-50 dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-slate-700 text-xs text-amber-900 dark:text-amber-300 space-y-1">
            <p className="font-bold">⚖️ Quy tắc tổng hợp xếp loại đơn vị xã/phường:</p>
            <p>• <strong>🟢 Đạt tốt (Xanh):</strong> Đạt toàn bộ (100%) các chỉ tiêu xanh đang áp dụng.</p>
            <p>• <strong>🟡 Trung bình (Vàng):</strong> Đạt từ 60% đến dưới 100% chỉ tiêu xanh.</p>
            <p>• <strong>🔴 Chậm (Đỏ):</strong> Đạt dưới 60% chỉ tiêu xanh hoặc phát sinh quá hạn.</p>
          </div>

          {/* Add KPI Form */}
          <form onSubmit={handleAdd} className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2.5">
            <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100 uppercase">
              Thêm chỉ tiêu mới vào hệ thống:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
              <input
                type="text"
                placeholder="Nhập tên chỉ tiêu..."
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="sm:col-span-6 border rounded px-2.5 py-1.5 bg-white dark:bg-slate-800 font-bold outline-none"
              />
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as KpiType)}
                className="sm:col-span-4 border rounded px-2 py-1.5 bg-white dark:bg-slate-800 font-bold outline-none"
              >
                <option value="CUSTOM_RATIO">Tỷ lệ % (Đạt / Giao)</option>
                <option value="RATIO_VNEID">Định danh mức 2 (Kích/Thu)</option>
                <option value="OVERDUE_RECORDS">Hồ sơ quá hạn</option>
                <option value="DATA_CLEANING">Làm sạch dân cư (Giảm số còn lại)</option>
                <option value="DIGITIZATION">Số hóa (Lũy kế trừ trước)</option>
              </select>
              <button
                type="submit"
                className="sm:col-span-2 bg-amber-600 hover:bg-amber-500 text-white font-bold px-3 py-1.5 rounded-lg flex items-center justify-center gap-1 cursor-pointer transition shadow"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm</span>
              </button>
            </div>
          </form>

          {/* List of KPIs */}
          <div className="space-y-3">
            <h4 className="font-bold text-xs text-slate-700 dark:text-slate-200 uppercase">
              Danh sách {kpis.length} chỉ tiêu đang áp dụng:
            </h4>
            {kpis.map((kpi) => {
              const typeLabels: Record<KpiType, string> = {
                RATIO_VNEID: 'Định danh mức 2 (≥90% Xanh, <90% Đỏ)',
                OVERDUE_RECORDS: 'Quá hạn (Ngày: =0 Xanh; Tháng: 0–4 ngày Xanh)',
                DATA_CLEANING: 'Làm sạch (So trước: giảm >50% Xanh, ≤50% Vàng, không giảm Đỏ)',
                DIGITIZATION: 'Số hóa (Lũy kế trừ trước: ≥100% Xanh, 50–99% Vàng, <50% Đỏ)',
                CUSTOM_RATIO: 'Tỷ lệ tùy chỉnh (% Đạt / Giao)'
              };

              return (
                <div
                  key={kpi.id}
                  className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col gap-2 text-xs font-bold shadow-sm"
                >
                  <div className="flex items-center justify-between gap-2">
                    <input
                      type="text"
                      value={kpi.name}
                      onChange={(e) => onUpdateKpiName(kpi.id, e.target.value)}
                      className="border border-slate-300 dark:border-slate-600 rounded px-2.5 py-1 w-full bg-white dark:bg-slate-800 font-bold text-slate-800 dark:text-slate-100"
                    />
                    {kpis.length > 1 && (
                      <button
                        onClick={() => onDeleteKpi(kpi.id)}
                        type="button"
                        className="text-red-600 font-bold px-2 py-1 hover:bg-red-50 dark:hover:bg-red-950/40 rounded whitespace-nowrap flex items-center gap-1 cursor-pointer transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Xóa</span>
                      </button>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 dark:bg-slate-900/60 p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px]">
                    <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300">
                      <span>Loại công thức:</span>
                      <span className="font-black text-amber-700 dark:text-amber-400">
                        {typeLabels[kpi.type] || kpi.type}
                      </span>
                    </div>

                    {kpi.type === 'CUSTOM_RATIO' && (
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <span className="text-emerald-600">🟢 Tốt ≥</span>
                          <input
                            type="number"
                            min="1"
                            max="100"
                            value={kpi.threshGood || 80}
                            onChange={(e) => onUpdateKpiThreshGood(kpi.id, parseInt(e.target.value) || 80)}
                            className="w-12 border rounded px-1 text-center font-bold"
                          />
                          <span>%</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-amber-600">🟡 TB ≥</span>
                          <input
                            type="number"
                            min="1"
                            max="99"
                            value={kpi.threshAvg || 50}
                            onChange={(e) => onUpdateKpiThreshAvg(kpi.id, parseInt(e.target.value) || 50)}
                            className="w-12 border rounded px-1 text-center font-bold"
                          />
                          <span>%</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-900 p-3 flex justify-between items-center border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={handleReset}
            type="button"
            className="text-red-600 hover:text-red-700 hover:bg-red-50 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 cursor-pointer transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Khôi phục 4 chỉ tiêu mặc định</span>
          </button>
          <button
            onClick={onClose}
            type="button"
            className="bg-slate-500 hover:bg-slate-400 text-white font-bold px-4 py-1.5 rounded-lg text-xs cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
