import React, { useState, useEffect } from 'react';
import { RankingRulesConfig, DEFAULT_RANKING_RULES } from '../../types';
import { X, Check, RotateCcw, Sliders, ShieldAlert, Award, FileSpreadsheet, Info } from 'lucide-react';

interface RankingRulesModalProps {
  isOpen: boolean;
  rules?: RankingRulesConfig;
  onSaveRules: (newRules: RankingRulesConfig) => void;
  onClose: () => void;
}

export const RankingRulesModal: React.FC<RankingRulesModalProps> = ({
  isOpen,
  rules = DEFAULT_RANKING_RULES,
  onSaveRules,
  onClose
}) => {
  const [formData, setFormData] = useState<RankingRulesConfig>({ ...DEFAULT_RANKING_RULES, ...rules });
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFormData({ ...DEFAULT_RANKING_RULES, ...rules });
      setSaveSuccess(false);
    }
  }, [isOpen, rules]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveRules(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 900);
  };

  const handleReset = () => {
    if (window.confirm('Khôi phục toàn bộ quy tắc xếp loại về thiết lập chuẩn ban đầu?')) {
      setFormData({ ...DEFAULT_RANKING_RULES });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-3 md:p-5">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-3xl w-full border border-amber-500 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-amber-950 text-white p-4 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm md:text-base text-amber-300 uppercase tracking-wide">
                CẤU HÌNH QUY TẮC XẾP LOẠI & ĐÁNH GIÁ ĐƠN VỊ
              </h3>
              <p className="text-[11px] text-amber-100/80">
                Điều chỉnh công thức tính toán, tỷ lệ ngưỡng phân loại Xanh - Vàng - Đỏ và cảnh báo
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-300 hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-4 md:p-6 overflow-y-auto space-y-5 text-xs text-slate-700 dark:text-slate-200">
          {/* Group 1: Quy tắc xếp loại Tổng hợp toàn Đơn vị */}
          <div className="bg-slate-50 dark:bg-slate-800/70 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-black text-sm border-b pb-1.5 border-slate-200 dark:border-slate-700">
              <Award className="w-4 h-4" />
              <span>1. QUY TẮC XẾP LOẠI TỔNG HỢP TOÀN ĐƠN VỊ (XÃ, PHƯỜNG)</span>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
              Đánh giá chung của đơn vị được tổng hợp dựa trên tỷ lệ số chỉ tiêu đạt trạng thái XANH so với tổng số chỉ tiêu đang áp dụng:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {/* Ngưỡng Tốt (Xanh) */}
              <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 p-3 rounded-lg flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-300 mb-1">
                    <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
                    <span>ĐẠT TỐT (XANH)</span>
                  </div>
                  <label className="text-[11px] text-slate-600 dark:text-slate-300 block mb-1">
                    Tỷ lệ chỉ tiêu xanh tối thiểu:
                  </label>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formData.overallGoodPercent}
                    onChange={(e) => setFormData({ ...formData, overallGoodPercent: Number(e.target.value) || 100 })}
                    className="w-20 px-2 py-1 font-bold text-center bg-white dark:bg-slate-900 border border-emerald-400 rounded outline-none"
                  />
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">%</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1">Mặc định: 100% (đạt toàn bộ)</span>
              </div>

              {/* Ngưỡng Trung bình (Vàng) */}
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 p-3 rounded-lg flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-amber-700 dark:text-amber-300 mb-1">
                    <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
                    <span>TRUNG BÌNH (VÀNG)</span>
                  </div>
                  <label className="text-[11px] text-slate-600 dark:text-slate-300 block mb-1">
                    Tỷ lệ chỉ tiêu xanh tối thiểu:
                  </label>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="1"
                    max="99"
                    value={formData.overallAvgPercent}
                    onChange={(e) => setFormData({ ...formData, overallAvgPercent: Number(e.target.value) || 60 })}
                    className="w-20 px-2 py-1 font-bold text-center bg-white dark:bg-slate-900 border border-amber-400 rounded outline-none"
                  />
                  <span className="font-bold text-amber-700 dark:text-amber-300">%</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1">Mặc định: 60% (từ 60% đến &lt;100%)</span>
              </div>

              {/* Chậm (Đỏ) */}
              <div className="bg-red-50 dark:bg-red-950/40 border border-red-300 dark:border-red-700 p-3 rounded-lg flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-red-700 dark:text-red-300 mb-1">
                    <span className="w-3 h-3 rounded-full bg-red-600 inline-block" />
                    <span>CHẬM / BÁO ĐỘNG (ĐỎ)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mb-1">
                    Tự động tính khi tỷ lệ xanh dưới ngưỡng Trung bình:
                  </p>
                </div>
                <div className="py-1">
                  <span className="font-bold text-red-600 dark:text-red-400 text-sm">
                    &lt; {formData.overallAvgPercent}% Xanh
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1">Dưới {formData.overallAvgPercent}% báo đỏ</span>
              </div>
            </div>

            {/* Cảnh báo đóng băng */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-500" />
                <span className="font-bold">Cảnh báo Đóng băng dữ liệu (Viền đỏ trên bản đồ):</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-600 dark:text-slate-400">Không có dữ liệu mới liên tiếp:</span>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={formData.frozenDaysThreshold}
                  onChange={(e) => setFormData({ ...formData, frozenDaysThreshold: Number(e.target.value) || 3 })}
                  className="w-16 px-2 py-1 font-bold text-center bg-white dark:bg-slate-900 border border-red-400 rounded outline-none"
                />
                <span className="font-bold">ngày</span>
              </div>
            </div>
          </div>

          {/* Group 2: Quy tắc từng chỉ tiêu */}
          <div className="bg-slate-50 dark:bg-slate-800/70 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-black text-sm border-b pb-1.5 border-slate-200 dark:border-slate-700">
              <FileSpreadsheet className="w-4 h-4" />
              <span>2. QUY TẮC & NGƯỠNG TỪNG CHỈ TIÊU NGHIỆP VỤ</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Chỉ tiêu 1 */}
              <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xs space-y-1.5">
                <h4 className="font-bold text-slate-900 dark:text-slate-100">
                  Chỉ tiêu 1 – Định danh điện tử mức 2
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Công thức: Tỷ lệ = Số đã kích hoạt / Tổng số đã thu nhận.
                </p>
                <div className="flex items-center justify-between pt-1">
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">Ngưỡng đạt Xanh (≥):</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={formData.ct1ThreshGood}
                      onChange={(e) => setFormData({ ...formData, ct1ThreshGood: Number(e.target.value) || 90 })}
                      className="w-16 px-2 py-1 font-bold text-center border border-slate-300 dark:border-slate-600 rounded"
                    />
                    <span className="font-bold">%</span>
                  </div>
                </div>
                <p className="text-[10px] text-red-500">Dưới {formData.ct1ThreshGood}% báo Đỏ; từ {formData.ct1ThreshGood}% trở lên đạt Xanh.</p>
              </div>

              {/* Chỉ tiêu 2 */}
              <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xs space-y-1.5">
                <h4 className="font-bold text-slate-900 dark:text-slate-100">
                  Chỉ tiêu 2 – Hồ sơ quá hạn
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Trong ngày: có phát sinh (&gt;0 hồ sơ) là Đỏ, 0 hồ sơ là Xanh.
                </p>
                <div className="flex items-center justify-between pt-1">
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">Theo tháng/quý: số ngày tối đa đạt Xanh:</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="0"
                      max="31"
                      value={formData.ct2MonthMaxGoodDays}
                      onChange={(e) => setFormData({ ...formData, ct2MonthMaxGoodDays: Number(e.target.value) || 4 })}
                      className="w-16 px-2 py-1 font-bold text-center border border-slate-300 dark:border-slate-600 rounded"
                    />
                    <span className="font-bold">ngày</span>
                  </div>
                </div>
                <p className="text-[10px] text-red-500">Từ {formData.ct2MonthMaxGoodDays + 1} ngày phát sinh trở lên báo Đỏ.</p>
              </div>

              {/* Chỉ tiêu 3 */}
              <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xs space-y-1.5">
                <h4 className="font-bold text-slate-900 dark:text-slate-100">
                  Chỉ tiêu 3 – Làm sạch dữ liệu dân cư
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  So số còn phải làm với kỳ trước. Không giảm hoặc tăng là Đỏ.
                </p>
                <div className="flex items-center justify-between pt-1">
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">Giảm trên mức này là Xanh:</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="1"
                      max="99"
                      value={formData.ct3GiamGoodPercent}
                      onChange={(e) => setFormData({ ...formData, ct3GiamGoodPercent: Number(e.target.value) || 50 })}
                      className="w-16 px-2 py-1 font-bold text-center border border-slate-300 dark:border-slate-600 rounded"
                    />
                    <span className="font-bold">%</span>
                  </div>
                </div>
                <p className="text-[10px] text-amber-600">Giảm từ 0% đến ≤{formData.ct3GiamGoodPercent}% là Vàng; trên {formData.ct3GiamGoodPercent}% là Xanh.</p>
              </div>

              {/* Chỉ tiêu 4 */}
              <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xs space-y-1.5">
                <h4 className="font-bold text-slate-900 dark:text-slate-100">
                  Chỉ tiêu 4 – Số hóa tàng thư
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Số làm trong ngày = Lũy kế hiện tại - Lũy kế hôm trước. So với chỉ tiêu ngày:
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">Đạt Xanh (≥):</span>
                    <input
                      type="number"
                      min="1"
                      max="200"
                      value={formData.ct4DailyGoodPercent}
                      onChange={(e) => setFormData({ ...formData, ct4DailyGoodPercent: Number(e.target.value) || 100 })}
                      className="w-14 px-1.5 py-1 font-bold text-center border border-slate-300 dark:border-slate-600 rounded"
                    />
                    <span className="font-bold">%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-amber-600 dark:text-amber-400 font-bold">Vàng (≥):</span>
                    <input
                      type="number"
                      min="1"
                      max="99"
                      value={formData.ct4DailyAvgPercent}
                      onChange={(e) => setFormData({ ...formData, ct4DailyAvgPercent: Number(e.target.value) || 50 })}
                      className="w-14 px-1.5 py-1 font-bold text-center border border-slate-300 dark:border-slate-600 rounded"
                    />
                    <span className="font-bold">%</span>
                  </div>
                </div>
                <p className="text-[10px] text-red-500">Dưới {formData.ct4DailyAvgPercent}% báo Đỏ; từ {formData.ct4DailyGoodPercent}% trở lên là Xanh.</p>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={handleReset}
              className="px-3 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Khôi phục mặc định</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer transition text-xs"
              >
                Hủy bỏ
              </button>

              <button
                type="submit"
                className="px-5 py-2 bg-gradient-to-r from-red-700 to-amber-600 hover:from-red-600 hover:to-amber-500 text-white font-bold rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer text-xs"
              >
                {saveSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-300" />
                    <span>Đã lưu thành công!</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Lưu & Áp dụng quy tắc</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
