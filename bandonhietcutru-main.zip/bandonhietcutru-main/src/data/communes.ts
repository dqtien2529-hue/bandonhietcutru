import { Commune, KPI } from '../types';

export const OFFICIAL_102_COMMUNES: Commune[] = [
  { stt: 1, name: "Phường Bình Kiến" },
  { stt: 2, name: "Phường Buôn Hồ" },
  { stt: 3, name: "Phường Buôn Ma Thuột" },
  { stt: 4, name: "Phường Cư Bao" },
  { stt: 5, name: "Phường Đông Hòa" },
  { stt: 6, name: "Phường Ea Kao" },
  { stt: 7, name: "Phường Hòa Hiệp" },
  { stt: 8, name: "Phường Phú Yên" },
  { stt: 9, name: "Phường Sông Cầu" },
  { stt: 10, name: "Phường Tân An" },
  { stt: 11, name: "Phường Tân Lập" },
  { stt: 12, name: "Phường Tuy Hòa" },
  { stt: 13, name: "Phường Thành Nhất" },
  { stt: 14, name: "Phường Xuân Đài" },
  { stt: 15, name: "Xã Buôn Đôn" },
  { stt: 16, name: "Xã Cuôr Đăng" },
  { stt: 17, name: "Xã Cư M'gar" },
  { stt: 18, name: "Xã Cư M'ta" },
  { stt: 19, name: "Xã Cư Pong" },
  { stt: 20, name: "Xã Cư Prao" },
  { stt: 21, name: "Xã Cư Pui" },
  { stt: 22, name: "Xã Cư Yang" },
  { stt: 23, name: "Xã Dang Kang" },
  { stt: 24, name: "Xã Dliê Ya" },
  { stt: 25, name: "Xã Dray Bhăng" },
  { stt: 26, name: "Xã Dur Kmăl" },
  { stt: 27, name: "Xã Đắk Liêng" },
  { stt: 28, name: "Xã Đắk Phoi" },
  { stt: 29, name: "Xã Đồng Xuân" },
  { stt: 30, name: "Xã Đức Bình" },
  { stt: 31, name: "Xã Ea Bá" },
  { stt: 32, name: "Xã Ea Bung" },
  { stt: 33, name: "Xã Ea Drăng" },
  { stt: 34, name: "Xã Ea Drông" },
  { stt: 35, name: "Xã Ea H'Leo" },
  { stt: 36, name: "Xã Ea Hiao" },
  { stt: 37, name: "Xã Ea Kar" },
  { stt: 38, name: "Xã Ea Kiết" },
  { stt: 39, name: "Xã Ea Kly" },
  { stt: 40, name: "Xã Ea Knốp" },
  { stt: 41, name: "Xã Ea Knuếc" },
  { stt: 42, name: "Xã Ea Ktur" },
  { stt: 43, name: "Xã Ea Khăl" },
  { stt: 44, name: "Xã Ea Ly" },
  { stt: 45, name: "Xã Ea M'Droh" },
  { stt: 46, name: "Xã Ea Na" },
  { stt: 47, name: "Xã Ea Ning" },
  { stt: 48, name: "Xã Ea Nuôl" },
  { stt: 49, name: "Xã Ea Ô" },
  { stt: 50, name: "Xã Ea Păl" },
  { stt: 51, name: "Xã Ea Phê" },
  { stt: 52, name: "Xã Ea Riêng" },
  { stt: 53, name: "Xã Ea Rốk" },
  { stt: 54, name: "Xã Ea Súp" },
  { stt: 55, name: "Xã Ea Tul" },
  { stt: 56, name: "Xã Ea Trang" },
  { stt: 57, name: "Xã Ea Wer" },
  { stt: 58, name: "Xã Ea Wy" },
  { stt: 59, name: "Xã Hòa Mỹ" },
  { stt: 60, name: "Xã Hòa Phú" },
  { stt: 61, name: "Xã Hòa Sơn" },
  { stt: 62, name: "Xã Hòa Thịnh" },
  { stt: 63, name: "Xã Hòa Xuân" },
  { stt: 64, name: "Xã Ia Lốp" },
  { stt: 65, name: "Xã Ia R'vê" },
  { stt: 66, name: "Xã Krông Á" },
  { stt: 67, name: "Xã Krông Ana" },
  { stt: 68, name: "Xã Krông Bông" },
  { stt: 69, name: "Xã Krông Búk" },
  { stt: 70, name: "Xã Krông Năng" },
  { stt: 71, name: "Xã Krông Nô" },
  { stt: 72, name: "Xã Krông Pắc" },
  { stt: 73, name: "Xã Liên Sơn Lắk" },
  { stt: 74, name: "Xã M'Đrắk" },
  { stt: 75, name: "Xã Nam Ka" },
  { stt: 76, name: "Xã Ô Loan" },
  { stt: 77, name: "Xã Pơng Drang" },
  { stt: 78, name: "Xã Phú Hòa 1" },
  { stt: 79, name: "Xã Phú Hòa 2" },
  { stt: 80, name: "Xã Phú Mỡ" },
  { stt: 81, name: "Xã Phú Xuân" },
  { stt: 82, name: "Xã Quảng Phú" },
  { stt: 83, name: "Xã Sông Hinh" },
  { stt: 84, name: "Xã Sơn Hòa" },
  { stt: 85, name: "Xã Sơn Thành" },
  { stt: 86, name: "Xã Suối Trai" },
  { stt: 87, name: "Xã Tam Giang" },
  { stt: 88, name: "Xã Tân Tiến" },
  { stt: 89, name: "Xã Tây Hòa" },
  { stt: 90, name: "Xã Tây Sơn" },
  { stt: 91, name: "Xã Tuy An Bắc" },
  { stt: 92, name: "Xã Tuy An Đông" },
  { stt: 93, name: "Xã Tuy An Nam" },
  { stt: 94, name: "Xã Tuy An Tây" },
  { stt: 95, name: "Xã Vân Hòa" },
  { stt: 96, name: "Xã Vụ Bổn" },
  { stt: 97, name: "Xã Xuân Cảnh" },
  { stt: 98, name: "Xã Xuân Lãnh" },
  { stt: 99, name: "Xã Xuân Lộc" },
  { stt: 100, name: "Xã Xuân Phước" },
  { stt: 101, name: "Xã Xuân Thọ" },
  { stt: 102, name: "Xã Yang Mao" }
];

// 4 Official Default KPIs (Chỉ tiêu 5 mặc định đã được bỏ)
export const DEFAULT_KPIS: KPI[] = [
  {
    id: 'kpi_1',
    name: '1. Kích hoạt định danh điện tử VNeID mức độ 2',
    shortName: 'VNeID Mức 2',
    type: 'RATIO_VNEID',
    description: 'Tỷ lệ = Đã kích hoạt / Đã thu nhận. Dưới 90% báo Đỏ; từ 90% trở lên đạt ngưỡng Xanh.',
    threshGood: 90,
    threshAvg: 80
  },
  {
    id: 'kpi_2',
    name: '2. Giải quyết hồ sơ cư trú quá hạn',
    shortName: 'Hồ sơ quá hạn',
    type: 'OVERDUE_RECORDS',
    description: 'Trong ngày: có phát sinh là Đỏ. Theo tháng: 0–4 ngày phát sinh là Xanh, từ 5 ngày trở lên là Đỏ.',
    threshGood: 0,
    threshAvg: 4
  },
  {
    id: 'kpi_3',
    name: '3. Làm sạch dữ liệu dân cư',
    shortName: 'Làm sạch dân cư',
    type: 'DATA_CLEANING',
    description: 'So số còn phải làm với lần trước: không giảm hoặc tăng là Đỏ; giảm đến 50% là Vàng; giảm trên 50% là Xanh.',
    threshGood: 50,
    threshAvg: 0
  },
  {
    id: 'kpi_4',
    name: '4. Số hóa tàng thư cư trú',
    shortName: 'Số hóa tàng thư',
    type: 'DIGITIZATION',
    description: 'Số làm trong ngày = Lũy kế hiện tại trừ ngày trước. So chỉ tiêu ngày: dưới 50% Đỏ, 50%–dưới 100% Vàng, từ 100% trở lên Xanh.',
    defaultDailyTarget: 100,
    threshGood: 100,
    threshAvg: 50
  }
];

// Safe date helpers avoiding UTC timezone shifts
export function formatDateYMD(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDateSafe(dateStr: string): { year: number; month: number; day: number } {
  if (!dateStr || typeof dateStr !== 'string') {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() };
  }
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const d = parseInt(parts[2], 10);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
      return { year: y, month: m, day: d };
    }
  }
  const now = new Date();
  return { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() };
}

export function formatDDMMYY(dateStr: string): string {
  if (!dateStr) return '';
  const { year, month, day } = parseDateSafe(dateStr);
  const dd = String(day).padStart(2, '0');
  const mm = String(month).padStart(2, '0');
  const yy = String(year).slice(-2);
  return `${dd}/${mm}/${yy}`;
}

export function formatDDMMYYYY(dateStr: string): string {
  if (!dateStr) return '';
  const { year, month, day } = parseDateSafe(dateStr);
  const dd = String(day).padStart(2, '0');
  const mm = String(month).padStart(2, '0');
  return `${dd}/${mm}/${year}`;
}

export function getAdjacentDate(dateStr: string, offsetDays: number): string {
  const { year, month, day } = parseDateSafe(dateStr);
  const d = new Date(year, month - 1, day + offsetDays);
  return formatDateYMD(d);
}

export function normalizeMapUnitName(value: string): string {
  return String(value || '')
    .replace(/^(xã|phường)\s+/i, '')
    .toLowerCase()
    .replace(/đ/g, 'd')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
}
