export interface Commune {
  stt: number;
  name: string;
}

export type KpiType = 
  | 'RATIO_VNEID'      // CT1: Đã kích hoạt / Đã thu nhận, <90% đỏ, >=90% xanh
  | 'OVERDUE_RECORDS'  // CT2: Hồ sơ quá hạn: trong ngày có phát sinh là đỏ; tháng 0-4 ngày xanh, >=5 ngày đỏ
  | 'DATA_CLEANING'    // CT3: Số còn phải làm so với trước: không giảm/tăng: đỏ, giảm <=50%: vàng, giảm >50%: xanh
  | 'DIGITIZATION'     // CT4: Lũy kế trừ trước = số ngày. So chỉ tiêu ngày: <50% đỏ, 50-99% vàng, >=100% xanh
  | 'CUSTOM_RATIO';    // Chỉ tiêu thêm mới tùy chỉnh

export interface KPI {
  id: string;
  name: string;
  type: KpiType;
  shortName: string;
  description: string;
  // Thresholds for custom or configured KPIs
  threshGood?: number;
  threshAvg?: number;
  defaultDailyTarget?: number; // Cho CT4 hoặc các chỉ tiêu có định mức ngày
}

export interface CommuneKPIValues {
  // Fields for CT1 (Định danh mức 2)
  da_thu_nhan?: number;
  da_kich_hoat?: number;

  // Fields for CT2 (Hồ sơ quá hạn)
  qua_han_ngay?: number; // Số phát sinh trong ngày
  so_ngay_phat_sinh_thang?: number; // Số ngày phát sinh trong tháng (nhập riêng hoặc tính)

  // Fields for CT3 (Làm sạch dữ liệu)
  con_phai_lam?: number; // Số trường hợp còn phải làm

  // Fields for CT4 (Số hóa tàng thư)
  luy_ke?: number; // Tổng lũy kế đến ngày nhập
  chi_tieu_ngay?: number; // Chỉ tiêu được giao mỗi ngày

  // Generic fallback fields
  giao?: number;
  da_lam?: number;
  ngay_hom_nay?: number;
  reported?: boolean;
}

export interface CommuneEntry {
  stats: Record<string, CommuneKPIValues>;
  last_updated_days_ago?: number;
}

export interface RankingRulesConfig {
  overallGoodPercent: number;      // % chỉ tiêu xanh để đạt Tốt (Mặc định 100%)
  overallAvgPercent: number;       // % chỉ tiêu xanh tối thiểu để đạt Trung bình (Mặc định 60%)
  frozenDaysThreshold: number;     // Số ngày chưa có phát sinh số liệu để cảnh báo viền đỏ (Mặc định 3 ngày)
  ct1ThreshGood: number;           // Định danh mức 2: Tỷ lệ đạt chuẩn (Mặc định 90%)
  ct2MonthMaxGoodDays: number;     // Hồ sơ quá hạn (tháng): Số ngày tối đa để đạt xanh (Mặc định 4 ngày)
  ct3GiamGoodPercent: number;      // Làm sạch dữ liệu: Giảm trên mức này là Xanh (Mặc định 50%)
  ct4DailyGoodPercent: number;     // Số hóa tàng thư: Đạt từ mức này trở lên là Xanh (Mặc định 100%)
  ct4DailyAvgPercent: number;      // Số hóa tàng thư: Đạt từ mức này đến dưới mức tốt là Vàng (Mặc định 50%)
}

export const DEFAULT_RANKING_RULES: RankingRulesConfig = {
  overallGoodPercent: 100,
  overallAvgPercent: 60,
  frozenDaysThreshold: 3,
  ct1ThreshGood: 90,
  ct2MonthMaxGoodDays: 4,
  ct3GiamGoodPercent: 50,
  ct4DailyGoodPercent: 100,
  ct4DailyAvgPercent: 50
};

export interface AppState {
  kpis: KPI[];
  selectedKpiId: string;
  selectedPeriod: 'day' | 'month' | 'quarter' | 'year'; // No week!
  selectedDate: string; // YYYY-MM-DD
  searchQuery: string;
  tableFilterStatus: 'all' | 'green' | 'yellow' | 'red';
  mapZoom: number;
  mapFilter: 'all' | 'green' | 'yellow' | 'red';
  communeData: Record<number, CommuneEntry>;
  rankingRules?: RankingRulesConfig;
  kioskRunning: boolean;
  kioskStep: number;
}

export interface ComputedKPIResult {
  kpiId: string;
  kpiName: string;
  kpiType: KpiType;
  displayInput: string;       // Text mô tả số liệu nhập (vd: "Thu: 1.000, Kích: 920")
  displayResult: string;      // Text kết quả tính (vd: "92.0%", "0 hồ sơ", "Giảm 60.5%", "120/100 hồ sơ")
  status: 'green' | 'yellow' | 'red' | 'none';
  percent?: number;
  isFirstTime?: boolean;      // Dành cho CT3, CT4 khi lần đầu nhập
  details: Record<string, any>;
}

export interface ComputedCommuneStats {
  kpiResults: Record<string, ComputedKPIResult>;
  totalKpis: number;
  greenKpisCount: number;
  yellowKpisCount: number;
  redKpisCount: number;
  greenKpiPercent: number;    // Tỷ lệ % số chỉ tiêu xanh
  overallStatus: 'green' | 'yellow' | 'red' | 'none'; // Xanh nếu 100%, Vàng nếu 60-99%, Đỏ nếu <60%
  isFrozen: boolean;
  primaryMetricDisplay: string; // Hiển thị chính trên bản đồ/thẻ theo KPI đang chọn
}

export interface ComputedCommune extends Commune {
  computed: ComputedCommuneStats;
}

export interface CsvPreviewRow {
  stt: number;
  name: string;
  kpiValues: Record<string, any>;
  computedPreview?: Record<string, { displayResult: string; status: 'green' | 'yellow' | 'red' | 'none' }>;
  confidence?: number;
  isUncertain?: boolean;
  error?: string;
}
