import { KPI, CommuneEntry, ComputedCommuneStats, ComputedCommune, ComputedKPIResult, CommuneKPIValues, RankingRulesConfig, DEFAULT_RANKING_RULES } from '../types';
import { OFFICIAL_102_COMMUNES } from '../data/communes';

export function evaluateKPI(
  kpi: KPI,
  currentValues: CommuneKPIValues | undefined,
  previousValues: CommuneKPIValues | undefined,
  period: 'day' | 'month' | 'quarter' | 'year' = 'day',
  rules: RankingRulesConfig = DEFAULT_RANKING_RULES
): ComputedKPIResult {
  const vals: CommuneKPIValues = currentValues || {};
  const prev: CommuneKPIValues | undefined = previousValues;

  switch (kpi.type) {
    case 'RATIO_VNEID': {
      const da_thu_nhan = vals.da_thu_nhan ?? vals.giao ?? 0;
      const da_kich_hoat = vals.da_kich_hoat ?? vals.da_lam ?? 0;
      const percent = da_thu_nhan > 0 ? parseFloat(((da_kich_hoat / da_thu_nhan) * 100).toFixed(1)) : 0;
      
      let status: 'green' | 'yellow' | 'red' | 'none' = 'none';
      const targetGood = rules.ct1ThreshGood ?? kpi.threshGood ?? 90;
      if (da_thu_nhan > 0) {
        status = percent >= targetGood ? 'green' : 'red';
      }

      return {
        kpiId: kpi.id,
        kpiName: kpi.name,
        kpiType: kpi.type,
        displayInput: `Thu: ${da_thu_nhan.toLocaleString()}, Kích: ${da_kich_hoat.toLocaleString()}`,
        displayResult: da_thu_nhan > 0 ? `${percent}%` : 'Chưa nhập',
        status,
        percent,
        details: { da_thu_nhan, da_kich_hoat }
      };
    }

    case 'OVERDUE_RECORDS': {
      if (period === 'month' || period === 'quarter' || period === 'year') {
        const so_ngay = vals.so_ngay_phat_sinh_thang ?? (vals.qua_han_ngay && vals.qua_han_ngay > 0 ? 1 : 0);
        const maxGood = rules.ct2MonthMaxGoodDays ?? 4;
        const status = so_ngay <= maxGood ? 'green' : 'red';
        return {
          kpiId: kpi.id,
          kpiName: kpi.name,
          kpiType: kpi.type,
          displayInput: `${so_ngay} ngày phát sinh`,
          displayResult: `${so_ngay} ngày (${status === 'green' ? `🟢 ≤${maxGood} ngày` : `🔴 ≥${maxGood + 1} ngày`})`,
          status,
          details: { so_ngay_phat_sinh_thang: so_ngay }
        };
      }

      // Theo ngày
      const qua_han_ngay = vals.qua_han_ngay ?? 0;
      const status = qua_han_ngay > 0 ? 'red' : 'green';
      return {
        kpiId: kpi.id,
        kpiName: kpi.name,
        kpiType: kpi.type,
        displayInput: `${qua_han_ngay} hồ sơ quá hạn`,
        displayResult: qua_han_ngay > 0 ? `🔴 ${qua_han_ngay} quá hạn` : '🟢 0 hồ sơ',
        status,
        details: { qua_han_ngay }
      };
    }

    case 'DATA_CLEANING': {
      const con_phai_lam = vals.con_phai_lam ?? 0;
      if (!prev || prev.con_phai_lam === undefined || prev.con_phai_lam === null) {
        return {
          kpiId: kpi.id,
          kpiName: kpi.name,
          kpiType: kpi.type,
          displayInput: `Còn: ${con_phai_lam.toLocaleString()}`,
          displayResult: 'Lần đầu (chưa đối chiếu)',
          status: 'none',
          isFirstTime: true,
          details: { con_phai_lam }
        };
      }

      const con_phai_lam_truoc = prev.con_phai_lam ?? con_phai_lam;
      const diffGiam = con_phai_lam_truoc - con_phai_lam;
      const giamPercent = con_phai_lam_truoc > 0 ? parseFloat(((diffGiam / con_phai_lam_truoc) * 100).toFixed(1)) : 0;

      let status: 'green' | 'yellow' | 'red' = 'red';
      let resultText = '';
      const goodGiam = rules.ct3GiamGoodPercent ?? 50;

      if (diffGiam <= 0) {
        status = 'red';
        resultText = diffGiam === 0 ? '🔴 Không giảm (0%)' : `🔴 Tăng +${Math.abs(diffGiam)}`;
      } else if (giamPercent <= goodGiam) {
        status = 'yellow';
        resultText = `🟡 Giảm ${giamPercent}% (≤${goodGiam}%)`;
      } else {
        status = 'green';
        resultText = `🟢 Giảm ${giamPercent}% (>${goodGiam}%)`;
      }

      return {
        kpiId: kpi.id,
        kpiName: kpi.name,
        kpiType: kpi.type,
        displayInput: `Còn: ${con_phai_lam.toLocaleString()} (Trước: ${con_phai_lam_truoc.toLocaleString()})`,
        displayResult: resultText,
        status,
        percent: giamPercent,
        details: { con_phai_lam, con_phai_lam_truoc, diffGiam, giamPercent }
      };
    }

    case 'DIGITIZATION': {
      const luy_ke = vals.luy_ke ?? vals.da_lam ?? 0;
      const chi_tieu_ngay = vals.chi_tieu_ngay || kpi.defaultDailyTarget || 100;

      const isFirst = !prev || prev.luy_ke === undefined || prev.luy_ke === null;
      const luy_ke_truoc = isFirst ? 0 : (prev.luy_ke ?? 0);
      const so_lam_ngay = isFirst ? luy_ke : Math.max(0, luy_ke - luy_ke_truoc);

      const percent = chi_tieu_ngay > 0 ? parseFloat(((so_lam_ngay / chi_tieu_ngay) * 100).toFixed(1)) : 0;
      const goodThresh = rules.ct4DailyGoodPercent ?? 100;
      const avgThresh = rules.ct4DailyAvgPercent ?? 50;

      let status: 'green' | 'yellow' | 'red' = 'red';
      if (percent < avgThresh) status = 'red';
      else if (percent < goodThresh) status = 'yellow';
      else status = 'green';

      return {
        kpiId: kpi.id,
        kpiName: kpi.name,
        kpiType: kpi.type,
        displayInput: `Lũy kế: ${luy_ke.toLocaleString()} (Chỉ tiêu ngày: ${chi_tieu_ngay})`,
        displayResult: `+${so_lam_ngay.toLocaleString()} (${percent}%)`,
        status,
        percent,
        isFirstTime: isFirst,
        details: { luy_ke, luy_ke_truoc, so_lam_ngay, chi_tieu_ngay, percent }
      };
    }

    default: {
      // CUSTOM_RATIO fallback
      const giao = vals.giao || 0;
      const da_lam = vals.da_lam || 0;
      const percent = giao > 0 ? parseFloat(((da_lam / giao) * 100).toFixed(1)) : 0;
      const threshGood = kpi.threshGood ?? 80;
      const threshAvg = kpi.threshAvg ?? 50;

      let status: 'green' | 'yellow' | 'red' | 'none' = 'none';
      if (giao > 0) {
        if (percent >= threshGood) status = 'green';
        else if (percent >= threshAvg) status = 'yellow';
        else status = 'red';
      }

      return {
        kpiId: kpi.id,
        kpiName: kpi.name,
        kpiType: kpi.type,
        displayInput: `Giao: ${giao}, Đạt: ${da_lam}`,
        displayResult: `${percent}%`,
        status,
        percent,
        details: { giao, da_lam }
      };
    }
  }
}

export function computeCommuneStats(
  communeData: Record<number, CommuneEntry>,
  previousCommuneData: Record<number, CommuneEntry> | undefined,
  kpis: KPI[],
  stt: number,
  selectedKpiId: string,
  period: 'day' | 'month' | 'quarter' | 'year' = 'day',
  rules: RankingRulesConfig = DEFAULT_RANKING_RULES
): ComputedCommuneStats {
  const currentEntry = communeData[stt] || { stats: {}, last_updated_days_ago: 0 };
  const prevEntry = previousCommuneData?.[stt];

  const kpiResults: Record<string, ComputedKPIResult> = {};
  let greenCount = 0;
  let yellowCount = 0;
  let redCount = 0;

  kpis.forEach(kpi => {
    const curVal = currentEntry.stats?.[kpi.id];
    const prevVal = prevEntry?.stats?.[kpi.id];
    const res = evaluateKPI(kpi, curVal, prevVal, period, rules);
    kpiResults[kpi.id] = res;

    if (res.status === 'green') greenCount++;
    else if (res.status === 'yellow') yellowCount++;
    else if (res.status === 'red') redCount++;
  });

  const totalKpis = kpis.length;
  const greenKpiPercent = totalKpis > 0 ? parseFloat(((greenCount / totalKpis) * 100).toFixed(1)) : 0;

  // Tổng hợp xếp loại của Đơn vị theo quy tắc có thể cấu hình:
  const targetGood = rules.overallGoodPercent ?? 100;
  const targetAvg = rules.overallAvgPercent ?? 60;

  let overallStatus: 'green' | 'yellow' | 'red' | 'none' = 'red';
  if (totalKpis === 0) {
    overallStatus = 'none';
  } else if (greenKpiPercent >= targetGood) {
    overallStatus = 'green';
  } else if (greenKpiPercent >= targetAvg) {
    overallStatus = 'yellow';
  } else {
    overallStatus = 'red';
  }

  // Primary metric display based on selected KPI
  let primaryMetricDisplay = `${greenCount}/${totalKpis} Xanh (${greenKpiPercent}%)`;
  if (selectedKpiId !== 'all') {
    const chosenRes = kpiResults[selectedKpiId];
    if (chosenRes) {
      primaryMetricDisplay = chosenRes.displayResult;
    }
  }

  const frozenThreshold = rules.frozenDaysThreshold ?? 3;

  return {
    kpiResults,
    totalKpis,
    greenKpisCount: greenCount,
    yellowKpisCount: yellowCount,
    redKpisCount: redCount,
    greenKpiPercent,
    overallStatus,
    isFrozen: (currentEntry.last_updated_days_ago ?? 0) >= frozenThreshold,
    primaryMetricDisplay
  };
}

export function computeSummaryData(
  communeData: Record<number, CommuneEntry>,
  previousCommuneData: Record<number, CommuneEntry> | undefined,
  kpis: KPI[],
  selectedKpiId: string,
  period: 'day' | 'month' | 'quarter' | 'year' = 'day',
  rules: RankingRulesConfig = DEFAULT_RANKING_RULES
) {
  let greenUnitsCount = 0;
  let yellowUnitsCount = 0;
  let redUnitsCount = 0;
  let noDataCount = 0;
  let frozenCount = 0;

  const computedList: ComputedCommune[] = OFFICIAL_102_COMMUNES.map(c => {
    const res = computeCommuneStats(communeData, previousCommuneData, kpis, c.stt, selectedKpiId, period, rules);

    // If looking at a specific KPI, color and classify based on that KPI's status
    const statusToCheck = selectedKpiId === 'all' ? res.overallStatus : (res.kpiResults[selectedKpiId]?.status || 'none');

    if (statusToCheck === 'green') greenUnitsCount++;
    else if (statusToCheck === 'yellow') yellowUnitsCount++;
    else if (statusToCheck === 'none') noDataCount++;
    else redUnitsCount++;

    if (res.isFrozen) frozenCount++;

    return { ...c, computed: res };
  });

  const total = computedList.length || 1;
  const overallGreenPercent = ((greenUnitsCount / total) * 100).toFixed(1);

  return {
    computedList,
    greenUnitsCount,
    greenPercent: overallGreenPercent,
    yellowUnitsCount,
    yellowPercent: ((yellowUnitsCount / total) * 100).toFixed(1),
    redUnitsCount,
    redPercent: ((redUnitsCount / total) * 100).toFixed(1),
    noDataCount,
    frozenCount,
    overallPct: `${overallGreenPercent}%`
  };
}
