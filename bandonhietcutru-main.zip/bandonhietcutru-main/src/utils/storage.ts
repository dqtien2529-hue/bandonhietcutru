import { AppState, KPI, DEFAULT_RANKING_RULES } from '../types';
import { DEFAULT_KPIS, OFFICIAL_102_COMMUNES } from '../data/communes';

const STORAGE_PREFIX = 'daklak-kpi-report:v1:';

export function getSavedDates(): string[] {
  try {
    return Object.keys(localStorage)
      .filter(key => key.startsWith(STORAGE_PREFIX))
      .map(key => key.slice(STORAGE_PREFIX.length))
      .filter(date => /^\d{4}-\d{2}-\d{2}$/.test(date))
      .sort();
  } catch (e) {
    console.error(e);
    return [];
  }
}

export function readDateRecord(date: string): { state: AppState; version: number; updated_at: string } | null {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + date);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.error(e);
    return null;
  }
}

export function writeDateRecord(date: string, state: AppState, version: number): void {
  try {
    const cleanSnapshot: AppState = {
      ...state,
      kioskRunning: false,
      kioskStep: 0
    };
    const record = {
      state: cleanSnapshot,
      version,
      updated_at: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_PREFIX + date, JSON.stringify(record));
  } catch (e) {
    console.error(e);
  }
}

export function createDefaultState(date: string, customKpis?: KPI[]): AppState {
  const kpis: KPI[] = customKpis && customKpis.length > 0
    ? JSON.parse(JSON.stringify(customKpis))
    : JSON.parse(JSON.stringify(DEFAULT_KPIS));

  const communeData: AppState['communeData'] = {};

  OFFICIAL_102_COMMUNES.forEach(c => {
    const statsObj: Record<string, any> = {};
    kpis.forEach((kpi: KPI) => {
      statsObj[kpi.id] = {
        da_thu_nhan: 0,
        da_kich_hoat: 0,
        qua_han_ngay: 0,
        so_ngay_phat_sinh_thang: 0,
        con_phai_lam: 0,
        luy_ke: 0,
        chi_tieu_ngay: kpi.defaultDailyTarget || 100,
        giao: 0,
        da_lam: 0,
        ngay_hom_nay: 0,
        reported: false
      };
    });
    communeData[c.stt] = { stats: statsObj, last_updated_days_ago: 0 };
  });

  return {
    kpis,
    selectedKpiId: 'all',
    selectedPeriod: 'day',
    selectedDate: date,
    searchQuery: '',
    tableFilterStatus: 'all',
    mapZoom: 1.0,
    mapFilter: 'all',
    communeData,
    rankingRules: { ...DEFAULT_RANKING_RULES },
    kioskRunning: false,
    kioskStep: 0
  };
}

export function normalizeAppState(saved: any, date: string): AppState {
  if (!saved || typeof saved !== 'object') return createDefaultState(date);
  const base = createDefaultState(date, saved.kpis);

  const mergedKpis: KPI[] = Array.isArray(saved.kpis) && saved.kpis.length > 0
    ? saved.kpis
    : base.kpis;

  const mergedCommuneData: AppState['communeData'] = {};
  OFFICIAL_102_COMMUNES.forEach(c => {
    const existing = saved.communeData?.[c.stt];
    const statsObj: Record<string, any> = {};
    mergedKpis.forEach(kpi => {
      const s = existing?.stats?.[kpi.id];
      statsObj[kpi.id] = {
        da_thu_nhan: Number(s?.da_thu_nhan ?? s?.giao ?? 0),
        da_kich_hoat: Number(s?.da_kich_hoat ?? s?.da_lam ?? 0),
        qua_han_ngay: Number(s?.qua_han_ngay ?? 0),
        so_ngay_phat_sinh_thang: Number(s?.so_ngay_phat_sinh_thang ?? 0),
        con_phai_lam: Number(s?.con_phai_lam ?? 0),
        luy_ke: Number(s?.luy_ke ?? s?.da_lam ?? 0),
        chi_tieu_ngay: Number(s?.chi_tieu_ngay ?? kpi.defaultDailyTarget ?? 100),
        giao: Number(s?.giao ?? s?.da_thu_nhan ?? 0),
        da_lam: Number(s?.da_lam ?? s?.luy_ke ?? 0),
        ngay_hom_nay: Number(s?.ngay_hom_nay ?? 0),
        reported: Boolean(s?.reported)
      };
    });
    mergedCommuneData[c.stt] = {
      stats: statsObj,
      last_updated_days_ago: Number(existing?.last_updated_days_ago ?? 0)
    };
  });

  const validPeriod = ['day', 'month', 'quarter', 'year'].includes(saved.selectedPeriod)
    ? saved.selectedPeriod
    : 'day';

  return {
    kpis: mergedKpis,
    selectedKpiId: saved.selectedKpiId || 'all',
    selectedPeriod: validPeriod,
    selectedDate: date,
    searchQuery: saved.searchQuery || '',
    tableFilterStatus: saved.tableFilterStatus || 'all',
    mapZoom: Number(saved.mapZoom) || 1.0,
    mapFilter: saved.mapFilter || 'all',
    communeData: mergedCommuneData,
    rankingRules: saved.rankingRules ? { ...DEFAULT_RANKING_RULES, ...saved.rankingRules } : { ...DEFAULT_RANKING_RULES },
    kioskRunning: false,
    kioskStep: 0
  };
}

export function loadStateForDate(date: string): { state: AppState; previousState?: AppState; version: number } {
  const record = readDateRecord(date);
  
  // Find closest previous date for historical comparison
  const previousDates = getSavedDates().filter(d => d < date);
  const previousDate = previousDates[previousDates.length - 1];
  let previousState: AppState | undefined = undefined;

  if (previousDate) {
    const prevRecord = readDateRecord(previousDate);
    if (prevRecord && prevRecord.state) {
      previousState = normalizeAppState(prevRecord.state, previousDate);
    }
  }

  if (record && record.state) {
    return {
      state: normalizeAppState(record.state, date),
      previousState,
      version: Number(record.version) || 1
    };
  }

  // Not saved yet for this date. Carry forward reference from previous date
  let state = createDefaultState(date, previousState?.kpis);
  if (previousState) {
    const carried = normalizeAppState(previousState, date);
    const elapsedDays = Math.max(0, Math.round((new Date(date + 'T00:00:00Z').getTime() - new Date(previousDate + 'T00:00:00Z').getTime()) / 86400000));
    Object.values(carried.communeData).forEach(unit => {
      Object.values(unit.stats || {}).forEach(stats => {
        stats.qua_han_ngay = 0;
        stats.ngay_hom_nay = 0;
        stats.reported = false;
      });
      unit.last_updated_days_ago = elapsedDays;
    });
    state = carried;
  }

  return { state, previousState, version: 0 };
}
